import json
import re
from pathlib import Path

root = Path(__file__).parent
json.loads((root / 'after/tools/docs/api-card-tasks.json').read_text())
assert len((root / 'after/AGENTS.md').read_text().splitlines()) <= 150
paths = ('AGENTS.md', 'docs/agent/recipes.md', 'docs/agent/errors.md')
before = '\n'.join((root / 'before' / path).read_text() for path in paths)
after = '\n'.join((root / 'after' / path).read_text() for path in paths)
assert sorted(re.findall(r'DI_BAG_[A-Z_]+', before)) == sorted(re.findall(r'DI_BAG_[A-Z_]+', after))
for phrase in ('bag is closed', 'bag is closing', 'scope-opened', 'scope-closing', 'scope-closed'):
    assert before.count(phrase) == after.count(phrase), phrase
for path in paths:
    assert (root / 'after' / path).read_text().count('```') % 2 == 0, path
print('json, line budget, codes, deferred messages/events, fences: ok')
print('AGENTS lines', len((root / 'after/AGENTS.md').read_text().splitlines()))
