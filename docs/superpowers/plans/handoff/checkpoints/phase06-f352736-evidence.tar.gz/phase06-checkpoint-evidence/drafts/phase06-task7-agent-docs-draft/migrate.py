from pathlib import Path
import re

root = Path(__file__).parent / 'after'
for relative in ('AGENTS.md', 'docs/agent/recipes.md', 'docs/agent/errors.md'):
    path = root / relative
    text = path.read_text()
    text = text.replace("'di-bag/node'", "'di-bag'")
    text = text.replace('.inspectGraph(', '.graphSnapshot(')
    text = text.replace('.inspectCollection(', '.serviceSnapshot(')
    text = text.replace('.inspect(', '.serviceSnapshot(')
    text = text.replace('.createScope(', '.createChildContainer(')
    text = text.replace('.fork(', '.createIndependentContainer(')
    text = text.replace('ScopeOptions', 'CreateChildContainerOptions')
    text = text.replace('CheckedScopeLifetimes', 'CheckedChildContainerLifetimes')
    text = text.replace('DisjointScopeSelection', 'DisjointChildContainerSelection')
    text = text.replace('ObserverOptions', 'LifecycleObserver')
    text = re.sub(
        r'\.renameExport\(\s*([^,()]+?)\s*,\s*([^,()]+?)\s*\)',
        r'.withRenamedExport({ currentExportKey: \1, newExportKey: \2 })',
        text,
    )
    text = re.sub(r'\bobservers\s*:', 'lifecycleObservers:', text)
    text = re.sub(r'\bonEvent\s*:', 'onLifecycleEvent:', text)
    text = re.sub(r'\bonError\s*:', 'onObserverFailure:', text)
    text = re.sub(r'\bonEvent\s*\(', 'onLifecycleEvent(', text)
    text = re.sub(r'\bonError\s*\(', 'onObserverFailure(', text)
    text = text.replace('{ share:', '{ sharedParentServiceKeys:')
    path.write_text(text)
