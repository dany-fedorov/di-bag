# Phase 6 Task 6 graph-manual draft

- Baseline: the nine current graph fixture files listed in `/tmp/di-bag-phase-06/task6-preview4-graph-inventory.txt`, copied from the post-mechanical Phase 6 tree. The source worktree was not edited.
- Input classification: 43 rows owned by `task6-current-graph-fixture` in `task6-preview3-manual-classification.json`.
- Output patch: `/tmp/di-bag-resume-20260921/phase06-task6-graph-manual-resolutions.diff` (SHA-256 `653961bafc2ecbfd4670f46ef1349c2d2d2c141589af69dd7a1cd40451076c5d`).

The draft migrates only current fixture APIs: `register` to `withServices`, each module install to ordered singleton `withInstalledModules` calls, terminals to `buildContainer`, module arrays/options to the checked `exportedServiceKeys`/`moduleLabel` bag, and the one positional export rename to `withRenamedExport`.

`split-builder.ts` remains split across `incomplete` and its later extension, so its intentional unresolved/cycle behavior is preserved. `ready-chain.ts` retains `ensureServicesReady` after the renamed terminal. The patch contains exactly the nine inventoried current files; protected `builder-names-0-4.ts` and other 0.4 compatibility fixtures are absent.

Light verification:

- `git apply --check` succeeds against the current post-mechanical Phase 6 files.
- Node 24 syntax checks succeed for all nine scratch files.
- Across the nine files, remaining `.installModule`, `.register`, `.build`, `.renameExport`, and positional `buildModule` matches are all zero. Before counts were 10, 15, 10, 1, and 8 respectively.
- No graph test, compiler, build, or other heavy gate was run.
