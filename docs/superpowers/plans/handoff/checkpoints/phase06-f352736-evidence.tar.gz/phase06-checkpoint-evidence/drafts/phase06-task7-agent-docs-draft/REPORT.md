# Phase 6 Task 7 authored-agent draft

Scratch-only draft over the current Phase 6 execution tree. Reserved paths: `AGENTS.md`, `docs/agent/recipes.md`, `docs/agent/errors.md`, and `tools/docs/api-card-tasks.json`. No generated API card/reference file or Phase 6 worktree file was edited.

## Inputs

- `AGENTS.md`: `936e6167faf5ea04b12c465808ade95595aad4a6114c34996dc09a4e7a3b6103`
- `docs/agent/recipes.md`: `d023d36faf8d1dc71534ce2529806d9c0a20e8a5008406ab711b92e37cdcb95b`
- `docs/agent/errors.md`: `96a9f57abe672edd8d6690c7771111230bfa052fd28ffbfa75d65a0ba4ef2455`
- `tools/docs/api-card-tasks.json`: `948abe062f83c1842d235e9b9fcc3b271a42d8f8cba9fa5e6653946932d861b3`

## Result

Patch: `task7-agent-docs.diff`, SHA-256 `8602b32a09a2543817cb56838ac20566e1b5e646775f233499983174c1718433`.

The draft uses the root import, current container/snapshot/module/observer names, positional replacement pairs, the optional `sharedParentServiceKeys` bag, current container terminology, and `container` receivers in the API-card task registry. It changes no DI Bag product/package name, `DI_BAG_*` code, lifecycle event field, or deferred `bag is closing` / `bag is closed` text. `AGENTS.md` remains exactly 150 lines.

The touched runtime-error summaries follow the current normalizers: malformed options, selections, provider records, and positional shapes are `DI_BAG_INVALID_ARGUMENT`; `DI_BAG_INVALID_OVERRIDE` covers unregistered independent replacements and missing own replacement providers in either derivation method; `DI_BAG_INVALID_SCOPE` covers unregistered child selections and invalid child sharing semantics; and malformed lifecycle observer records or runtime classifiers remain `DI_BAG_INVALID_CONFIGURATION`. The service-readiness prose uses container terminology without changing deferred literal close-state messages.

Light checks: JSON parses; Markdown fences balance; the `DI_BAG_*` token multiset and deferred close/event text counts match the input; retired authored-call/callback/type scans are empty except intentional product names; and `git apply --check` succeeds against the moving Phase 6 tree. No docs generator, compiler, build, or test ran.

Final application, integrated generated-document checks, and commit ownership remain with the Phase 6 executor.
