import json, os, pathlib, signal, subprocess, sys, time

label, cwd, *command = sys.argv[1:]
root = pathlib.Path('/tmp/di-bag-resume-20260921/gates-phase00')
root.mkdir(exist_ok=True)
def resources():
    mem = dict(line.split(':', 1) for line in pathlib.Path('/proc/meminfo').read_text().splitlines())
    available = int(mem['MemAvailable'].split()[0]) / 1024**2
    swap = (int(mem['SwapTotal'].split()[0]) - int(mem['SwapFree'].split()[0])) / 1024**2
    pressure = pathlib.Path('/proc/pressure/memory').read_text().splitlines()
    full = float(dict(item.split('=') for item in pressure[1].split()[1:])['avg10'])
    return {'availableGiB': round(available, 2), 'swapUsedGiB': round(swap, 2), 'fullPressure10': full}
initial = resources()
launch_minimum = max(6.0, float(os.environ.get('DI_BAG_GUARD_MIN_AVAILABLE_GIB', '6')))
if initial['availableGiB'] < launch_minimum:
    print(json.dumps({'deferred': label, 'resources': initial, 'requiredGiB': launch_minimum}), flush=True)
    sys.exit(75)
env = os.environ.copy()
env['PATH'] = '/tmp/claude-1000/-home-df-wd-personal-di-bag/7818417c-3b3a-48db-9bef-85624eff953b/scratchpad/bun/bin:' + env['PATH']
env['npm_config_update_notifier'] = 'false'
env['GOMAXPROCS'] = '2'
start = time.monotonic()
minimum = initial['availableGiB']
bad_since = None
stopped = False
with (root / (label + '.log')).open('w') as log:
    process = subprocess.Popen(command, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'started': label, 'pid': process.pid, 'command': command, 'resources': initial}), flush=True)
    last_report = start
    while process.poll() is None:
        current = resources()
        minimum = min(minimum, current['availableGiB'])
        now = time.monotonic()
        unsafe = current['availableGiB'] < 3 or current['fullPressure10'] > 10
        bad_since = (bad_since or now) if unsafe else None
        if bad_since is not None and now - bad_since >= 10:
            stopped = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
            print(json.dumps({'resourceStop': label, 'resources': current}), flush=True)
            break
        if now - last_report >= 30:
            print(json.dumps({'running': label, 'seconds': round(now-start), 'resources': current}), flush=True)
            last_report = now
        time.sleep(2)
    code = process.wait()
end_resources = resources()
minimum = min(minimum, end_resources['availableGiB'])
result = {'label': label, 'exitCode': code, 'resourceStopped': stopped, 'seconds': round(time.monotonic()-start, 2), 'minimumAvailableGiB': minimum, 'endResources': end_resources}
(root / (label + '.json')).write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result), flush=True)
print('\n'.join((root / (label+'.log')).read_text(errors='replace').splitlines()[-18:]), flush=True)
sys.exit(75 if stopped else code)
