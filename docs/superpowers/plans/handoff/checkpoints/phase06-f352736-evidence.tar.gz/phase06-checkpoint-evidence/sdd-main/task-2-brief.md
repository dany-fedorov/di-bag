# Task 2 — derivation parsers and runtime

Authoritative range: plan07 lines 578–966. Consumes Task 1's unstaged tree.

- Add runtime tests first and capture the focused red.
- Implement explicit child/independent selectors with `snapshotOptionsBag`; snapshot tuple indices before provider getters.
- Preserve ownership: child shares only requested parent acquisitions; independent never shares. Keep collection replacement/disposal view semantics.
- Connect new public methods directly; retain old scope/fork implementations through expand.
- Run focused runtime, classic/native compiler fixtures, typecheck, and declaration consumption as printed.
- Run twelve-case evidence. Adopt S3 only if every row is accepted and cumulative delta is <=10%; otherwise take the named fallback and repeat affected work.
- Write exact decision, attempts, compiler versions, commands, and all twelve rows to phase-06 evidence.
- Commit Tasks 1–2 together as `feat!: add container derivation APIs`, with required trailers and observed generated-doc status only.

## Reviewed entry corrections

The root plan07 now preserves explicit pair presence independently of empty tuple length: validate an explicitly supplied replacement map even with no selected keys, without reading unselected getters. Claim shared token kinds as well as replacement kinds before installation; retain collection-sharing rejection. Add exact wrong-kind and empty-map shape controls. See /tmp/di-bag-resume-20260921/phase06-task2-selector-review.md and the current authoritative root plan, whose printed bodies include the fixes.


## Controller update: e6df58b

The authoritative plan is /home/df/wd/personal/di-bag/docs/superpowers/plans/2026-09-21-07-container-renames.md (root next e6df58b), not this worktree's entry copy. S3 preferred bag failed all three serious candidates. Selected replacements are positional; preserve no-argument/empty-bag/undefined/share-only forms. Root plan explicitly records the independently reviewed fallback dependency annotations and four precise negative marker changes, preserving rejected bag evidence. Task5 goldens and mapped-role test now use positional pairs and a quoted `parent-keys` sharing field; Task7 current-call examples and inventory are positional. Compiler and declaration focused checks passed before additional required regression controls; cumulative measurement and combined review still pending at this update.
