# Task 8 — contract container type and methods

Authoritative range: plan07 lines 1954–2061. Remains uncommitted into Tasks 9–11.

- Add removal tests first, then rename public `Bag` to `Container` and remove old inspect/scope/fork/support declarations.
- Keep internal `BagRuntime`, graph JSON `kind: "bag"`, product/code names, and the 10 closing + 5 closed messages.
- Preserve seven callable facade exports from their actual owners and the physical builder-renames producer/consumer, including both replacement paths.
- Update public comments/JSDoc only within phase scope. Do not touch deferred close-state text.
- Run contract tests/audits; only Task 9 expand names and explicit negative/codemod inputs may remain.
- Leave checked changes unstaged and uncommitted.


## Controller update: 002d5f0

Read authoritative root plan07 at /home/df/wd/personal/di-bag/docs/superpowers/plans/2026-09-21-07-container-renames.md; its Task3/4/8/9 corrections supersede this entry brief and the worktree tracked plan. Task3 has explicit S5 snapshot overloads with never-rest on BOTH, per-operation RenameKeys default preserving legacy until contraction, exact runtime bag/getter checks and all three contributions fixtures plus emitted/physical declaration proof. Task4 owns immediate LifecycleObserver index export and retains object-only frozen callback snapshots plus legacy array text. Task8 removes inspectCollection and only an exact duplicate never control after migration; Task9 contracts RenameKeys default/constraint to the new operation. Root and independent reviews are recorded in the resume ledger.


Controller correction, 2026-09-22: Retired-member runtime and negative-type controls include inspectCollection alongside inspect, inspectGraph, createScope and fork. Close the runtime test container.


Controller correction, 2026-09-22: Remove the temporary Task6 Bag as Container export alias when renaming the actual class to Container.


Controller correction, 2026-09-22: Only at Task8 remove the expand-only lifetimes Bag as LegacyContainer import and ContainerAliasIdentity equality. Never rewrite the equality into Container==Container. Retain defaultBag: Container, ContainerAliasValue, producer-hidden consumption and reflected-method wrapper assertions; independent review approves this precise contraction boundary.


Controller entry correction, 2026-09-22: Files explicitly include tests/types/lifetimes.ts for the previously approved expand-only alias identity retirement.
