# Task 11 — regenerate docs and close ratchets

Authoritative range: plan07 lines 2208–2275. Commits Tasks 8–11 atomically.

- Update docs receiver/signature expectations for final declarations, then run build and docs generation.
- Generated reference must contain Container/new option/lifetime/observer pages and no Bag/old support/node pages.
- Edit only allowed API-reference link rows after generation. Never hand-edit generated pages.
- Remove exactly the six Phase 6 naming-ratchet entries; do not touch later-phase owners. Remove only stale summary ids.
- Run rendering, naming, snippets, docs check/site links, and AGENTS line budget.
- Confirm generated-doc exception is closed and unchanged 400-line API-card budget is green.
- Stage the exact coherent source/package/tests/scripts/docs set and commit `refactor!: contract container API and publish reference` with trailers.


Controller correction, 2026-09-22: Preserve both existing exact-rendering snapshot checks: collection serviceSnapshot overload retains CollectionTokenMember, never rest guard and readonly array return, and ordinary serviceSnapshot retains its never rest guard. Do not reduce coverage to the short ordinary-signature fragment.


Controller entry correction, 2026-09-22: Delete the docs/guides/api-reference.md di-bag/node table row after its generated target is removed; do not repoint the retired entry. Other guide prose remains deferred.
