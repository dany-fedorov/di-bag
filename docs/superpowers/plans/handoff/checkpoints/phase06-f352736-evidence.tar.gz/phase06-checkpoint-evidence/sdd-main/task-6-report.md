# Task 6 — typed container migration

## Candidate

- Base: `e33c976e42f306d819ddf0bc9281014d77b495e1` (reviewed graph parser integrated).
- Final tracked diff: 137 paths, `/tmp/di-bag-phase-06/task6-final-candidate.diff`, SHA-256 `20378fa608f5e804d2383b91d7f96c0ab298f732dd0fc4de2f221c16bacb2ea4`.
- Final path inventory: `/tmp/di-bag-phase-06/task6-final-changed-files-r2.txt`, SHA-256 `340eef232bdc8553f5b99f1d995a12027492b6078d634468496edf8b195628f0`.
- `git diff --check` passes.

## Mechanical and hand provenance

- The one checker write changed 135 files with 730 rewrites and 135 manual rows. Its report is `/tmp/di-bag-phase-06/task6-write1-report.txt` (SHA-256 `5129fef9e2298c500be8540883c3e5fd9ec5aee92e297be437f7c34ac1950b8f`).
- The exact mechanical patch is `/tmp/di-bag-phase-06/task6-mechanical-write1.diff` (SHA-256 `ec8a9f936385d07230af0580a8458543a44e2402b148055248cc286144a2e3aa`). The final preview and write differed only in `written`.
- The separately reviewed graph hand patch owns 43 rows in nine current fixtures: `/tmp/di-bag-resume-20260921/phase06-task6-graph-manual-resolutions.diff` (SHA-256 `653961bafc2ecbfd4670f46ef1349c2d2d2c141589af69dd7a1cd40451076c5d`). It excludes both protected builder-name compatibility fixtures.
- All remaining edits relative to the mechanical snapshot are retained in `/tmp/di-bag-phase-06/task6-hand-after-mechanical.diff` (SHA-256 `04b0933f9333058f423b3cd10f4445101007fc5f5f1a3a0d793cd40954b287a3`). They include 26 `inspectCollection` rows, positional derivation/reference repairs, indirect option records, malformed controls, reflected declaration consumption, and runtime expectation adaptations.
- `/tmp/di-bag-phase-06/task6-final-manual-dispositions.json` (SHA-256 `8ee95ba58c3b4b82bb3a55872dbc65458bd185de34156678b9b6dda4717b1004`) maps every one of the 135 initial manual rows to its final disposition: 68 resolved hand migrations, 43 reviewed graph hand migrations, 20 retained current controls, three retained negative controls, and one retained expand control. It reports 135 accounted and zero unaccounted.
- Three checker-written paths end byte-identical to the base because hand review restored their expand controls: `tests/container-names.test.ts`, `tests/types/negative/observers.ts`, and `tests/types/negative/startup.ts`. Five paths are hand-only additions to the final inventory: `src/module-types.ts`, `tests/contributions-runtime-fixture.ts`, `tests/observers-runtime-fixture.ts`, `tests/platform/portable/contract.ts`, and `tests/types/lifetimes-consumer.ts`.

## Preserved boundaries

- `tests/types/negative/startup.ts` retains invalid `timeoutMs` and `signal`; `tests/types/negative/api-renaming.ts` retains the legacy `buildModule` array rejection.
- `tests/container-names.test.ts` retains all legacy/mixed observer expand controls. Observer indirect options and mutations use the current fields elsewhere, while the extracted receiver negatives still fail for their intended reason.
- The emitted lifetime consumer invokes imported `reflectedScope` through a never-run wrapper and proves its exact return, while retaining non-`any` checks for both reflected methods.
- `RenameKeys` and `InvalidRename` constrain `Operation` with `extends string`. The public methods still supply exact `renameExport`/`withRenamedExport` operation literals; the default remains `renameExport` during expand. This follows the existing selection-helper pattern and avoids presenting diagnostic operation literals as public values to the naming ratchet.
- Final residual classification is `/tmp/di-bag-phase-06/task6-final-residual-classification.json` (SHA-256 `469ef100ae5edaec52212452d2db80606a9f4e2cd75b468c966702c849037f1a`): 64 rows, zero unclassified. Owners are Task 7 generated runtime source (28), Task 7 generated package source (21), private `BagRuntime` inspection (10), and the Task 7 bilingual benchmark adapter (5).

## Verification

- Negative lane: `phase06-task6-negatives3`, 86/86 and 430 assertions, min 12.14 GiB. Earlier marker-discovery runs `negatives1` and `negatives2` remain retained failures.
- Full type harness: `phase06-task6-types-full1` had 136 passes and one real 5409 ms per-test timeout for lifetime declaration consumption. The same byte-identical lifetime source/emitted cases passed focused (`lifetimes-focused1`, 2/2), and `types-full2` passed 137/137 with 521 assertions, min 11.27 GiB. No timeout or source workaround was introduced.
- Naming fix: `phase06-task6-operation-naming1`, naming ratchet plus contribution source/emitted/negative checks 4/4, min 12.06 GiB.
- Runtime: `phase06-task6-fast1` retained eight stale runtime-expectation failures plus the `RenameKeys` naming-helper constraint failure (627 pass); focused repairs closed them, and `phase06-task6-fast2` passes 636/636 with 16,227 assertions, min 13.43 GiB.
- `phase06-task6-typecheck6` and `phase06-task6-build1` pass.
- `phase06-task6-graph1` passes 23/23; `phase06-task6-agent-eval1` passes 7/7.
- No resource guard stopped. All raw logs and JSON receipts are under `/tmp/di-bag-resume-20260921/gates-phase00/` with the labels above.

## Documentation state

Task 6 does not edit authored or generated documentation. The bounded expand-period generated-reference exception remains the already observed missing Markdown links for `CreateChildContainerOptions` and `CheckedScopeLifetimes`; source/runtime/type/build/graph/agent checks for this candidate are green. Task 7 owns generated strings and authored agent material, and Tasks 8–11 close the generated-reference exception atomically.
