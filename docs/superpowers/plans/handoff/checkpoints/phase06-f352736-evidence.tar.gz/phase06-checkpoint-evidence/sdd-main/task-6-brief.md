# Task 6 — one typed mechanical migration

Authoritative range: plan07 lines 1724–1779.

- Build first, run inclusive preview with src/dist roots and negative fixtures, then read and classify every manual item.
- Apply exactly once to typed tests/examples/agent-eval/graph fixtures. Resolve manuals by the Task 5 reasons; preserve explicit negative, codemod-input, and graph 0.4 compatibility fixtures.
- Preserve Phase 5 builder shapes: positional token/replacement, contribution/alias bags, module list, checked module bag.
- Audit changed-file inventory and old-use controls; run only the printed source/runtime/compiler checks.
- Stage exact report-changed paths. Commit this pure mechanical unit with the exact producing command in the body and required trailers.


## Controller S5 migration ruling: e5bcaf0

Root authoritative plan07 now explicitly owns 26 typed inspectCollection rows (11files), invisible to the original-map name gates. Preserve old pure-collection reflected context as collectionSnapshotMethod, separately from Task3 aggregateBag serviceSnapshotMethod; do not drop its assertion. Adapt two obsolete method-specific kind failures to valid unified snapshots and retain two real opposite-kind/same-symbol rejection controls with exactdetails. Task7 owns one acquisition-retention.node.mjs call through an explicit collection-snapshot rule. All public residual audits include inspectCollection; private runtime channel and exact historical phase05-strings.py evidence remain. Do not attribute these hand edits to codemod or invent a fictional0.4 map hop. Read the root plan for full inventory and review links.


Controller correction, 2026-09-22: Use the authoritative root Task6 commands with explicit agent-eval and current graph extra-file roots; preserve builder-names-0-4.ts and builder-names-0-5.ts. Retain exact mechanical/hand patch provenance; no unverified intermediate commit.


Controller correction, 2026-09-22: Missing prerequisite approved: add type-only Bag as Container export in di-bag.ts and root index before migration, preserving underlying Bag class. Follow authoritative root Task6 prerequisite RED/GREEN, emitted/physical proof and preview identity requirements, then separate reviewed commit.


Controller correction, 2026-09-22: Frozen-write preservation preflight is /tmp/di-bag-resume-20260921/phase06-task6-preservation-preflight.md. Resolve all five boundaries with exact hand provenance. Reflected lifetime proof must exercise imported reflectedScope through a never-invoked consumer wrapper, not substitute only a direct graph method result; see phase06-task6-reflected-contract-audit.md.


Controller correction, 2026-09-22: RenameKeys and InvalidRename use Operation extends string, matching Selection / InvalidSelection. Preserve the old renameExport default during expansion and change only the default to withRenamedExport at Task9; public methods keep exact operation arguments. Do not grow the naming ratchet or relax the scanner. Authoritative root plan supersedes the earlier literal-union constraint.
