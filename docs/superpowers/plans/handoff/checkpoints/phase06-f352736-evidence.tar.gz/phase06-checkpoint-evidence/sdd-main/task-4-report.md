# Task 4 report — lifecycle observer names

- Base: `6738ee66b817ad9706183f2fcae9cd05dd95afa9`.
- Owned files: `src/observers.ts`, `src/index.ts`, `src/di-bag.ts`,
  `tests/container-names.test.ts`, and the three existing observer type fixtures.
- Added public `LifecycleObserver`, `lifecycleObservers`, `onLifecycleEvent`, and
  `onObserverFailure` beside the retained expand names.
- The private queue still stores one `ObserverRecord` shape and preserves event order/failure routing.
- Legacy and renamed callbacks are snapshotted once into frozen records; function records are rejected.
- `withConfiguration` rejects both observer fields in one snapshotted options bag.

## TDD and proof

- `phase06-task4-container-names-red`: expected RED, 4 pass / 3 fail because the renamed
  configuration field was absent; 15 assertions, no resource stop.
- `phase06-task4-runtime1`: 21 tests / 114 assertions, exit 0, minimum 13.93 GiB.
- `phase06-task4-types1`: observer source, negative, and emitted-declaration consumer cases;
  3 tests / 11 assertions, exit 0, minimum 12.66 GiB.
- `phase06-task4-typecheck1`: `npm run typecheck`, exit 0, minimum 12.86 GiB.
- `phase06-task4-build1`: `npm run build`, exit 0, minimum 13.91 GiB.
- `git diff --check`: clean.

## Documentation status

- `phase06-task4-docs-generate1` stopped only at missing Markdown link
  `CheckedScopeLifetimes`; `phase06-task4-docs-check1` stopped only at missing link
  `CreateChildContainerOptions`.
- These are the authorized generated dual-surface link exception through Task 7;
  coherent generation is owned by Tasks 8–11.

## Evidence

- Guard JSON/logs: `/tmp/di-bag-resume-20260921/gates-phase00/phase06-task4-*`.
- Frozen diff: `/tmp/di-bag-resume-20260921/phase06-task4-review.diff`.
- Commit pending independent review; no push or merge performed.
