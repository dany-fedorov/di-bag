# Dependency, gate, and resource checklist

## Start boundary

- Wait for Phase 5 merge, push, clean `next`, final phase-05 evidence, and controller authorization.
- Create `phase-06-container-renames` only then; create `/tmp/di-bag-phase-06`.
- Pinned tools: Bun 1.4.0 first on PATH, Node 24.20.0, update notifier off.
- Confirm the final entry tree rather than copying counts from the 0.4-era plan.

## Binding Phase 5 contracts

- Collection fallback: `resolveCollection` and `inspectCollection`; ordinary `resolve`/`inspect` remain single-service-only.
- Builder choices: positional `withTokenService(token, provider)` and `withReplacedService(serviceKey, provider)`; bag alias/contribution; `withInstalledModules(list)`; checked `buildModule({ exportedServiceKeys, moduleLabel? })`.
- Preserve seven public callable facades: six from `builder-method-types.ts` plus `BuilderWithCollectionContribution` from `contribution-types.ts`. Physical producer/consumer must exercise all seven and both replacement paths.
- Preserve Phase 5's bilingual graph extractor, old/current terminals and shapes, ordered inline/const module lists, schema `kind: "bag"`, and repeated-contribution omission parity.
- Preserve benchmark lane adapter: current builder surface; pinned `739b509` baseline `begin/add/end`, `factory(...,{ acquisition })`, `scope/inspect`.
- Entry selection: current always root; baseline uses `di-bag/node` only for `node-native-promise`. Keep `runRuntimeArchiveSmoke` and its test lane-aware.

## Task dependencies

`0 -> (1 + 2 combined) -> 3 -> 4 -> 5 -> 6 -> 7 -> (8 + 9 + 10 + 11 coherent contract) -> 12`.

- Task 1 stays uncommitted into Task 2; Task 2 records S3 and commits both.
- Tasks 3–5 commit separately. Task 6 is the pure mechanical commit. Task 7 is the hand/generated migration commit.
- Tasks 8–10 remain unstaged and uncommitted into Task 11; Task 11 commits source, packaging, tests, and generated docs atomically.
- Generated-doc-only red is allowed only for the named expand/migrate commits, only after observed evidence. Runtime/compiler/codemod/graph checks remain green. Task 11 closes the exception.

## Resource protocol

- One heavy lane only. Use `/tmp/di-bag-resume-20260921/run-guarded.py`, unique phase06 labels, pinned PATH, and the controller's launch minimum (8 GiB focused; 12 GiB full/compiler unless controller rules otherwise).
- Nested-spawn suites use the established exact escalated execution. Do not rerun a passing broad gate.
- Test first with the narrow command in each task. The full gate runs once in Task 12.
- After three serious type-shape failures or a >10% cumulative evidence result, take the named S3 fallback and record attempts; never weaken fixtures.

## Final gate order

Run the authoritative Task 12/master list serially: `npm run check`,
`docs:check`, `graph:check`, `codemod:check`, native type/build/check,
classic build, three Node retention suites, `agent-eval:test`, then the
fail-fast pinned-Bun examples. Final classic build must leave `dist/` current.
No actual agent evaluation is allowed.

- Preserve the final Phase 5 `Builder<in out Entries, in out Constraints>` annotations together with the invariant function witness; all twelve repaired budget cases pass below the original baselines. Do not restore the unannotated recursive declaration from older plan-era code.
