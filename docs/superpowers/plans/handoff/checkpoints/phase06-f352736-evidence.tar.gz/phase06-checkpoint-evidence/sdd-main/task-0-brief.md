# Task 0 — branch and entry check

Authoritative range: plan07 lines 157–175.

- Start only from clean, merged Phase 5 `next`; create `phase-06-container-renames` and `/tmp/di-bag-phase-06`.
- Run every State-on-entry command and save exact output. Recount names; old planning counts are advisory.
- Record settled Phase 5 choices: positional token/replacement, `withInstalledModules(list)`, seven callable-facade ownership, and whether the invalid-argument docs section exists.
- Read final phase-04/05 evidence. Pin collection fallback to `resolveCollection`/`inspectCollection`.
- Run one guarded `npm run build` so dist-reading tests start current.
- No repository files and no commit.

- Preserve the final Phase 5 `Builder<in out Entries, in out Constraints>` annotations together with the invariant function witness; all twelve repaired budget cases pass below the original baselines. Do not restore the unannotated recursive declaration from older plan-era code.
