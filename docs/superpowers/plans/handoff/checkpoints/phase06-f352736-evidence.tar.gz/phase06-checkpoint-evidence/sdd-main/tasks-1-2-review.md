# Tasks 1–2 independent review

**Candidate:** uncommitted 13-file patch based on `324d4a7`; frozen diff SHA-256 `9bf8cd3ba541740d69fc4aeef9c9766c2f2fa86ea84c4478a1747253b2fe1f00`.

**Spec verdict:** Compliant.  
**Code-quality verdict:** Approved.  
**Findings:** None. Ready for the combined green commit and Task 3.

- The selected fallback is implemented consistently: replacement pairs are positional, while zero arguments, explicit `undefined`, empty options, and child sharing-only options remain supported. The three rejected bag signatures and the legacy inference control are preserved accurately in evidence.
- Public overloads retain replacement output inference, compatibility/completeness/constraint checks, lifetime checks, collection-aware admission, disjoint sharing, and exact operation names. The empty option branch uses optional `never`, so explicit replacement properties cannot enter the one-bag forms.
- Runtime normalization snapshots only the allowed one-bag fields, enforces exact arity, and rejects hidden replacement fields. The selectors snapshot tuple indices, authenticate both selected and shared token kinds before provider reads, validate explicit empty provider maps, reject collection/transient sharing, and read selected provider values once.
- Ownership remains correct: children use the parent runtime's tracked scope and only the requested shared binding IDs; independent containers create fresh runtime ownership. Empty selections preserve graph identity. Collection replacements preserve provider-owned arrays and return frozen read snapshots.
- Old `fork`/`createScope`, `CheckedScopeLifetimes`, and their behavior remain additive and unchanged during expand. The renamed lifetime helper and `Overrides` operation parameter preserve existing defaults.
- Runtime coverage includes identity/ownership, named and token replacements, collection replacement/disposal, both wrong-kind directions, publicly replaced collection sharing, explicit empty maps, getter ordering/counts, malformed registrations/options/arity, hidden replacement fields, overlap, transient sharing, and exact codes/details.
- Compiler coverage keeps positive inference and emitted-declaration consumption plus exact negatives for unknown/missing/wrong outputs, bag-form exclusion including explicit `undefined`, dependency completeness, lifetime capture, transient sharing, and disjoint selections. No negative case was weakened.
- Final evidence is coherent: runtime 21/49; compiler fixtures 3/11; classic/native source checks and build exit 0. All 12 S3 rows are accepted within the unchanged 10% limit; JSON SHA-256 `a043ae905c978dbc8060580f1e6cd05b15d8148a532dab1e6f2cc09df7b4d2fd`.
- Documentation checks expose only the authorized dual-surface drift: restored docs 28/29 lacks the new `CreateChildContainerOptions` link, and generated docs lacks the retained `CheckedScopeLifetimes` link. Both new public methods have complete examples and throws documentation; no other docs failure is hidden.
- `tasks-1-2-report.md` SHA-256 `b48634e7aab0feaa96d3469824b6be1973b357581f0661c328574d7c0b89ee93` accurately distinguishes compiler-host emitted declarations from a physical installed-package matrix. The patch applies cleanly in reverse and `git diff --check` passes.
