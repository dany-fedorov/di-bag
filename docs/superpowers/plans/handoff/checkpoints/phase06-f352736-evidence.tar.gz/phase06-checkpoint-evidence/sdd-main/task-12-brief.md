# Task 12 — final audit, evidence, and gate

Authoritative range: plan07 lines 2279–2354.

- Run retired declaration/member/operation/import audits. Allow only explicit negative/codemod/graph compatibility inputs and exact pinned-baseline benchmark branches.
- Recount unchanged 10 closing + 5 closed assertions and three runtime construction sites.
- Re-run twelve-case evidence; every row accepted, token diagnostics empty, cumulative delta <=10%. Update final evidence values and decision.
- Run the full guarded master gate serially, including native lanes, classic rebuild before Node retention suites, agent-eval harness tests, and fail-fast pinned-Bun examples.
- Verify codemod from a clean 0.4 fixture byte-for-byte including literal manual report.
- Commit only final phase evidence as `docs(plans): record phase 6 evidence`.
- Require clean status and report branch, commits, every gate, S3 decision/numbers, manual resolutions, deliberate BagRuntime/schema decisions, red-exception hashes, and deviations in <=60 lines.
