# Task 7 — generated strings, graph, agents, benchmark adapter

Authoritative range: plan07 lines 1782–1949.

- Hand-migrate generated TypeScript/JS/docs inputs; `reshape-untyped.mjs` excludes benchmark adapter files and deliberate compatibility fixtures.
- Preserve pinned baseline adapter byte-for-byte: `begin/add/end`, `factory(...,{ acquisition })`, `scope/inspect`. Hand-migrate only current adapter snapshots/child creation.
- Child entry is lane-aware: current always `di-bag`; only baseline `node-native-promise` uses `di-bag/node`.
- Update `runRuntimeArchiveSmoke` and its test with the same lane/scenario entry predicate. Direct current native-Promise test uses root `DiBag`; exact `739b509` identity stays.
- Preserve the complete Phase 5 bilingual graph extractor and contribution-omission parity; add only renamed-export parsing and retain schema `kind: "bag"`.
- Run evidence cases, agent-eval tests, graph tests, and focused `tests/runtime-benchmark-child.test.ts`; no performance matrix.
- Keep AGENTS <=150 lines. Commit the complete hand/generated migration with observed generated-doc status and trailers.


## Controller update: e6df58b

The authoritative plan is /home/df/wd/personal/di-bag/docs/superpowers/plans/2026-09-21-07-container-renames.md (root next e6df58b), not this worktree's entry copy. S3 preferred bag failed all three serious candidates. Selected replacements are positional; preserve no-argument/empty-bag/undefined/share-only forms. Root plan explicitly records the independently reviewed fallback dependency annotations and four precise negative marker changes, preserving rejected bag evidence. Task5 goldens and mapped-role test now use positional pairs and a quoted `parent-keys` sharing field; Task7 current-call examples and inventory are positional. Compiler and declaration focused checks passed before additional required regression controls; cumulative measurement and combined review still pending at this update.


## Controller S5 migration ruling: e5bcaf0

Root authoritative plan07 now explicitly owns 26 typed inspectCollection rows (11files), invisible to the original-map name gates. Preserve old pure-collection reflected context as collectionSnapshotMethod, separately from Task3 aggregateBag serviceSnapshotMethod; do not drop its assertion. Adapt two obsolete method-specific kind failures to valid unified snapshots and retain two real opposite-kind/same-symbol rejection controls with exactdetails. Task7 owns one acquisition-retention.node.mjs call through an explicit collection-snapshot rule. All public residual audits include inspectCollection; private runtime channel and exact historical phase05-strings.py evidence remain. Do not attribute these hand edits to codemod or invent a fictional0.4 map hop. Read the root plan for full inventory and review links.


Controller correction, 2026-09-22: Use updated root helper exclusions: exact renamed-exports.test.mjs, container-names.test.ts (all three expand controls), and tests/fixtures/api-naming/** in addition to existing protected paths. Preserve excluded hashes/control accounting separately; callback inventories include method syntax. Verify Task6 observer member-reference fix, do not repeat it.


Controller Task7 entry correction, 2026-09-22: The printed ten derivation rows cover named package/node files only. Also explicitly migrate twelve derivation calls across eight *-runtime-fixture.ts generated-source templates; root entry inventory is /tmp/di-bag-resume-20260921/phase06-task7-runtime-string-derivations.json from594e91c. Preserve positional pairs/provider bodies and sharing-only/third bags; no checker rerun. Capture separate before/after rows, all28 generated runtime residuals remain accounted. See authoritative root plan for exact8file counts.
