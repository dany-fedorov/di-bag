# Task 6 independent review

## Verdict

- **Spec compliance: Approved.** The frozen 137-path migration at base `e33c976e42f306d819ddf0bc9281014d77b495e1` implements the selected positional derivation fallback and current snapshot, module, observer, close-option, type, and entry-point names while retaining the expand compatibility controls assigned to later tasks.
- **Code quality: Approved.** No Critical, Important, or Minor findings remain. The source candidate is `/tmp/di-bag-phase-06/task6-final-candidate.diff`, SHA-256 `20378fa608f5e804d2383b91d7f96c0ab298f732dd0fc4de2f221c16bacb2ea4`.
- Ready to commit as the Task 6 migration unit. Generated-reference failures remain only the previously authorized expand-period missing links; Task 6 does not edit documentation.

## Contract review

- The five preservation findings from the mechanical preflight are closed: invalid startup option names and the legacy `buildModule` array rejection remain invalid; legacy/mixed observer expand tests remain; observer indirect records use current callback names without weakening malformed controls; imports and extracted calls are coherent.
- The emitted lifetime consumer calls imported `reflectedScope` through a never-run wrapper and proves the wrapper's exact return. The existing non-`any` assertions for both extracted derivation methods remain.
- Explicit empty selections still validate the replacement map, avoid unselected reads, reuse the unchanged graph through the empty batch path, and create fresh ownership. `undefined` and `{}` remain valid no-replacement forms; `null`, hidden replacement fields, malformed arities, and invalid third bags remain rejected.
- Duplicate mixed selections now read each own provider getter once, preserve token/name ordering, and route the captured values through private consumers and cleanup assertions.
- Unified `serviceSnapshot` preserves valid single and collection snapshots. The obsolete method-specific kind failures became valid reads, while forged opposite-kind handles over real same-symbol graph entries retain both exact `DI_BAG_WRONG_TOKEN_KIND` codes and details. Missing replacement providers still pin `DI_BAG_INVALID_OVERRIDE`.
- Configuration migration pins the exact `DI_BAG_INVALID_ARGUMENT` code, `{ operation: 'withConfiguration', argument: 'options', expected: 'an object' }` details, and full message. Callback snapshot/getter tests retain one read per callback, mutation isolation, receiver behavior, append order, and callable/non-object rejection.
- `RenameKeys` and `InvalidRename` safely use `Operation extends string`; old/new public methods continue to supply exact operation literals, and the expand default remains `renameExport`.

## Provenance and evidence

- Mechanical provenance is exact: 135 files, 730 rewrites, 135 manual rows; patch SHA `ec8a9f936385d07230af0580a8458543a44e2402b148055248cc286144a2e3aa`. The graph hand patch and remaining hand patch have SHAs `653961bafc2ecbfd4670f46ef1349c2d2d2c141589af69dd7a1cd40451076c5d` and `04b0933f9333058f423b3cd10f4445101007fc5f5f1a3a0d793cd40954b287a3`.
- Final manual accounting SHA `8ee95ba58c3b4b82bb3a55872dbc65458bd185de34156678b9b6dda4717b1004` maps all 135 initial rows: 68 resolved hand migrations, 43 reviewed graph migrations, 20 intentionally current controls, three negative controls, and one expand control; zero rows are unaccounted.
- Residual classification SHA `469ef100ae5edaec52212452d2db80606a9f4e2cd75b468c966702c849037f1a` contains 64 rows and zero unclassified owners; they are bounded to Task 7 generated/package fixtures, private runtime inspection, and the bilingual benchmark adapter.
- Guard evidence passes: negatives 86/86 (430 assertions), full types 137/137 (521), naming/contribution checks 4/4, fast runtime 636/636 (16,227), source typecheck, build, graph 23/23, and agent evaluation 7/7. No guard reports a resource stop.
- The earlier full-type timeout is isolated by the passing focused 2/2 declaration cases and the later unchanged full 137/137 run; no source or timeout workaround was introduced.
- Final report SHA-256: `253af4b1ccbcdfb3a1b09f7040d428b6d5ddcd64fd74485558520f1a567f3afd`. Final inventory SHA-256: `340eef232bdc8553f5b99f1d995a12027492b6078d634468496edf8b195628f0`.
