# Task 7 checkpoint — unfinished generated and agent migration

Status: **in progress; not reviewed, not committed as a completed task, and not ready for contraction**.

## Repository boundary

- Branch: `phase-06-container-renames`.
- Clean Task 6 base: `594e91c59e90c743c63660b2ee074d7a2f3c1d15`.
- Task 6 exact reviewed diff was committed and the tree was clean before Task 7 began.
- Current Task 7 worktree has 27 modified tracked files and no running command/session.
- Frozen checkpoint diff: `/tmp/di-bag-phase-06/task7-checkpoint.diff`, SHA-256 `3f3100bc958970099be7df731f1a1f92812e95c152c8fdf25bbe5647a40c49cc`.
- Exact path inventory: `/tmp/di-bag-phase-06/task7-checkpoint-files.txt`, SHA-256 `0d408f2cdeabc4fe3a3598811ee1bdd58a7956eb453895bf5d2d3532270317b0`.
- Status snapshot: `/tmp/di-bag-phase-06/task7-checkpoint-status.txt`, SHA-256 `0d4df8b7ebb1837effbf23faa9729326cc59c39ef6645a5fc4ac329ad352c33b`.

## Implemented so far

- Applied the independently reviewed authored-agent patch to `AGENTS.md`, `docs/agent/errors.md`, `docs/agent/recipes.md`, and `tools/docs/api-card-tasks.json`. Source patch: `/tmp/di-bag-resume-20260921/phase06-task7-agent-docs-draft/task7-agent-docs.diff`, SHA-256 `8602b32a09a2543817cb56838ac20566e1b5e646775f233499983174c1718433`.
- Captured and migrated the printed ten named package/node derivation calls in `/tmp/di-bag-phase-06/untyped-derivations.before.txt`.
- Separately found and migrated the twelve helper-visible derivation strings across eight `*-runtime-fixture.ts` files. The authoritative inventory is `/tmp/di-bag-resume-20260921/phase06-task7-runtime-string-derivations.json`.
- The first helper attempt stopped before writing on those additional derivations. After their explicit positional migration, `/tmp/di-bag-phase-06/reshape-untyped.mjs` wrote 16 files and recorded 117 retired rows before / zero after in `/tmp/di-bag-phase-06/untyped-inventory.json` (SHA-256 `89f1a80437b4815b6d1e38eeef5b683efec500e1e51b348c9456be2d963d744e`). This is a mechanical intermediate inventory only.
- Restored all ten textual private `BagRuntime.inspect` rows in `tests/selected-scope-runtime.test.ts` after the helper changed them. These are the intentional private runtime inspection channel, not public `Container.inspect` calls. Do not rerun the helper over that restored file.
- Migrated package declaration strings from `Bag` to `Container`, including the type-only runtime export absence control and unchecked-construction controls.
- Migrated current benchmark adapter calls to `serviceSnapshot` / `createChildContainer`, retained baseline `.inspect()` / `.scope()`, removed current `NodeDiBag`, and made `di-bag/node` selection baseline-and-native-Promise only. Four-file patch: `/tmp/di-bag-phase-06/task7-benchmark-candidate.diff`, SHA-256 `bcc80a216a1651f44768d60e3abad0af6579caf1617a249e075945ce7bc86aa4`. Independent final review was requested from agent 02 and may still be pending.
- Updated archive smoke entry expectations with the same lane/scenario predicate, deduplicated the helper-produced `['di-bag', 'di-bag']` release entry to `['di-bag']`, and updated platform evidence prose to current root-entry coverage.
- Updated the first two migrated observer negative markers to exact `onObserverFailure` / `onLifecycleEvent` diagnostics.
- Protected input hashes still match `/tmp/di-bag-phase-06/task7-protected-inputs.before-r2.sha256`: graph renamed-export compatibility, all three container-name expand controls, both builder-name fixtures, and the API-naming fixtures.

## Verification completed

- `phase06-task7-observers-negative1`: 1/1, five assertions, exit 0, no resource stop, minimum 9.19 GiB.
- `phase06-task7-typecheck1`: retained expected failure only because the helper had renamed the private `BagRuntime.inspect` calls.
- `phase06-task7-typecheck2`: exit 0, no resource stop, minimum 7.77 GiB, after restoring the exact private channel.
- `git diff --check` passed before the checkpoint freeze.

## Remaining work

1. Incorporate the read-only benchmark review result; fix only concrete findings and refresh the four-file benchmark diff if needed.
2. Produce final residual classifications. The helper's 117-to-zero output is intermediate because ten private runtime rows were intentionally restored. Preserve exact Task 7 owners for generated API card drift, graph 0.4/current compatibility, Phase 5 historical strings, container-name expand controls, API-naming fixtures, the baseline benchmark adapter, and `src/node.ts`/node-export contraction controls.
3. Verify the ten named and twelve runtime-fixture derivation inventories are both empty after migration. Keep them as separate populations.
4. Run the focused benchmark protocol/current smoke and all seven current/baseline archive scenarios. Retain baseline commit/archive identities and exact resolved entries.
5. Run changed package/native/token/release/runtime-scale tests, agent-eval, graph, and the source/runtime checks required by the actual changed-file inventory.
6. Run the twelve compiler evidence cases with the 12 GiB launch floor and record final Phase 6 values; no evidence gate has run for this checkpoint.
7. Run integrated authored-doc/API-card checks. `AGENTS.md` remains 150 lines, but no Task 7 docs generation/check/build gate has run.
8. Freeze the final Task 7 diff/report, obtain independent aggregate review, and commit only after all required gates pass. Do not begin Tasks 8–11 contraction from this checkpoint.

## Resource/process state

- No command, test runner, compiler, pack process, or unified exec session is running.
- The last guarded process was `phase06-task7-typecheck2`; it completed successfully.
- Heavy lane is released. The final twelve-case evidence gate still requires at least 12 GiB available at launch; the checkpoint was frozen while available memory was around 9 GiB.
