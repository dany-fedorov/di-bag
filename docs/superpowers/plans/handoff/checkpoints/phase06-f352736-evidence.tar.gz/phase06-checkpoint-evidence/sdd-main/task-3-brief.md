# Task 3 — expand snapshots and module rename

Authoritative range: plan07 lines 970–1121.

- Add focused runtime red coverage for `serviceSnapshot`, `graphSnapshot`, and `withRenamedExport`.
- Rename adopted fallback `inspectCollection` to the collection `serviceSnapshot` overload while retaining `CollectionTokenMember` and never-rest guard; ordinary overload keeps `SingleServiceTokenMember`.
- Preserve general two-argument `TokenMember`; reflected uncalled methods must emit only public facades.
- Add module bag parsing via shared options validation; preserve export identity and runtime error codes.
- Run the printed runtime/type/declaration checks and commit only listed files as `feat!: add container snapshot and module names`.


## Controller update: 002d5f0

Read authoritative root plan07 at /home/df/wd/personal/di-bag/docs/superpowers/plans/2026-09-21-07-container-renames.md; its Task3/4/8/9 corrections supersede this entry brief and the worktree tracked plan. Task3 has explicit S5 snapshot overloads with never-rest on BOTH, per-operation RenameKeys default preserving legacy until contraction, exact runtime bag/getter checks and all three contributions fixtures plus emitted/physical declaration proof. Task4 owns immediate LifecycleObserver index export and retains object-only frozen callback snapshots plus legacy array text. Task8 removes inspectCollection and only an exact duplicate never control after migration; Task9 contracts RenameKeys default/constraint to the new operation. Root and independent reviews are recorded in the resume ledger.
