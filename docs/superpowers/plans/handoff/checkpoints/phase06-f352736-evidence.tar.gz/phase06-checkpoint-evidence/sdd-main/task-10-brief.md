# Task 10 — remove node entry

Authoritative range: plan07 lines 2153–2204. Continues the coherent contract tree.

- Pin root-entry ESM/CJS behavior and subpath rejection before deleting `src/node.ts`, package export, build/docs/CI references, and generated node reference pages.
- Current benchmark lane always loads root. Preserve the explicit pinned-baseline native-Promise node-subpath branch only.
- Keep zero runtime dependencies and no `node:` import reachable from src; `process.getBuiltinModule` remains.
- Update package/platform/release/browser assertions and run the focused package suite plus pinned Node probes.
- Save exact deleted-path inventory. Leave all changes unstaged/uncommitted for Task 11.


Controller entry correction, 2026-09-22: Contract scripts/verify-release-artifacts.ts with root-only package exports: require index JS/declaration, forbid node JS/declaration beside removed adapters. Preserve missing-public-file rejection by removing index.d.ts in its fixture, and add explicit node-file rejection controls. Package archive tests require both index files and reject both node files. See authoritative root plan for exact scope.
