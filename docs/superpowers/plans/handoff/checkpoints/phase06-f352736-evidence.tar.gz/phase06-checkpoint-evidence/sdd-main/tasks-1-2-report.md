# Tasks 1–2 report

- Base: `324d4a7`; candidate remains uncommitted pending independent review.
- Added `createChildContainer` and `createIndependentContainer`, selector/runtime validation, public option/lifetime types, exports, focused runtime/compiler/declaration fixtures, S3 evidence, and the measured API-naming exception.
- Runtime preserves snapshot order, getter read counts, ownership, collection and transient guards, token-kind claims, explicit pair presence, graph identity for empty selections, and exact error codes/details.
- Initial runtime RED: `phase06-task2-container-derivation-red` (0/16; methods absent). Final runtime: `phase06-task2-runtime-fallback3` (21/49), exit 0, minimum 13.42 GiB.
- Three serious options-bag signature attempts failed: candidate 1 inferred replacement providers as `never`; candidates 2 and 3 overflowed TypeScript's mapped-type instantiator. Exact source diffs and raw logs are `/tmp/di-bag-resume-20260921/phase06-task2-candidate{1,2,3}-source.diff` and `gates-phase00/phase06-task2-types-focused{1,2,3}.log`.
- Selected fallback changes only replacement pairs to positional arguments. No-argument, explicit `undefined`, empty options, and child sharing-only calls remain. A same-tree legacy `fork`/`createScope` control established the same dependency-annotation boundary; no fixture annotation hides a new-signature regression.
- Final compiler proof: `phase06-task2-types-fallback7` (3 fixtures/11 assertions), source `phase06-task2-typecheck-fallback3`, native source `phase06-task2-typecheck-native-fallback2`; all exit 0.
- Build after final JSDoc: `phase06-task2-build-fallback3`, exit 0, minimum 14.08 GiB. The declaration consumer uses compiler-host emitted declarations with its producer hidden; it is not a physical installed-package matrix.
- Final S3: `phase06-task2-s3-evidence-fallback2`, all 12 rows accepted, 66.01 s, minimum 11.42 GiB. JSON `/tmp/di-bag-phase-06/s3-fallback-final.json`, SHA-256 `a043ae905c978dbc8060580f1e6cd05b15d8148a532dab1e6f2cc09df7b4d2fd`.
- `phase06-task2-docs-check2`: 28/29; both new calls now have examples and the sole failure is the approved dual-surface missing Markdown link for `CreateChildContainerOptions`.
- `phase06-task2-docs-generate2`: sole approved dual-surface failure, missing Markdown link for retained `CheckedScopeLifetimes`. Full raw output is preserved; no generated references were partially adopted.
- `git diff --check` passes. No full suite, codemod, physical package matrix, push, or merge ran in this bounded group.
