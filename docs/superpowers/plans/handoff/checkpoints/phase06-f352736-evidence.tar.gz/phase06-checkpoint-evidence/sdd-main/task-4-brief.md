# Task 4 — expand lifecycle observer names

Authoritative range: plan07 lines 1125–1340.

- Add runtime red coverage, then `LifecycleObserver`, `onLifecycleEvent`, `onObserverFailure`, and `lifecycleObservers` beside old names.
- Preserve queue ordering, failure routing, callback types, codes, and single snapshot/read behavior.
- Reject both old and new configuration fields together as specified; old/new each work during expand.
- Update positive consumer and negative fixtures without weakening marker text.
- Run the narrow checks and commit listed files as `feat!: rename lifecycle observer configuration`.


## Controller update: 002d5f0

Read authoritative root plan07 at /home/df/wd/personal/di-bag/docs/superpowers/plans/2026-09-21-07-container-renames.md; its Task3/4/8/9 corrections supersede this entry brief and the worktree tracked plan. Task3 has explicit S5 snapshot overloads with never-rest on BOTH, per-operation RenameKeys default preserving legacy until contraction, exact runtime bag/getter checks and all three contributions fixtures plus emitted/physical declaration proof. Task4 owns immediate LifecycleObserver index export and retains object-only frozen callback snapshots plus legacy array text. Task8 removes inspectCollection and only an exact duplicate never control after migration; Task9 contracts RenameKeys default/constraint to the new operation. Root and independent reviews are recorded in the resume ledger.
