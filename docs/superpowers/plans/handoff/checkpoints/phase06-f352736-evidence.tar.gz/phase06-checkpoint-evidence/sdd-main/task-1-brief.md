# Task 1 — expand derivation types and decide S3 inputs

Authoritative range: plan07 lines 179–575. Continues uncommitted into Task 2.

- Own the listed scope/lifetime/di-bag/types files, three compiler fixtures, registration, and provisional phase evidence.
- Write positive, negative, and declaration-consumer fixtures before checks. Preserve collection-aware `Overrides<R,O,K>`, public facade types, and original-program inference.
- Add exact option-bag types and expand overloads for `createChildContainer` and `createIndependentContainer`; old methods remain during expand.
- Reuse `snapshotOptionsBag`; do not reconstruct pre-collection replacement types.
- Preserve single/collection selection diagnostics, lifetime/sharing contracts, never/union behavior, and portable emitted declarations.
- Do not compile until the plan's fixture/overload set is complete. If S3 fails, use only the fully printed fallback after the three-attempt rule.
- Verify diff ownership and hand the entire unstaged set to Task 2. No commit.

## S3 fallback ruling after three failed candidates

Read the corrected fallback in the authoritative root plan07. Preserve both optional empty-bag/no-argument forms; only the replacement pair becomes positional. Independent runtime accepts 0/1/2 arguments, with its one-argument form limited to empty own options or undefined. Child's one-argument form is sharing-only. Its third argument uses the checked sharing property from CreateChildContainerOptions to retain transient/collection checks, and both Overrides helpers receive explicit renamed operation strings. Existing runtime selector preservation corrections apply unchanged.


## Controller update: e6df58b

The authoritative plan is /home/df/wd/personal/di-bag/docs/superpowers/plans/2026-09-21-07-container-renames.md (root next e6df58b), not this worktree's entry copy. S3 preferred bag failed all three serious candidates. Selected replacements are positional; preserve no-argument/empty-bag/undefined/share-only forms. Root plan explicitly records the independently reviewed fallback dependency annotations and four precise negative marker changes, preserving rejected bag evidence. Task5 goldens and mapped-role test now use positional pairs and a quoted `parent-keys` sharing field; Task7 current-call examples and inventory are positional. Compiler and declaration focused checks passed before additional required regression controls; cumulative measurement and combined review still pending at this update.
