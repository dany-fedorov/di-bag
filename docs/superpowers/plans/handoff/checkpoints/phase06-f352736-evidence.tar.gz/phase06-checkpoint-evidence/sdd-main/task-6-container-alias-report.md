# Task 6 Container alias prerequisite

Status: frozen for independent review on `e7aec0cd45dc5dc2d88c18827c1416b31a457b58`.

- Added the same type identity as `Bag` and `Container` in `src/di-bag.ts`, then re-exported both names from `src/index.ts`. There is no runtime value, wrapper, class rename, or constructor change.
- Extended the existing lifetime declaration producer with `Bag as LegacyContainer` beside `Container`, an exact identity assertion, a built-container assignment explicitly annotated `Container`, and an exact resolved value assertion. The local alias remains distinct after the Task 6 type rename.
- Meaningful RED `phase06-task6-container-alias-red`: both selected compiler tests failed because `../../src` did not export `Container`; 0 passed, 2 failed, no resource stop.
- Initial GREEN `phase06-task6-container-alias-types1`: lifetime source and emitted-declaration consumption 2/2, 6 assertions. Review found that the exported assignment still used `LegacyContainer`, allowing the emitted declaration to omit the new name.
- Final GREEN `phase06-task6-container-alias-types2`: after changing only that exported annotation to `Container`, lifetime source and producer-hidden emitted-declaration consumption remain 2/2, 6 assertions.
- `phase06-task6-container-alias-emit1` independently retained the emitted excerpt. It contains `export declare const defaultBag: Container<{`, proving the current name survives declaration emission; the script used the same TS 6.0.3 options as the test.
- `phase06-task6-container-alias-typecheck1` and `phase06-task6-container-alias-build1`: exit 0.
- Emitted declarations contain `Bag as Container` and the root `Container` re-export. `dist/di-bag.js` and `dist/index.js` hashes are byte-identical before and after the build.
- `phase06-task6-container-alias-physical1`: classic6/native7 CTS/MTS installed-package consumers with producer source deleted, 2/2 and 1,262 assertions; 164.03s, minimum 8.65 GiB, no resource stop. This matrix used the first fixture version, with `defaultBag: LegacyContainer`; the public source alias, identity assertion, and explicit `Container` import were already present. The final annotation is covered by `types2` and the retained `emit1` declaration.
- Final post-alias owner preview `phase06-task6-preview4-post-alias-final`: 135 files, 730 rewrites, 135 manuals; 10.00s, minimum 12.46 GiB, no resource stop. Its report is byte-identical to preview 3. Preview 2 had 731 rewrites; only `tests/types/lifetimes.ts` changes from 8 to 7 because its explicit current `Container` use needs no rewrite. Manual reason/text/file multiplicities are identical; its two reflected legacy method references move down three lines.

Artifacts:

- Candidate diff: `/tmp/di-bag-phase-06/task6-container-alias-final-r2.diff`, SHA-256 `660270e1fde85ece0a6120f41969d306dcb2ceb85fe89f4c1145c86c93c4cb9f`
- Preview report: `/tmp/di-bag-phase-06/task6-preview4-post-alias-final-report.txt`, SHA-256 `344fa69ce433e6f9382dc05210be0ec69472fbf341c2f8dd6edfdc181904d411`
- Preview comparison: `/tmp/di-bag-phase-06/task6-preview2-vs-preview3.txt`
- JS hashes: `/tmp/di-bag-phase-06/task6-container-alias-js-before.sha256` and `task6-container-alias-js-after.sha256`
- Emitted excerpt and script: `/tmp/di-bag-phase-06/task6-container-alias-emitted-excerpt.txt` and `emit-lifetimes-declaration.mjs`
- Guard logs and receipts: `/tmp/di-bag-resume-20260921/gates-phase00/phase06-task6-container-alias-{red,types1,types2,typecheck1,build1,physical1,emit1}.{log,json}` and `phase06-task6-preview4-post-alias-final.{log,json}`

No codemod write has run.
