# Task 9 — contract module and observer names

Authoritative range: plan07 lines 2065–2149. Continues the coherent contract tree.

- Add removed-name negative coverage, then delete `renameExport`, old observer interface/fields, and expand-only branches.
- Public surface keeps only `withRenamedExport`, `lifecycleObservers`, `onLifecycleEvent`, and `onObserverFailure`.
- Reword operation details to final method names while retaining existing runtime codes and message format.
- Run exact focused runtime/type/audit commands. No staging or commit; continue into Task 10.


## Controller update: 002d5f0

Read authoritative root plan07 at /home/df/wd/personal/di-bag/docs/superpowers/plans/2026-09-21-07-container-renames.md; its Task3/4/8/9 corrections supersede this entry brief and the worktree tracked plan. Task3 has explicit S5 snapshot overloads with never-rest on BOTH, per-operation RenameKeys default preserving legacy until contraction, exact runtime bag/getter checks and all three contributions fixtures plus emitted/physical declaration proof. Task4 owns immediate LifecycleObserver index export and retains object-only frozen callback snapshots plus legacy array text. Task8 removes inspectCollection and only an exact duplicate never control after migration; Task9 contracts RenameKeys default/constraint to the new operation. Root and independent reviews are recorded in the resume ledger.


Controller correction, 2026-09-22: Retain Task4 object-only observer validation in the contracted append body; callable observer records remain rejected. The focused API-removal filter is api-renaming (hyphen), not api renaming.


Controller correction, 2026-09-22: Only at Task9 contraction retire the two expand-only legacy/mixed observer positives. Retain all current callback/getter/mutation controls. The preserved both-fields payload now rejects retired observers through snapshotOptionsBag with INVALID_ARGUMENT / withConfiguration / options / only the own properties: runtime, lifecycleObservers. See authoritative root plan for exact expected details.


Controller correction, 2026-09-22: RenameKeys and InvalidRename use Operation extends string, matching Selection / InvalidSelection. Preserve the old renameExport default during expansion and change only the default to withRenamedExport at Task9; public methods keep exact operation arguments. Do not grow the naming ratchet or relax the scanner. Authoritative root plan supersedes the earlier literal-union constraint.
