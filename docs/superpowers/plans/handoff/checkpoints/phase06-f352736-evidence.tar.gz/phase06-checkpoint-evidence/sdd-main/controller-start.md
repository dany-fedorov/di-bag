# Phase 6 controller start

Entry: 324d4a7 on pushed next, including Phase 5 merge 5e0c362.
Phase 5 final source 8b33d7c and evidence 35abd19 pass every gate.
Read the current plan07 from this worktree; prepared brief line numbers are advisory.

The earlier heavy-command hold is lifted by the user. Current guard rules bind: one heavy lane, at least 8 GiB launch for focused checks/evidence and 12 GiB for full checks or whole-project codemod/compiler ownership proofs. Never lower guard stop limits or kill unrelated workloads.

Use unique phase06 guard labels, pinned Bun 1.4.0 and Node24.20.0. Dependencies are shared read-only via symlinks to phase05; do not run package installation or alter installed compilers. Known nested-spawn failures use the existing escalated guarded execution.

Author owns source and the heavy lane. Root owns root plans/handoff/integration; independent reviewers own scratch reviews. Never push, merge, publish or change final spec decisions. Required commit trailers apply. Review every task unit before committing; Tasks1–2 combine and Tasks8–11 combine.

Preserve phase5 explicit Builder invariance and witness, all seven public callable facades, positional token/replacement fallbacks, module list, collection read fallback, bilingual graph controls, and actual pinned runtime baseline739b509 version0.1.0.
