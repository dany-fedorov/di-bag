# Phase 6 S5 snapshot migration audit

Verdict: Task 6 currently misses the Phase 4 fallback spelling `inspectCollection`. The shipped map must remain the truthful original-0.4-to-final mapping `Bag.inspectAll -> serviceSnapshot`; a fictional `inspectCollection` source-map row or chained hop is not warranted.

## Engine evidence

- `tools/codemod/lib/rename-map.mjs:229-231` builds `callNames` and `memberNames` only from map-entry `from` names.
- `tools/codemod/lib/rewrite.mjs:286` returns before checker lookup when a called member is absent from `callNames`; lines 374 and 387 do the same for property and qualified-type references.
- `tools/codemod/rename-map.json:18` currently has only `from: "inspectAll"`; Task 5 correctly changes only its `to` value to `serviceSnapshot`.
- Therefore neither called nor uncalled `inspectCollection` members are rewritten or reported. `nameOf`/dispatch performs no transitive target lookup.

## Exact current inventory and ownership

- Task 6 typed inputs contain 26 textual rows across 11 files. Hand-migrate 23 rows to `serviceSnapshot`: `tests/collection-tokens.test.ts` (7, including the operation-detail literal), `tests/contributions-runtime-fixture.ts` (2), `tests/contributions.test.ts` (3), `tests/final-adversarial-runtime-fixture.ts` (1), `tests/nested-modules.test.ts` (1), `tests/observers-runtime-fixture.ts` (1), `tests/observers.test.ts` (1), `tests/types/collection-tokens.ts` (1), and `tests/types/negative/contributions.ts` (6). Preserve every negative marker and wrong-kind assertion while changing the operation spelling.
- The other three typed rows are the old reflected fixture: `tests/types/contributions.ts` exports `inspectCollectionMethod`; `tests/types/contributions-consumer.ts` imports and calls it. After Task 3 adds and consumes `serviceSnapshotMethod`, remove this redundant old export/import/call in Task 6 rather than manufacturing a second same-named export. The Task 3 direct and reflected `serviceSnapshot` controls remain the declaration proof.
- Task 7 must hand-migrate the one untyped executable call at `tests/acquisition-retention.node.mjs:48`; its printed regex rewrites `.inspect(` only and cannot see `.inspectCollection(`.
- Task 5 owns the two cumulative codemod expected outputs under `tools/codemod/test/fixtures/collection-tokens{,-import}/expected.ts`; their 0.4 inputs remain `inspectAll`.
- Task 11/normal documentation generation owns `docs/agent/api-card.md`, `docs/reference/api-coverage.json`, `docs/reference/index/interfaces/Bag.md`, and `tools/docs/test/exact-rendering.test.mjs`. The first three are generated; the exact-rendering assertion must follow final `Container.serviceSnapshot` output in its already planned owner.
- `src/di-bag.ts` keeps the old public compatibility method until Task 8; Task 3's new implementation may continue calling private `BagRuntime.inspectCollection`. `src/runtime.ts` is an internal runtime channel and is not renamed.
- `scripts/phase05-strings.py` is historical Phase 4 migration machinery whose replacement literals describe that phase. Classify it explicitly as historical evidence; do not execute or silently rewrite it as a current API call.

## Minimum plan correction

1. Add a Task 6 pre-write exact inventory for `inspectCollection` over its typed input roots. Record the 26-row baseline, the 23 hand replacements, and the three-row reflected-fixture fold separately from the checker report.
2. Perform those edits in the Task 6 migration unit and include all 11 files in its existing broad staging paths. Do not describe these rows as codemod-produced or as manual-report items.
3. Extend Task 6 Step 3's API grep to include `inspectCollection`; after the hand migration it must have no hits in `tests`, `examples`, `scripts/agent-eval`, or graph typed fixtures except an expressly listed negative input (none is presently needed).
4. Add the single `.node.mjs` hand edit to Task 7's explicit inventory and verification. Keep the private runtime spelling and historical script outside that public-call assertion.

No compiler, codemod, test, or source mutation was run for this audit.
