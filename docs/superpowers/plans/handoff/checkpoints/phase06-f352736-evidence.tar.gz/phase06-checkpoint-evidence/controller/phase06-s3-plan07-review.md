# Phase 6 plan 07 S3 fallback review

Read-only review of the current uncommitted `2026-09-21-07-container-renames.md` diff, focused on Tasks 3–12. No source, plan, compiler, or test command ran.

## Verdict

The selected positional call shape is propagated correctly through the Task 5 transform table, shipped golden, alternate-role test, Task 7 generated-string inventory, agent material, and final public examples. No replacement one-bag call remains in Tasks 3–12. The remaining `createChildContainer({ ... })` calls are the valid share-only form; multiline `preserved` and the two Task 7 canonical examples are positional.

The historical preferred-bag implementation at lines 1513–1599 is acceptably retained because lines 1494–1509 explicitly require replacing its three reachable pair branches with the printed positional branches. The entry probes and internal normalized selector bags likewise remain historical/implementation evidence, not public adoption.

## Exact checks

- Golden trivia is coherent: `child3` emits `keys /* k */, replacements /* p */, { sharedParentServiceKeys: ['b'], }`; `preserved` retains both argument comments and trailing commas; `nested` remains positional while its nested builder transform composes.
- The alternate role test correctly exercises only the emitted sharing role. `chosenKeys` and `providerMap` remain declaration-backed metadata but are not rendered under the positional fallback; quoted `"parent-keys"` is rendered in the third bag.
- Both regexes at lines 1729–1733 match the exact printed strings, including comment delimiters, quoted sharing key, one space after `{`, trailing comma, closing braces, and semicolon.
- Task 7's four nonempty generated replacements are positional; zero-argument calls remain unchanged. The benchmark current adapter uses only zero-argument child creation, and the pinned `739b509` branch remains excluded and byte-preserved.
- Final prose correctly preserves no-argument, `{}`, explicit-`undefined`, and child share-only forms, while distinguishing exported normalized option types from replacement method arguments.

## Two narrow prose corrections

1. Line 1513 still calls the retained code the “complete adopted-shape implementation.” Rename this to “complete historical preferred-bag implementation” so it cannot be mistaken for executable final guidance; the following positional replacement instruction remains authoritative.
2. The type-consistency paragraph at line 2397 says `Overrides<R,O,K>`, but both selected overloads now deliberately pass the fourth operation argument. Spell this `Overrides<R,O,K,Operation>` (or the two exact literal operations) so the summary matches the printed signatures and their diagnostic-priority repair.

These are plan-consistency defects only. The actual positional golden, regexes, ownership, and public call inventory are sound.
