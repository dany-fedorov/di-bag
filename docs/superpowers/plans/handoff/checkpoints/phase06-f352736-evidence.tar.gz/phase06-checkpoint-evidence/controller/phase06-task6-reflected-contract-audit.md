# Phase 6 Task 6 reflected-contract audit

## Finding

**Important — current adaptation no longer proves the imported reflected child overload.**

`tests/types/lifetimes.ts` now exports `reflectedScopeResult = graph.createChildContainer()` and `reflectedForkResult = graph.createIndependentContainer()`. Those direct calls repeat the already covered `scoped`/`independent` method calls; neither consumes `reflectedScope` nor `reflectedFork`. In `lifetimes-consumer.ts`, exact result assertions therefore pass even if declaration emit or overload ordering makes the extracted `reflectedScope` zero-argument call unusable.

The old `ReturnType<typeof reflectedScope>`/`Parameters<typeof reflectedScope>` assertions cannot be carried literally because utility types inspect the final overload, which is now the positional replacement overload rather than the zero-argument overload. Dropping those incidental utility results is appropriate; dropping reflected-call coverage is not.

## Minimal correction

- Remove `reflectedScopeResult` and `reflectedForkResult` from the producer and consumer; they add only direct-method coverage.
- In the producer-hidden consumer, add a never-invoked wrapper:

```ts
const callReflectedScope = () => reflectedScope();
```

- Assert `Assert<Equal<ReturnType<typeof callReflectedScope>, typeof graph>>`. This forces zero-argument overload resolution through the imported emitted declaration without executing a detached runtime method.
- Retain `Assert<Equal<IsAny<ReturnType<typeof reflectedScope>>, false>>` and the existing `reflectedFork` IsAny control. Do not alter public overloads, never guards, or negative fixtures for this adaptation.

The type-test harness compiles/emits producer and consumer programs; it does not execute this wrapper. Only the focused lifetime declaration/source checks need rerunning for this fixture-only correction.
