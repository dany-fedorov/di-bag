# Phase 6 Task 6 command/scope review

Verdict: **One Important command-coverage gap; the new provenance paragraph is approved.**

## Finding

The printed preview/write command does not cover its stated scope. Root `tsconfig.json` includes only `src`, `tests`, and `examples`; no file in `scripts/agent-eval/**` or `tools/graph/test/fixtures/**` is imported by those project roots. Adding only `tests/types/negative/*.ts` therefore leaves the agent-eval calls and current graph fixtures untouched and unreported.

Use the same additional roots in preview, write, and the exact command copied into the commit body:

```sh
--extra-files 'scripts/agent-eval/**/*.ts' \
--extra-files 'tools/graph/test/fixtures/ready-chain.ts' \
--extra-files 'tools/graph/test/fixtures/split-builder.ts' \
--extra-files 'tools/graph/test/fixtures/cross-module/*.ts' \
--extra-files 'tools/graph/test/fixtures/consumer/src/**/*.ts'
```

This adds all 31 agent-eval TypeScript files and the 13 current graph-program files. Imports from those roots remain available to the checker, including files without direct renamed calls.

Preserve both explicit graph compatibility fixtures outside this write set: `builder-names-0-4.ts` is the deliberate original-0.4 extractor input, while `builder-names-0-5.ts` is already the current untyped/declaration-free counterpart and needs no codemod rewrite. The `split-builder.ts` cycle/missing-service rejection stays included: its negative graph semantics remain intact while its ordinary public calls/import migrate.

Keep `tests/types/negative/*.ts` as the existing separate extra root. Its diagnostic cases are migration inputs whose expressions change while markers remain; it is not a reason to exclude the current graph rejection fixture.

## Provenance paragraph

The new Step 4 paragraph is sound. It requires preservation of the exact checker patch and separate hand patches, permits a mechanical-only commit only after that intermediate tree passes its gates, and otherwise requires one coherent tested commit with accurate attribution. It also explicitly prevents attributing the hand-only `inspectCollection` migration to the checker. This resolves the heading/commit-template ambiguity without weakening the single-write rule or authorizing an unverified red commit.

No compiler or source mutation was run for this audit.

## Downstream contract corrections

- **Task 8 approved:** `inspectCollection` is now named in the produced-contract list, the runtime absence array, and the negative member fixture. This turns the existing prose deletion into executable runtime/type obligations. Making the runtime test async and closing its container restores ownership hygiene without weakening any absence assertion.
- **Task 9 approved:** the contracted `LifecycleObservers.append` guard now keeps Task 4's object-only boundary (`typeof observer !== 'object' || observer === null`). It continues to reject callable objects carrying callback properties and preserves the frozen single-read callback record; no compatibility surface remains at contraction to justify function acceptance.

## Re-review closure

**Addressed; final verdict: Approved with no open findings.** The authoritative plan now carries the exact five additional `--extra-files` arguments in the preview command, the sole write command, and the command recorded in the commit body. Its preview expectation records all 31 agent-eval roots and 13 current graph roots, preserves both `builder-names` compatibility fixtures outside the write, and explicitly keeps `split-builder.ts` in scope with its graph rejection semantics unchanged. The three command sites are identical apart from preview/report/write flags, so provenance can be reproduced exactly.
