# Phase 6 S3 downstream-plan review

## Finding

1. **Important — plan 11 reintroduces the explicit-empty replacement validation bypass.** In `2026-09-21-11-singleton-default.md` Step 4, the complete `selectChildContainer` body destructures only `{ selected, providers }` and skips `selectedBindings` when `selected.length === 0`. Phase 6 deliberately changed `replacementPair` to return `present` so an explicitly supplied empty positional pair still validates that `replacementProviders` is an object. Because plan 11 replaces the complete selector, this would regress the reviewed Task 2 boundary. Destructure `{ present, selected, providers }` and use `const bindings = present ? selectedBindings(claimedGraph, 'createChildContainer', selected, providers) : [];`. Keep the claimed graph and new singleton loop unchanged.

## Verified scope

- Ordinary replacement calls in plans 09, 11, 12, 13 and 14 use the selected positional pair; child sharing remains the optional third bag. No-argument, `{}`, explicit `undefined` and share-only forms remain documented.
- Plan 11's remaining replacement bags are intentionally bounded: one direct `CreateChildContainerOptions` type fixture proves property-local admission, and the lifetime-codemod scratch library explicitly exposes both custom shapes. Its comments correctly say those calls are non-shipped synthetic input.
- The runtime invalid-argument rows exercise malformed positional keys/providers and the child's third-bag allowlist. Unknown replacement, missing provider, overlap and transient-sharing rows retain meaningful distinct failures.
- The normalized option aliases remain available for internal/type-level use without restoring replacement-bag method overloads. The patch makes no S5, baseline `739b509`, measurement or budget claim and does not alter pinned historical inputs.

## Verdict

Not ready until the plan 11 complete selector carries Phase 6's `present` discriminator. No other blocking propagation issue found in the five-plan patch.

## Fix re-review

Reviewed patch SHA-256 `f3127d785b002fa2572bd96d13099d74597528425cca05900dd37c747f5cb6dc` changes exactly the affected plan 11 selector flow: it destructures `present` and calls `selectedBindings(claimedGraph, ...)` whenever the pair is present. The claimed graph, singleton rejection loop and return path are unchanged. `git apply --check` passes. **Important finding closed; five-plan S3 propagation approved.**
