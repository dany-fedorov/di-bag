# Phase 6 Task 6 `Container` prerequisite audit

Verdict: **Confirmed blocking prerequisite gap.** Task 6 cannot finish green with the current exports.

## Evidence

- `src/di-bag.ts:128` still declares `class Bag`; line 831 exports only `Bag, Builder`.
- `src/index.ts:4` re-exports only `Bag, Builder, DiBagApi, ConfigurationOptions`.
- No source declaration or export named `Container` exists before Task 8.
- The shipped map already has `types: Bag -> Container`. Task 6 therefore rewrites real imported annotations to a name the dual-surface library does not export.
- Eight checked fixture files currently import/use the public `Bag` type and are Task 6 migration inputs: positive `tests/types/{boundaries,container-derivation,lifetimes}.ts` plus negative `builder-views`, `contributions`, `module-narrowing`, `scopes`, and `selected-scopes`. Task 7 also changes the generated package consumer string from `Bag` to `Container` before Task 8.
- The plan states that the class remains named `Bag` through migration and is renamed only after call sites move, but it contains no earlier `Container` alias step. This is an execution contradiction, not an optional convenience.

## Minimal additive correction

Before the Task 6 write, export the same type identity under both names:

```ts
// src/di-bag.ts
export type { Bag, Bag as Container, Builder };

// src/index.ts
export type { Bag, Container, Builder, DiBagApi, ConfigurationOptions } from './di-bag';
```

This emits no runtime value, does not duplicate or wrap the class, leaves every return/`this` type and constructor identity as `Bag`, and keeps the old export available for checker authentication and unmigrated compatibility. Task 8 can still rename the class and replace the dual export with `export type { Container, Builder }` while removing `Bag` exactly as planned.

## Required proof

1. Before the write, add a focused compiler/source fixture that imports `Bag as LegacyContainer` beside `Container`, proves `Equal<LegacyContainer<R>, Container<R>>`, assigns a built container, and checks its `resolve` result. The local alias prevents the later `Bag -> Container` rewrite from creating duplicate local imports (`Container as LegacyContainer` remains distinct from `Container`). A qualified type query is also safe.
2. Run source typecheck and build. Inspect `dist/di-bag.d.ts` for `Bag as Container` and `dist/index.d.ts` for the `Container` re-export; confirm JS output and runtime exports remain unchanged.
3. Preserve an unchanged post-alias migration preview as owner-authentication evidence, then after the Task 6 write run the affected positive/negative compiler fixtures so every rewritten `Container` import and diagnostic marker is exercised.
4. Run the existing focused classic/native installed-package producer-deletion matrix (`native installed contracts and physical downstream declarations`). Once the fixtures are rewritten, it proves the root `Container` export through emitted declarations, CTS/MTS consumers, and absence of producer source.
5. Keep the ordinary Task 6 typecheck/build gates. No migration gate should be weakened or replaced by declaration greps alone.

No source edit or compiler was run for this audit.
