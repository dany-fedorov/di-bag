import assert from 'node:assert/strict';
const excluded = /(?:api-renaming\.ts|docs\/agent\/api-card\.md$|tests\/benchmarks\/runtime-scenarios\.ts|scripts\/runtime-benchmark-child\.ts|tools\/codemod\/test\/fixtures|tools\/graph\/test\/fixtures\/.*0-4|tools\/graph\/test\/renamed-exports\.test\.mjs$|tests\/container-names\.test\.ts$|tests\/fixtures\/api-naming\/)/;
const retired = /\.(?:createScope|fork|inspect|inspectCollection|inspectGraph|renameExport)\(|\b(?:ScopeOptions|CheckedScopeLifetimes|DisjointScopeSelection|ObserverOptions)\b|\b(?:observers\s*:|onEvent\s*[:(]|onError\s*[:(])/g;
for (const file of ['tools/graph/test/renamed-exports.test.mjs','tests/container-names.test.ts','tests/fixtures/api-naming/src/surface.ts','docs/agent/api-card.md','tests/benchmarks/runtime-scenarios.ts','tools/graph/test/fixtures/builder-names-0-4.ts','tests/types/negative/api-renaming.ts']) assert.equal(excluded.test(file), true, file);
for (const file of ['tests/observers.test.ts','docs/agent/recipes.md','tools/graph/test/cross-module.test.mjs']) assert.equal(excluded.test(file), false, file);
for (const value of ['observers: []','onEvent: fn','onError: fn','onEvent() {}','onError (error) {}']) { retired.lastIndex=0; assert.equal(retired.test(value), true, value); }
for (const value of ['lifecycleObservers: []','onLifecycleEvent() {}','onObserverFailure: fn']) { retired.lastIndex=0; assert.equal(retired.test(value), false, value); }
console.log('Helper exclusion and callback audit controls pass');
