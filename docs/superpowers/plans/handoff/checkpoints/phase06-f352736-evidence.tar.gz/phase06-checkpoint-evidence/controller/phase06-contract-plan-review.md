# Phase 6 contraction plan correction review

**Verdict: Approved.** No Critical, Important, or Minor findings.

Reviewed the current plan-07-only diff against `/tmp/di-bag-resume-20260921/phase06-contract-entry-audit.md` (SHA-256 `509c0d4d0fa87db6907498423a078b9dabd1ca7e532ff1093a8319b7e919c87b`) and the referenced current files.

- Task 8 now names `tests/types/lifetimes.ts` in its ownership list, matching the explicit retirement of `Bag as LegacyContainer` and `ContainerAliasIdentity` while preserving the meaningful final `Container` and reflected-consumer assertions.
- Task 10 now owns `scripts/verify-release-artifacts.ts` and states the exact final contract: only the root `dist/index.{js,d.ts}` pair is required, `node` joins `sas-box` and `val-box` as a forbidden removed entry, and the export map is exactly root-only.
- The package and release tests retain both sides of that contract. They require the root pair, reject both node files, exercise all three removed names with both `js` and `d.ts`, and preserve the missing-public-export control by deleting `dist/index.d.ts` rather than the retired node declaration.
- These changes preserve archive-byte, dependency, metadata-shape, malicious-archive, and missing-file controls. The existing root-import-graph rejection of `node.js` remains intact.
- Task 11 explicitly deletes the one `di-bag/node` API-reference table row whose generated target is removed. It neither invents a replacement link nor broadens the allowed guide edit beyond the affected row.

The corrections are bounded, internally consistent, and ready to commit with the related ledger update.
