# Phase 6 Task 7 helper entry audit

Scope: static review of plan 07's printed `reshape-untyped.mjs` against the protected post-Task-6 inputs. The helper was not executed.

## Required exclusions

1. `tools/graph/test/renamed-exports.test.mjs` must be excluded as a whole. Its positional `.renameExport('clock', 'time')` is the required mixed-generation 0.4/current parser control. The context-free rule at plan lines 1951–1952 would turn it into a second current call and erase the compatibility proof.
2. `tests/container-names.test.ts` must be excluded after Task 6. Task 6 restores and preserves all three expand-only observer controls through Task 9: the legacy positive, the mixed legacy/current positive, and the deliberate `{ observers: [], lifecycleObservers: [] }` both-field rejection. Rewriting them would erase the compatibility cases and turn the rejection into duplicate `lifecycleObservers` keys.
3. `tests/fixtures/api-naming/**` must be excluded. `src/surface.ts:41` deliberately declares `onEvent` as an abbreviation finding asserted by `tests/api-naming.test.ts`; changing the fixture invalidates that independent naming test rather than migrating a DI Bag call.

Add those three path predicates to `excluded`; do not weaken or remove the existing `api-renaming`, generated API card, benchmark adapter, codemod fixture, or graph-0.4 exclusions.

## Required prior-repair verification

The callback declaration rules do not rewrite property references. Task 6's coherent observer migration therefore owns changing the `tests/observers.test.ts` mutation from `options.onEvent` to `options.onLifecycleEvent`; the moving Task 6 tree already contains that repair. Task 7 must verify the prior repair is present before running the helper, rather than edit it again. A global `.onEvent` replacement would be less safe and is unnecessary; the corrected Task 7 entry has no such old member reference in the helper scope.

## Verification correction

Both `retired` and the Step-5 callback grep currently match only `onEvent:`/`onError:` property syntax, while the helper also rewrites method syntax `onEvent(`/`onError(`. Change those audit patterns to `\b(?:observers\s*:|onEvent\s*[:(]|onError\s*[:(])` (or equivalent), then classify the three excluded controls by exact path and expected text. This makes the inventory prove method-shorthand cleanup without treating the exclusions as zero-count inputs.

No other concrete protected match appeared in the reachable helper scope. Ordinary package/runtime strings, authored agent docs, runtime-scale observer calls, and observer fixtures are current-call migrations; `tests/api-renaming.test.ts`, the generated card, bilingual benchmark adapter, codemod inputs, and graph 0.4 fixtures are already excluded for their stated compatibility roles.
