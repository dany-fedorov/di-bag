# Phase 6 Task 6 operation naming audit

## Result

The narrow source fix is safe:

```ts
export type RenameKeys<P, Old extends string, New extends string, Operation extends string = 'renameExport'> = ...
type InvalidRename<Operation extends string> = ...
```

## Contract analysis

- `renameExport` relies on the existing default; `withRenamedExport` passes `'withRenamedExport'` explicitly at both option properties. No method call infers `Operation` from user data.
- `InvalidRename` receives only that selected type parameter and interpolates it into the diagnostic. Therefore public method diagnostics remain exactly operation-specific.
- `RenameKeys` and `InvalidRename` are not exported from `src/index.ts`. `RenameKeys` appears transitively in the `Module` declaration, but package-root consumers cannot supply an extra operation argument through either method signature.
- This matches established `Selection`/`InvalidSelection` and related helpers, which use `Operation extends string` while methods provide an exact default or type argument.
- The scanner intentionally exempts method labels carried by a type parameter named `Operation` at defaults and type-argument sites. Widening the internal constraint removes the duplicate enum-like spelling without adding a known violation or weakening ordinary value scanning.

## Required preservation

- Keep the expand default `'renameExport'` until the legacy method is removed.
- Keep both explicit `'withRenamedExport'` arguments and the negative diagnostics proving the new method name.
- At Task 9 contraction, change the default to `'withRenamedExport'`. Update the plan wording that currently says to remove `'renameExport'` from a union constraint; after this fix the constraint is already `string`, so only the default and legacy method/diagnostic surface change.

**Verdict:** Approve the two `extends string` edits. No scanner, ratchet, or broader source change is warranted.
