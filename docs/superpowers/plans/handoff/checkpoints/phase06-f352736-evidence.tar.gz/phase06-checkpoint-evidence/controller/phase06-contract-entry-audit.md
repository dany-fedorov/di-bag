# Phase 6 Tasks 8–11 contraction entry audit

Scope: authoritative plan 07 Tasks 8–11 versus the current Phase 6 source, package tests, physical declaration matrix, and documentation layout. No source, compiler, build, or test command was run.

## Concrete corrections

1. **Task 8 omits an owned fixture from its Files list.** Plan lines 2098–2102 do not list `tests/types/lifetimes.ts`, but Step 2 at line 2159 explicitly removes its `Bag as LegacyContainer` import and `ContainerAliasIdentity` assertion while preserving `defaultBag: Container`, `ContainerAliasValue`, and reflected derivation methods. Add `tests/types/lifetimes.ts` to Task 8's Files list. The final broad `git add tests` would stage it, but the current ownership declaration is internally incomplete.

2. **Task 10 must own the production release verifier and its archive-assertion transitions.** The general instruction at plan line 2318 is directionally correct, but `scripts/verify-release-artifacts.ts:116–119` still encodes the old package contract. Add that script to Task 10's Files and require these exact changes: require only `dist/index.js` and `dist/index.d.ts`; reject `dist/node.js` and `dist/node.d.ts` through the same removed-entry check as `sas-box`/`val-box`; and set `expectedExports` to exactly `{ '.': { types: './dist/index.d.ts', default: './dist/index.js' } }`. The adjacent verifier scan found no other hard-coded public-export assumption: line 205 already rejects `node.js` in the root import graph and remains correct.

   Preserve and extend its tests rather than merely making current expectations green:
   - `tests/package.test.ts:47–49` currently requires all four root/node files. Change it to require `dist/index.{js,d.ts}` and explicitly reject `dist/node.{js,d.ts}`; otherwise deleting the positive node list can silently lose the packed-file absence assertion.
   - `tests/release-artifacts.test.ts:650–653` currently proves a missing public declaration by deleting `dist/node.d.ts`. After the node export is removed, preserve that negative test by deleting `dist/index.d.ts` instead (and rename its artifact label). Exercise the removed-entry check for every product of names `node`, `sas-box`, `val-box` and extensions `js`, `d.ts`; the current test covers only the two adapter JS files. Require the verifier's removed-entry failure for each. Do not merely delete the missing-export case; it is the only assertion in that block that a declared public export pair must exist.

3. **Task 11 must name the guide row made dead by Task 10.** `docs/guides/api-reference.md:15` links `di-bag/node` to `../reference/node/index.md`, while Task 10 deletes that tree and Task 11's docs gate checks links. Under the already allowed generated-page-row scope at plan lines 2393–2395, explicitly delete that one node-entry table row. Do not repoint it to the root reference: that would claim the retired entry still exists. The remaining guide prose stays deferred to phase 12 under the master boundary.

## Checked and sound

- Task 8 explicitly retains all seven exported callable facades and the `builder-renames` producer/declaration-consumer matrix; Task 10 runs the native package matrix after root-entry migration.
- Task 8 preserves direct and reflected snapshot never guards; Task 11 preserves both ordinary and collection `serviceSnapshot` exact-rendering assertions.
- Task 9 retains the corrected `Operation extends string`, contracted default, explicit fourth diagnostic argument, callback/getter/freeze controls, and phase-11 lifecycle-event fields.
- Task 10 contracts TypeDoc and coverage to the root entry; Task 11 stages both generated index output and the already tracked node-reference deletion.
- Task 11's six-entry naming-ratchet count matches the current violations: four exports plus `createScope` and `fork`.
