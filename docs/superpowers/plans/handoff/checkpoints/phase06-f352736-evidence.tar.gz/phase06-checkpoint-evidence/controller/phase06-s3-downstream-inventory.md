# Phase 6 S3 positional-fallback downstream inventory

Read-only inventory against root plans 07–14. This applies only after the final S3 fallback is verified and measured. No compiler, test, or plan edit ran.

## Canonical projection

- Replacement child: `createChildContainer({ replacedServiceKeys: keys, replacementProviders: providers })` becomes `createChildContainer(keys, providers)`.
- Replacement plus sharing: the same bag becomes `createChildContainer(keys, providers, { sharedParentServiceKeys: shared })`.
- Independent replacement: `createIndependentContainer({ replacedServiceKeys: keys, replacementProviders: providers })` becomes `createIndependentContainer(keys, providers)`.
- Preserve `createChildContainer()`, `createIndependentContainer()`, and share-only `createChildContainer({ sharedParentServiceKeys })` exactly. The optional third bag may contain only `sharedParentServiceKeys`.
- Keep operation names, diagnostic details, provider expressions, token keys, collection-read fallback, comments, and provider-marker locations unchanged. Only the call boundary moves.

## Plan 07: current phase, Task 3 onward

- **Task 5 codemod** (`2026-09-21-07-container-renames.md:1469-1482`): the fallback branch already states the right three positional outputs. Resolve the preceding adopted-output table to the fallback rather than leaving both as current API.
- **Task 5 golden** (`:1641-1667`): convert `child2`, `child3`, `preserved`, `nested`, and `fork1`; retain `child0`, `child1`, `fork0`, and the direct `CreateChildContainerOptions` type aliases. The exact comment-preserving assertions at `:1721-1725` must expect positional arguments and the third sharing bag.
- **Task 6 typed write** (`:1741-1798`): no separate shape is printed, but its post-write assertions and classification must use the selected fallback emitted by Task 5.
- **Task 7 untyped/generated inventory** (`:1878-1893`): change the four nonempty exact replacements in `tests/token-package.test.ts` and `tests/package.test.ts` from bags to positional pairs. Zero-argument rows stay unchanged. `tests/compiler.ts` and the three compiler scripts must receive the same positional current API.
- **Task 7 agent/docs material** (`:1919-1933`): canonical child example becomes `createChildContainer(['request'], { request: ... }, { sharedParentServiceKeys: ['client'] })`; independent becomes `createIndependentContainer(['clock'], { clock: ... })`. Task-name JSON rows remain method-only and need no change.
- **Task 8 exports** (`:2033-2045`): retain both spec-mandated option type exports, but do not describe `CreateIndependentContainerOptions` as a callable one-bag overload. `CreateChildContainerOptions` remains useful for the share-only overload and direct property-admission fixtures. The sentence at `:2045` is valid only for sharing-only use.
- **Task 11 rendering/self-review** (`:2241-2249`, `:2385`): substitute the measured positional signature text and replace “one-bag overloads”/field-based method claims with positional pair plus optional sharing bag. TypeDoc may still render the two exported option types; it must not imply a replacement-options overload.
- The fallback implementation deliberately normalizes positional arguments into the internal `{ replacedServiceKeys, replacementProviders, sharedParentServiceKeys }` selector object (`:461-509`). That internal bag and `scope-selection.ts` code are not migration targets.

## Later plans

- **Plan 08** (`2026-09-21-08-requirement-renaming.md:41-45,440,1097`): no call-shape change. These are retained type/name audits.
- **Plan 09** (`2026-09-21-09-provider-sources.md:20,75-86,3201`): retain the inherited `CreateChildContainerOptions` definition and generic order. Add an explicit note that this type does not restore a replacement one-bag method overload under S3 fallback. No printed container replacement call exists.
- **Plan 10** (`2026-09-21-10-provider-methods.md:760`): the only call is `createChildContainer()`; preserve it.
- **Plan 11 Task 1 runtime** (`2026-09-21-11-singleton-default.md:151-235`): move all replacement calls and cast-bypassed rejection calls to positional arguments. Casts must accept `(...args: unknown[])`, not `(options: object)`. Zero-argument child calls stay.
- **Plan 11 Task 2 source/negative fixtures** (`:486-525`, `:585-646`): make child/independent replacements positional; keep the share-only `sharedChild` bag. The existing fallback paragraph at `:634` is incomplete: it mentions only two child calls, but the valid child and independent controls at `:623-631` also need positional form. Preserve the direct `CreateChildContainerOptions` negative at `:637-645` for property-local admission.
- **Plan 11 Task 3 codemod fixture** (`:1134-1176`): both preferred-S2 and fallback-S2 goldens need positional child/independent calls. The synthetic dual-shape transformer test at `:1789-1866` may keep a bag branch only if labeled a non-shipped custom-map compatibility input; current API fixtures and expected output must be positional.
- **Plan 11 Task 4 docs** (`:2415-2427`): request-container recipe becomes positional plus no third bag.
- **Plan 11 Task 6 fallback contract** (`:2910-3019`): every replacement/rejection call becomes positional, including token, alias, collection, source, and negative fixtures. Keep `createChildContainer()` unchanged; retain the S5 `resolveCollection` substitutions independently.
- **Plan 12 Tasks 6–7** (`2026-09-21-12-observability-and-errors.md:1080-1085,1211-1218,1258-1287`): unknown-key, missing-provider, conflict, and documentation examples use positional pairs; conflict passes sharing as the third bag. Share-only unknown/transient controls remain bags.
- **Plan 12 Task 9** (`:1468-1473,1550-1555`): the prose already says the old mixed form is gone, but printed invalid-argument calls are stale. Test `createChildContainer('bad', {})`, `createChildContainer(['config'], 42)`, third-bag unknown option via `createChildContainer([], {}, { other: [] })`, and the analogous two positional independent cases. Preserve expected argument/detail names.
- **Plan 13** (`2026-09-21-13-guides-and-readme.md:26-35`): the global S3 rule is correct. Fix the explicit enterprise-guide instruction at `:714` to positional independent replacement. Tasks 4–9 and README examples then follow the checklist.
- **Plan 14 Task 1** (`2026-09-21-14-migration-and-release.md:153-167`): stub-generator replacement text must advertise `createIndependentContainer(replacedServiceKeys, replacementProviders)` and `createChildContainer(replacedServiceKeys, replacementProviders, { sharedParentServiceKeys })`, while mentioning zero/share-only forms where relevant.
- **Plan 14 release prose** (`:1019-1027`): replace “each with one options bag” with the selected positional pair/optional sharing form. Migration-guide examples and acceptance stubs must use the same shapes.

## Boundaries and ruling

- `CreateChildContainerOptions` and `CreateIndependentContainerOptions` remain named by the binding spec (`swift-api-style.md:344`) even when S3 selects positional calls. Their export is not evidence of a public replacement-bag overload. Generated reference/API-card prose must state that distinction.
- The S5 collection fallback is orthogonal: retain `resolveCollection` and the final collection snapshot name exactly. Moving replacement arguments must not alter token/provider keys or collection result types.
- `tests/benchmarks/runtime-scenarios.ts` uses only the current adapter’s zero-argument child operation; rename it to zero-argument `createChildContainer()` and leave the pinned-`739b509` baseline adapter byte-for-byte. `scripts/runtime-benchmark-child.ts` lane/entry selection is unchanged.
- No contradiction requires changing the fallback runtime normalization or codemod owner (`Bag`). The concrete contradiction is stale public bag syntax and claims after the decision; resolving every location above preserves zero/share-only forms and the historical/custom fixtures explicitly classified as such.
