# Phase 6 positional-fallback type audit

## Finding

No accidental admission or return-type difference exists between the entry positional methods and the new fallback declarations. After identifier substitution, `createIndependentContainer` matches `fork` across the recursive provider bound, `Record`, `Overrides`, dependency checks, constraints, lifetime check and return projection; `createChildContainer` likewise matches selected `createScope`, with only the intended operation names, renamed lifetime alias and checked sharing option. Removing the explicit `Overrides` or `Selection` operation labels therefore cannot repair the failure.

The concrete difference is in the new fixture's expectation. Its replacement factories destructure dependencies without parameter annotations. The current-tree legacy control proves `fork` / `createScope` also emit TS7031 for that form; the positional API never supplied the contextual dependency inference that all three rejected S3 bag candidates were intended to add. Once one factory has an implicit-`any` dependency, the whole replacement graph fails dependency admission, and its error intersection makes every provider property appear assignable to `never`; the sibling no-dependency errors are cascade effects rather than independent provider failures. Removing all admissions hides that graph failure but correctly leaves the missing context and wrong exact-output assertion.

## Bounded correction

- Do not change the fallback declaration shape or remove admissions.
- In the fallback-only positive fixture, annotate each destructured replacement dependency with the inferred selected graph contract, as existing positional `fork` / selected `createScope` fixtures do: the named `clock`, computed token provider and collection provider each use `{ value: number }`.
- Annotate the incomplete negative provider as `({ missing }: { missing: number }) => missing`; this preserves the intended missing-registration diagnostic instead of letting TS7031/invalid-provider admission mask it.
- Keep exact return assertions for richer replacement outputs. Run the existing focused positive, declaration-consumer and negative-marker checks; also retain a same-tree legacy positional control or cite its raw log to document why annotation is the selected fallback boundary.

## Verdict

The fallback declarations preserve the entry positional type contract. The failing expectation belongs to the rejected S3 contextual-inference surface and must not drive a fourth signature experiment. Explicit dependency annotations are the narrow, established positional fallback requirement; output inference, provider compatibility and every graph admission remain checked.

The follow-up explicit-context intersection probe confirms the boundary: duplicating `OverrideFactoryContext<R,K,O>` on the provider parameter stack-overflows the checker with the full admissions and was reverted. The reviewed runtime normalization independently passes 20 cases / 42 assertions. Neither result supports changing the selected positional type shape.

## Negative-marker audit

The fallback raw program reports exactly nine diagnostics at the nine invalid calls. Five preferred messages still win unchanged (unknown selection, overlap, unknown sharing, root capture and transient sharing). Four calls are rejected earlier by the legacy positional `OverrideFactoryContext` / required-record boundary, so their S3-era semantic markers cannot appear. Replace only those four markers with source-shape-specific legacy diagnostics:

- Named wrong output: `Type '() => string' is not assignable to type`
- Missing selected provider: `Property 'b' is missing`
- Token wrong output: `Type of computed property's value is '() => { now: string; }'`
- Missing dependency: `Type '({ missing }: { missing: number; }) => number' is not assignable to type`

These are exact prefixes from TS2322, TS2345 and TS2418 in the retained raw log, and match the established precision used by `selected-scopes.ts` and `fork-missing.ts`. They identify the concrete provider or missing property rather than weakening to a generic `not assignable`. Keep every expression and admission unchanged; the marker parser requires one matching substring within each marker-to-next-marker line interval, so these four replacements account for the four existing diagnostics without suppressing extras.
