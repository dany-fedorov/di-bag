# Phase 6 Task 7 helper/contract plan review

Scope: current root `2026-09-21-07-container-renames.md` diff against `/tmp/di-bag-resume-20260921/phase06-task7-helper-entry-audit.md` and the Phase 6 source contracts.

## Findings

No open findings.

## Helper boundary

- The exclusion regex exactly protects `tools/graph/test/renamed-exports.test.mjs`, `tests/container-names.test.ts`, and `tests/fixtures/api-naming/**` while retaining the prior API-renaming, generated-card, benchmark, codemod, and graph-0.4 exclusions.
- Excluding the graph test preserves its required positional/current mixed chain. Excluding `container-names.test.ts` protects the legacy positive, mixed old/new positive, and both-fields rejection until Task 9. The naming fixture exclusion preserves an intentional independent abbreviation finding.
- The plan requires separate path/text/hash accounting for excluded controls, so they cannot be presented as zero-count migrated inputs.
- Both the helper inventory and later audits now match callback property and method syntax: `observers:`, `onEvent:`/`onEvent(`, and `onError:`/`onError(`. This closes the method-shorthand blind spot without adding a permissive global member rewrite.
- Verifying the Task 6 `options.onLifecycleEvent` mutation before helper execution is correct: declaration regexes cannot safely migrate property references, and Task 6 owns that coherent indirect-record change.

## Contraction boundary

- Task 9 retires only the two expand-only legacy/mixed positive tests. It explicitly retains current callback, getter, mutation, malformed-record, and delivery controls.
- Keeping `{ observers: [], lifecycleObservers: [] }` after contraction is a meaningful retired-key payload. Once `observers` leaves the supported option list, `snapshotOptionsBag` rejects it before the old conflict branch with code `DI_BAG_INVALID_ARGUMENT` and details `{ operation: 'withConfiguration', argument: 'options', expected: 'only the own properties: runtime, lifecycleObservers' }`; the plan's expected order matches the optional-key order.
- The final callback audits and exact-path compatibility classification remain separate from private runtime inspection exemptions.

**Verdict:** Approved. The delta preserves all expand controls through their assigned owner and gives Task 9 an exact, nonweakened contraction assertion.
