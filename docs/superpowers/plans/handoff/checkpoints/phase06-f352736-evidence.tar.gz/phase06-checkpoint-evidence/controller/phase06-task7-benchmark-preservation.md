# Phase 6 Task 7 bilingual benchmark preservation

Read-only comparison against committed `594e91c` and the moving Phase 6 tree. No source or scratch implementation and no runtime/compiler gate was run.

## Entry state

At inspection time, the first three owned files byte-match `594e91c`: `tests/benchmarks/runtime-scenarios.ts` `c7fa99619f03210583a03ceb49b72a7b21326aa217e6b7854154c410d5640885`, `scripts/runtime-benchmark-child.ts` `9d02b25d81c91b53a2ee9d7c09bf62f978808b4173127dfada6a317de1c98013`, and `scripts/performance-evidence.ts` `2dd3063bf031c75794696ba51997e5571964e72caa005240f40d594ea333d204`. `tests/runtime-benchmark-child.test.ts` has one moving-tree edit (`prepared.adapter.inspect` to `.serviceSnapshot`) and hash `5c1e420fb8d80d6235727547b9dd2c24db885f77cbe8119e8922826c4d4c80e4`; by itself it is incomplete because the adapter interface still exposes `inspect`.

Pinned-`739b509` baseline-facing declarations at `594e91c`:

- `BaselineRuntimeBag` (`resolve`, `inspect`, `scope`, `close`): `5bf077e82f7248b3709646f6596770f7f23825ae32d221467261086c029d802e`.
- `BaselineRuntimeBuilder` (`add`, `end`): `99ea89f1af1924c12f1ae1028faeef66e495bc2f5131bc610aee0c59adddb616`.
- `BaselineRuntimeFacade` (`factory(..., { acquisition: 'raw' | 'native' })`, `begin`, disposal, lifetime): `65db5082c927e476157a0cc98d672dc593c205370462153311745136bf92a94e`.
- Whole pre-edit baseline selection branch: `dc6b3ca3a3269da7afff9ba586b26daeed7eed97b600154131229a1b7513faf4`. Its baseline-facing expressions must remain `factory/acquisition`, `begin().add().end()`, `.scope()`, `.resolve()`, `.inspect()`, and `.close()`. Renaming only the common adapter property from `inspect` to `serviceSnapshot` necessarily changes this branch's wrapper key; it must still delegate to baseline `.inspect()`.

## Exact current-only adapter edits

In `runtime-scenarios.ts`, change `CurrentRuntimeBag.inspect` to `serviceSnapshot` and `createScope` to `createChildContainer`. Rename the common `RuntimeScenarioAdapter.inspect` property to `serviceSnapshot`; current delegates to `CurrentRuntimeBag.serviceSnapshot`, baseline delegates to the unchanged `BaselineRuntimeBag.inspect`. Current `child` delegates to `createChildContainer`; baseline `child` continues to delegate to `.scope`. Preserve builder/factory/disposal/lifetime setup and timing boundaries.

In `runtime-benchmark-child.test.ts`, remove the `NodeDiBag` import and run the current `node-native-promise` scenario with root `DiBag`. Keep the already-present `.adapter.serviceSnapshot` assertion. Baseline mock vocabulary and expected scenario results remain unchanged.

## Exact lane/entry edits

- `runtime-benchmark-child.ts`: after `runtimeBuilderSurfaceForLane(request.lane)` validates the lane, select `di-bag/node` only when `request.lane === 'baseline' && request.scenario === 'node-native-promise'`; every current request and every other baseline request selects `di-bag`. Preserve validation before `createRequire.resolve`, import, and scenario preparation.
- `performance-evidence.ts:595`: the smoke's expected file uses the same conjunction: baseline native-Promise -> `node.js`; all other lane/scenario pairs -> `index.js`.
- `runtime-benchmark-child.test.ts:212–226`: assert all current rows resolve `index.js`; assert only the baseline native-Promise row resolves `node.js`, with the other six baseline rows resolving `index.js`. Retain exact baseline commit `739b509eb7942e4e26c972a711d003aaf8769997`, seven rows per lane, archive identity separation, and work-result assertions.

## Review checklist

1. Diff touches exactly the four owned files and does not change the baseline-facing declarations or member calls listed above.
2. The common closure adds the same adapter call boundary already used by both lanes; no builder creation, preparation, priming, or provider setup moves into `runTimed`.
3. Unknown lane rejection remains before resolution/import/preparation, and its test still proves zero loader calls.
4. Root current native-Promise smoke and pinned baseline node-subpath smoke both execute; no new performance threshold or matrix is added.
5. The archive-smoke expected entry and child entry selector use identical lane/scenario logic.
