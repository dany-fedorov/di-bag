# Phase 6 S3 positional-fallback preservation review

## Findings

1. **Important — replacement diagnostics retain the old operation.** The entry `Overrides<F,O,K>` now has a fourth `Operation` parameter defaulting to `'fork'`, but both printed positional replacement overloads pass only three arguments. Unknown replacement keys would therefore report `fork accepts...` from `createChildContainer` / `createIndependentContainer`.
2. **Important — the child third bag drops transient-share admission.** Its literal property carries `Selection` and `ScopeShareAdmission`, but omits the `Transients<...>` branch already included by `CreateChildContainerOptions`. A transient can consequently type-check as shared in the positional fallback.
3. **Important — runtime arity and public empty-bag admission disagree.** The retained independent overload accepts `createIndependentContainer({})` (and explicit `undefined`) through default `CreateIndependentContainerOptions`, while `positionalIndependentOptions` accepts only zero or two arguments. The child helper's one-argument raw pass-through also accepts a replacement bag at runtime even though the selected fallback exposes one argument only as the share/empty options form.

## Narrow correction

- Pass `'createChildContainer'` / `'createIndependentContainer'` as the fourth `Overrides` parameter in the corresponding positional overload.
- Define the optional child third argument as `Pick<CreateChildContainerOptions<ServiceRegistrations, SharedParentServiceKeys, Constraints>, 'sharedParentServiceKeys'> & DisjointChildContainerSelection<ReplacedServiceKeys, SharedParentServiceKeys>`. This reuses selection, collection-kind and transient admission without importing replacement fields or duplicating their conditions; inference and the returned `ScopedAliases` remain unchanged.
- Preserve the already-published empty-bag overload. Let `positionalIndependentOptions` accept one argument only as `undefined` or a bag snapshotted with no supported keys (`snapshotOptionsBag(value, operation, [], [])`); change its arity diagnostic to 0/1/2. Two arguments remain the only replacement form.
- For the child's one-argument form, return `undefined` unchanged or call `snapshotOptionsBag(value, 'createChildContainer', [], ['sharedParentServiceKeys'])`. This accepts `undefined`, `{}` and share-only bags, rejects hidden replacement fields, and snapshots an original getter once. The common selector may snapshot the resulting plain record again without re-reading the caller's getter. The third positional bag uses the same allowed-key set.

## Focused controls

- Unknown keys in each positional replacement provider produce the new operation name, never `fork`.
- A transient in the child third bag is a compile-time rejection; collection and overlap controls remain.
- `createChildContainer()`, `createChildContainer(undefined)`, `createChildContainer({})`, share-only, and positional replace(+share) remain accepted; a one-argument replacement bag rejects as an unknown child option before provider reads.
- `createIndependentContainer()`, explicit `undefined`, and `{}` remain accepted; a one-argument replacement bag rejects, while the two-argument replacement form remains accepted. Use throwing getters to prove each caller-owned option getter is read at most once.

## Verdict

The positional fallback is viable after these local signature/normalization repairs. As printed, it weakens diagnostics and transient admission and exposes runtime forms that contradict its selected public surface.

## Plan-fix re-review

The corrected Step 8 closes all three Important findings: both `Overrides` applications name their new operation, the child third bag reuses the complete checked sharing property through `Pick`, and both one-argument normalizers preserve the empty/`undefined` forms while rejecting hidden replacements. The focused-control instructions cover transient sharing, unknown bag fields, getter ordering and renamed diagnostics. One nonblocking wording issue remains: the independent arity message describes an empty bag or a replacement pair but omits its accepted zero-argument and explicit-`undefined` forms; its structured `expected` detail correctly lists `0/1/2`. Expanding that sentence would make the human-readable contract exact. **Important findings closed; approved subject to that prose-level correction.**
