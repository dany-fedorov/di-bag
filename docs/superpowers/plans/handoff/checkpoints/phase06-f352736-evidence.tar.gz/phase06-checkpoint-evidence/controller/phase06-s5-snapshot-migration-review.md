# Phase 6 S5 snapshot-migration review

Verdict: **Approved with the root correction. No blocking findings.**

- Preserve the reflected collection fixture as `collectionSnapshotMethod = bag.serviceSnapshot` and retain its existing declaration-consumer call and exact `ReadonlyArray<RegistrationSnapshot<...>>` assertion. It exercises the contribution-bearing `bag` receiver and is not redundant with Task 3's `aggregateBag.serviceSnapshotMethod`, whose receiver has a different inferred graph/context.
- Treat the 23 other typed `inspectCollection` rows as explicit Task 6 hand migrations. The original-0.4 shipped map must remain `inspectAll -> serviceSnapshot`; adding an `inspectCollection` owner or claiming these edits came from the checker would falsify map provenance.
- The two current wrong-kind inspection assertions cannot be renamed mechanically. `inspect(collection)` and `inspectCollection(single)` are invalid because the old methods impose a kind; under unified `serviceSnapshot`, both authentic calls are valid and must become lazy-snapshot assertions for their actual graphs.
- Retain two genuine runtime kind failures by rewrapping each existing symbol with the opposite token kind: a forged single-service token for `numbersKey` on the collection graph, and a forged collection token for `serviceKey` on the single-service graph. Assert `DI_BAG_WRONG_TOKEN_KIND` and exact `details` with `operation: 'serviceSnapshot'`, graph kind as `expectedKind`, and forged-handle kind as `receivedKind`.
- Keep the separate `resolve(collection)` and `resolveCollection(single)` wrong-kind assertions unchanged apart from surrounding final-name migrations; those APIs remain kind-specific and still test distinct boundaries.
- The migrated valid snapshot assertions should verify no acquisition is triggered (empty `acquisitions` before resolution) and the correct scalar-versus-array return shape. This prevents the new unified dispatch from being tested only through failures.
- Task 7 still owns the untyped `.node.mjs` call; private `BagRuntime.inspectCollection` and the historical Phase 4 string script remain outside this public migration.

This adaptation preserves the original behavior being tested while replacing method-kind mismatches with the graph-kind authentication contract that `serviceSnapshot` actually implements.
