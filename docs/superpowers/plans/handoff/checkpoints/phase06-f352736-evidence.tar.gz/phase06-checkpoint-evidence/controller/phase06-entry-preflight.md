# Phase 6 entry preflight (bounded)

Compared authoritative plan 07 with the accepted Phase 5 surfaces in `src/builder-method-types.ts`, `src/di-bag.ts`, `src/index.ts`, `tests/types/builder-renames*.ts`, and the lane-selected runtime benchmark adapter. No compiler or test was run.

## Concrete corrections

1. **Entry collection-read row contradicts its own controlling fallback** (`plan07:62,68`). Line 62 correctly says the adopted Phase 4 fallback keeps `resolveCollection`/`inspectCollection` and ordinary `resolve`/`inspect` single-service-only, but line 68 then claims collection overloads on `resolve` and `inspect`. Replace line 68's final sentence with the actual fallback names. Later Task 3 already preserves `CollectionTokenMember` and the collection never-rest guard, so this is an entry-description correction, not an API redesign.

2. **Task 0 still names a rejected singular install fallback** (`plan07:67,170`). The settled Phase 5 API is `withInstalledModules(modules)`; line 170 asks whether S7 chose `withInstalledModule`. Replace that question with an assertion that evidence records the selected list form and its callable facade `BuilderWithInstalledModules`. No singular public method should be recreated.

3. **Callable-facade export ownership/count is internally wrong** (`plan07:2025`). Phase 5 has seven current callable facades: six exported from `builder-method-types.ts` (`BuilderWithServices`, `BuilderWithTokenService`, `BuilderWithServiceAlias`, `BuilderWithReplacedService`, `BuilderBuildModule`, `BuilderWithInstalledModules`) plus `BuilderWithCollectionContribution` from `contribution-types.ts`. Rewrite the instruction to preserve all seven from their actual owner files. Keep the existing `builder-renames` producer/consumer physical proof and both replacement overload paths.

4. **Graph step should be phrased as preservation plus one addition** (`plan07:1787,1892-1900`). Phase 5 Task 11 already ships bilingual terminals, service/token/replacement/alias shapes, checked module bags, inline/const module lists, and the contribution-omission parity test. State that these branches/tests remain unchanged while adding `withRenamedExport`; otherwise the terse “recognize buildContainer and phase 5's module terminal” wording can be misread as replacing the broader reviewed extractor.

## Checked and coherent

- All plan examples use positional `withTokenService(token, provider)` and `withReplacedService(serviceKey, provider)`; no stale options-bag form was found.
- `buildModule({ exportedServiceKeys, moduleLabel? })` and `withInstalledModules([...])` are used consistently outside the single Task 0 wording defect.
- Task 7 correctly excludes both benchmark adapter files from blanket rewriting, migrates only the current branch, preserves pinned `739b509` `begin/add/end`, `factory(..., { acquisition })`, and `scope/inspect`, and selects `di-bag/node` only for baseline `node-native-promise`.
- The focused current/archive smoke requirement preserves work and timing boundaries without adding a new performance matrix.

## Follow-up: Phase 5 archive-smoke entry assertions

Phase 5 Task 9B added another hard-coded entry owner that plan 07 does not yet name. In `scripts/performance-evidence.ts:583-598`, `runRuntimeArchiveSmoke` currently expects `node.js` for `node-native-promise` in both lanes. `tests/runtime-benchmark-child.test.ts:211-225` repeats that assumption for every returned row; lines 4 and 78-80 also run the current native-Promise scenario through `src/node.ts` directly.

Minimum Task 7 correction:

- Add `scripts/performance-evidence.ts` explicitly to Task 7's Files list (`plan07:1784-1788`).
- Alongside the lane-aware child change at `plan07:1888-1890`, make the smoke helper's expected entry `node.js` only when `lane === 'baseline' && scenario === 'node-native-promise'`; expect `index.js` otherwise. This changes assertion/provenance checking only, not sample work.
- In `tests/runtime-benchmark-child.test.ts`, remove the `NodeDiBag` current-lane import/use, run that direct current scenario with root `DiBag`, and make the archive result assertion use the same lane-and-scenario predicate. Keep the exact `739b509...` baseline identity assertion.
- Add `bun test tests/runtime-benchmark-child.test.ts` to Task 7 Step 5 (`plan07:1927-1942`). Its real archive smoke proves all seven scenarios select root for current, while only baseline native-Promise selects the historical node entry. The final full gate is not a substitute for this explicit compatibility proof.
