# Phase 6 Task 2 selector regression review

## Findings

1. **Important — shared token kinds are parsed but not authenticated against the graph.** The printed `selectChildContainer` claims only `replacedServiceKeys`. A forged single-service token whose symbol is already a collection can pass the later `!isCollection && graph.hasPublic(key)` check and reach `publicBinding`, including after the collection has a replacement public binding. Entry `selectScope` claims both replacement and sharing selections before lookup, so the printed selector weakens the wrong-kind boundary.
2. **Important — an explicit empty replacement selection bypasses provider-object validation.** `replacementPair` records `replacementProviders`, but `selectIndependentContainer` returns on `selected.length === 0` and `selectChildContainer` skips `selectedBindings`. Thus `{ replacedServiceKeys: [], replacementProviders: null | 1 | [] }` is accepted. Entry `fork`/`selectScope` validate the provider object before their empty-selection return.

## Narrow correction

- Extend `replacementPair` with an explicit `present` discriminator. Return `present: true` when both properties exist, even when the selected tuple is empty; return `present: false` when neither exists.
- Whenever `present` is true, call `selectedBindings` exactly once. It already validates `replacementProviders` before reading selected properties. For an empty valid object it returns `[]` without reading unrelated getters; return the unchanged graph afterward. Remove the independent `selected.length === 0` bypass and replace the child conditional with the `present` check.
- In `selectChildContainer`, snapshot both tuples, then claim token kinds in the entry order: replacements first, shared keys second. Use the twice-claimed `workingGraph` for existence checks, `publicBinding`, replacement binding installation and the returned graph. Keep the explicit collection-sharing rejection; the kind claim catches graph conflicts while that check rejects an otherwise unclaimed collection handle.
- Preserve error codes/details: kind conflicts remain `DI_BAG_WRONG_TOKEN_KIND` with operation `createChildContainer`; malformed providers remain `DI_BAG_INVALID_ARGUMENT` with `{ operation, argument: 'replacementProviders', expected: 'an object' }`. Do not loosen supported object shapes or read provider values during validation.

## Focused regressions

- Build a graph with a collection token, install a valid public collection replacement, forge a single-service token over the same symbol, then pass it in `sharedParentServiceKeys`. Assert `DI_BAG_WRONG_TOKEN_KIND` with expected `collection`, received `single-service`, operation `createChildContainer`, before any sharing/provider side effect.
- For both new operations, pass an explicit empty `replacedServiceKeys` tuple with each of `null`, an array and a primitive `replacementProviders`; assert the exact `DI_BAG_INVALID_ARGUMENT` code/details above.
- For both operations, retain the positive empty-pair case with a valid provider object containing a throwing getter for an unselected key. Assert construction succeeds and the getter is never read. This preserves the existing lazy empty-selection contract while closing only malformed provider objects.

## Verdict

Both are real entry-contract regressions in the printed Task 2 implementation. The corrections are local to selector normalization and require no public type, codemod or later-task change.

## Plan-fix re-review

The root plan diff closes both findings. `replacementPair` now distinguishes an omitted pair from an explicitly present empty pair; both selectors call `selectedBindings` for the latter, preserving provider-object validation without reading unselected values. `selectChildContainer` now claims replacement kinds followed by shared kinds and consistently uses `sharedGraph` for validation, public binding lookup, installation and return. The added regression instructions cover malformed empty-pair providers, getter laziness and the forged single-service token over a publicly replaced collection. The explicit collection-sharing prohibition remains. **Approved; no open Task 2 selector-plan findings.**
