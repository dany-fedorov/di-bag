import { diagnosticsByFile, describeDiagnostic } from '/tmp/di-bag-resume-20260921/phase06/tests/compiler.ts';
import { resolve } from 'node:path';
const path=resolve('/tmp/di-bag-resume-20260921/phase06/tests/types/negative/container-derivation.ts');
console.log(JSON.stringify((diagnosticsByFile([path]).get(path) ?? []).map(describeDiagnostic), null, 2));
