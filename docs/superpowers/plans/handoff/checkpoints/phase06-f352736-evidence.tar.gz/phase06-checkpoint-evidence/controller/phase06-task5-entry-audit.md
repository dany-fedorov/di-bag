# Phase 6 Task 5 codemod entry audit

Read-only comparison of plan 07 Task 5 (`2026-09-21-07-container-renames.md:1345-1724`) with merged Phase 5 source `324d4a7`, the shipped map/engine, and vendored 0.4 declarations. No codemod or compiler ran.

## Exact ownership checklist

- `tools/codemod/rename-map.json`: retain all Phase 3–5 entries. Replace the one existing `Bag.inspectAll -> inspectCollection` entry with direct original-to-final `Bag.inspectAll -> serviceSnapshot` plus `collection-read`; retain `Bag.resolveAll -> resolveCollection` unchanged. Add `Bag.inspect`, `Bag.inspectGraph`, `Bag.createScope`, `Bag.fork`, `Module.renameExport`, observer/scope property and type entries, and the two import entries exactly as printed.
- All method owners remain vendored-0.4 declarations (`Bag`, `Module`, `DiBagApi`). Do not substitute future `Container` owners before contraction: authentication reads the original program. Vendored `di-bag.d.ts` contains `inspectAll`, `inspectGraph`, the three `createScope` shapes, `fork()`/`fork(keys, overrides)`, and `Module.renameExport`.
- `tools/codemod/lib/transforms/container-derivation.mjs`: own only derivation shape rendering/manuals. Use the existing original-program `api.nameOf`/`nameForRole`/`assemble`; preserve nested Phase 5 builder transformations. Select either the adopted bag branches or the ruled S3 positional replacements after Tasks 0–2, never both.
- `tools/codemod/lib/transforms/index.mjs`: final registry must contain all five shipped ids: `build-and-start`, `collection-read`, `collection-reference`, `collection-token`, `container-derivation`.
- New `container-renames/{input,expected,expected-manual}.ts|json`: pin static `di-bag/node -> di-bag`, 0.4 `Bag` ownership, derivation forms/manual, nested builder calls, module rename/type/property composition, and direct `inspectAll -> serviceSnapshot` composition.
- Existing shipped-map expected files requiring cumulative target updates are exactly `collection-tokens/expected.ts:35` and `collection-tokens-import/expected.ts:5`: `inspectCollection` becomes `serviceSnapshot`. Their inputs remain `inspectAll`, and `resolveCollection` output remains unchanged.
- Do not broadly edit `arguments-to-bag`, `method-rename`, `properties`, or `types-and-imports` expected files merely because they contain Phase 6 words: each has its own custom `map.json`. The last already proves static import/export, import type, dynamic import, and exact/suffix import rewrites; its custom-map contract should remain stable.
- `rename-map.test.mjs`, `transforms.test.mjs`, `pack.test.mjs`: own closed validation/effective conflict behavior, alternate role-name rendering through the real checker, the exact five-id registry, and packed-file presence. No schema/dispatcher extension is needed.

## Concrete plan defects

1. **Transform registry snippet drops three required transforms.** Lines 1582–1590 say “without replacing earlier registrations” but print an object containing only `build-and-start` and `container-derivation`. Applied literally, shipped map loading fails for `collection-read`, `collection-reference`, and `collection-token`, and the new collection composition fixture cannot run. Import and retain the existing three transforms and print all five keys (matching lines 1413/1673).
2. **The new collection token widens its symbol identity.** Lines 1621 and 1653 use `DiBag.token(Symbol('collection'))` inline. Phase 5 established that typed collection fixtures must bind a singleton symbol first; the current `forCollectionOf` admission can otherwise reject/widen the expected output independently of the codemod behavior. Add `const collectionKey = Symbol('collection');` in both input/expected and call `DiBag.token(collectionKey)`; the codemod still changes only `.of` to `.forCollectionOf`.
3. **“Older fixture expected files” is overbroad ownership.** Line 1357 should name the two shipped collection expected files above. Custom-map fixtures intentionally retain old/manual calls or test isolated transformations; changing them to the full shipped result would invalidate their contract rather than prove cumulative 0.4→0.5 output.

## Boundaries checked clean

- Direct `inspectAll -> serviceSnapshot` is correct under the selected Phase 4 `inspectCollection` fallback: `collection-read.mjs` emits the map target directly and does not chase `inspectAll -> inspect -> serviceSnapshot`.
- The S3 fallback substitutions preserve positional `createScope`/`fork` arguments while still renaming the method and the literal `share` key; zero-argument and share-only shapes stay as specified. The final Task 5 brief must resolve the conditional from Tasks 0–2 before implementation.
- Exact `di-bag/node -> di-bag` plus relative `/src/node -> /src` matches `rewriteString`: it covers import/export declarations, import types, `require`, and dynamic import; explicit-extension suffixes remain correctly manual.

## Correction re-review

Approved. The pending Task 5 diff addresses all three findings exactly: the printed registry imports and retains all five transforms; both fixture sides bind `collectionKey` before constructing the token; and ownership now names only the two shipped-map collection goldens while expressly preserving custom-map fixtures. The corrections preserve the direct `inspectAll -> serviceSnapshot` mapping, original `Bag` ownership, and cumulative-map boundary. No new Task 5 contradiction is present.
