# Phase 6 entry-plan correction review

## Finding

1. **Important — the `api-renaming` filter correction is incomplete.** Plan 06 Task 12 Step 7 (`2026-09-21-06-builder-renames.md:3247`) and Task 14 focused checks (`:3383`) still use `api renaming` with a space. The relevant dynamic test title is `type rejection: api-renaming.ts`, so both commands silently omit the same negative fixture that the corrected Task 12 Step 1 now selects. Change both remaining alternatives to `api-renaming`.

## Assessment

- Plan 07 now states the adopted Phase 4 read boundary accurately: collection handles use `resolveCollection`/`inspectCollection`, while ordinary `resolve`/`inspect` remain single-service-only.
- Task 0 records the selected list API and `BuilderWithInstalledModules`; it explicitly forbids recreating the rejected singular fallback. Positional token-service and replacement selections remain consistent.
- The callable-facade inventory is now exact: six owners in `builder-method-types.ts` plus `BuilderWithCollectionContribution` in `contribution-types.ts`, with physical producer/consumer and both replacement-path proof preserved.
- The graph instruction correctly preserves the full reviewed Phase 5 bilingual branches and contribution-omission parity, then adds only renamed-export parsing while retaining schema-v1 `kind: 'bag'`.
- No contradictory singular-install, collection-overload, or six-facade wording remains in Plan 07. `git diff --check` passes.

## Verdict

**Plan 07 corrections are approved. Overall patch is not ready until the two remaining Plan 06 filter spellings are corrected.**

## Re-review

- Task 12 Step 7 and Task 14 now use `api-renaming`, matching the dynamic test title `type rejection: api-renaming.ts`; their Task 12/14 brief copies match. No `api renaming` filter remains.
- The positive fixture is titled `consolidated API preserves exact mode-dependent contracts`, so the old space form did not select it either. The correction restores the intended negative-fixture coverage without claiming extra positive coverage.
- The pre-removal expectation now accurately says the final removed-member/shape diagnostics are absent while some calls may already produce older admission diagnostics. It requires recording those actual outcomes and no longer makes the false blanket claim that every old call compiles.
- `git diff --check` passes.

**Re-review verdict: Approved. The Important finding is closed; no open findings.**

## Additional archive-smoke ownership review

- Task 7 now owns `scripts/performance-evidence.ts`, closing the Phase 5 Task 9B helper gap rather than leaving a hard-coded current `node.js` expectation for Task 10.
- The child loader, `runRuntimeArchiveSmoke`, and `tests/runtime-benchmark-child.test.ts` now share the exact selected rule: only `baseline` plus `node-native-promise` uses/expects the historical node entry; every current scenario and every other baseline scenario uses/expects the root entry.
- Removing the direct current `NodeDiBag` selection is required by Phase 6's root-only current API and leaves the exact pinned-`739b509` baseline branch intact. The plan preserves all seven paired scenarios, archive identities, canonical results, invalid-lane-before-import behavior, and the exact baseline commit assertion.
- The focused `bun test tests/runtime-benchmark-child.test.ts` command directly covers the changed helper and assertions; it does not add or claim a performance threshold gate. Task 10 can subsequently delete the node subpath while retaining only the explicit baseline branch in the child.
- `git diff --check` passes.

**Additional review verdict: Approved. No open findings.**
