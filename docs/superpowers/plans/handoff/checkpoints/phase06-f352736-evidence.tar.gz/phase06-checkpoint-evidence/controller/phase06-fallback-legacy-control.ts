import { diagnostics, describeDiagnostic } from '/tmp/di-bag-resume-20260921/phase06/tests/compiler.ts';
import { resolve } from 'node:path';
const path = resolve('/tmp/di-bag-resume-20260921/phase06/tests/types/fallback-legacy-control.ts');
const source = `
import { DiBag } from '../../src';
type Clock = { now(): number };
const root = DiBag.createBuilder()
  .withServices({ value: () => 1, clock: (): Clock => ({ now: () => 1 }) })
  .buildContainer();
const independent = root.fork(['clock'], {
  clock: ({ value }) => ({ now: () => value + 1, source: 'fork' as const }),
});
const child = root.createScope(['clock'], {
  clock: ({ value }) => ({ now: () => value + 2, source: 'scope' as const }),
});
const a: 'fork' = independent.resolve('clock').source;
const b: 'scope' = child.resolve('clock').source;
void a; void b;
`;
console.log(JSON.stringify(diagnostics(path, source).map(describeDiagnostic), null, 2));
