# Phase 6 Task 6 preservation preflight

Scope: frozen mechanical diff `task6-mechanical-write1.diff` from prewrite `e33c976e42f306d819ddf0bc9281014d77b495e1`, its write report, and `task6-preview3-manual-classification.json`. This is not final approval.

## Findings

1. **Important — two startup rejection expressions became valid** (`tests/types/negative/startup.ts:77-80`). Mechanical rewriting changes retired `timeoutMs`/`signal` controls to accepted `waitTimeoutMs`/`abortSignal` while leaving `does not exist` markers. Preserve the two old property spellings as removed-option negatives; they are not present in the manual classification.

2. **Important — the removed buildModule-shape control became valid** (`tests/types/negative/api-renaming.ts:69`). `buildModule(['value'])` is rewritten to the accepted `{ exportedServiceKeys: ['value'] }` bag while its rejection marker remains. Preserve the positional array call as the old-shape negative; it is absent from the manual classification.

3. **Important — expand-only legacy observer coverage is erased** (`tests/container-names.test.ts:80-98`). Both the “legacy observers” case and the legacy half of the mixed old/new case are rewritten to `lifecycleObservers` plus new callback names. Restore their legacy `observers`/`onEvent`/`onError` calls through the expand boundary. The classified dual-field conflict at line 107 is correctly retained, but these two additional compatibility cases are missing from classification.

4. **Important — indirect observer records are partially migrated** (`tests/observers.test.ts:80-94,248-251`). The outer key becomes `lifecycleObservers`, while the `options` objects still define/mutate `onEvent` and `onError`; those positive snapshot/duplicate tests now fail validation instead of exercising delivery. Migrate the indirect object fields and mutation consistently. The three malformed-record probes likewise retain old callback fields under the new outer key, weakening their specific missing/wrong-new-callback coverage; preserve equivalent invalid new-field expressions rather than accepting a broad throw for unrelated missing fields.

5. **Important — observer declaration fixtures contain split-shape and syntax regressions** (`tests/types/observers.ts:1`, `tests/types/observers-consumer.ts:4,20-23`). `ObserverOptions -> LifecycleObserver` creates a duplicate `LifecycleObserver` import. Extracted `observe(...)` calls retain outer `observers` while their callbacks become `onLifecycleEvent`/`onObserverFailure`, so positive composition becomes invalid and both `@ts-expect-error` controls reject for the wrong legacy/new shape mismatch. Deduplicate the import and migrate each extracted-call bag coherently, retaining the missing-callback and receiver diagnostics.

## Preserved controls checked

- `tests/types/negative/observers.ts` keeps every invalid expression invalid after the direct field migration; its first two marker texts need actual-diagnostic capture because the required property names changed, but no case should be deleted or generalized.
- Manual rows for `tests/types/negative/fork-selection.ts`, `scopes.ts`, and `selected-scopes.ts` correctly identify nonmechanical derivation calls that need hand adaptation while retaining invalid arity/unknown-property meaning.
- The classified `tests/container-names.test.ts` dual observer-field conflict, single-token `.of` controls, erased current method references, malformed `null`, and explicit source-import controls are correctly marked for preservation.
- Direct renamed negative calls for collection/token/lifetime/provider contracts retain their invalid payloads. Their operation-name markers must follow captured diagnostics; no blanket marker replacement is justified by this preflight.

**Status:** Mechanical provenance is usable, but the hand unit must resolve all five findings and add the omitted controls to its accounting before Task 6 can be reviewed green.
