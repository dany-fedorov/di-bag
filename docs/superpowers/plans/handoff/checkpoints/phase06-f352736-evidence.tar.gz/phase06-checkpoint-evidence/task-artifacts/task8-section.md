### Task 8: Contract the public type and container methods

**Files:**
- Modify: `src/di-bag.ts`, `src/scope-selection.ts`, `src/scope-types.ts`, `src/lifetime-types.ts`, `src/types.ts`, `src/startup.ts`, `src/index.ts`
- Modify: `tests/container-names.test.ts`
- Modify: `tests/types/negative/api-renaming.ts`
- Modify: `tests/package.test.ts`

**Interfaces:**
- Consumes: migrated call sites and adopted S3 shape.
- Produces: `Container<ServiceRegistrations, Constraints>` as the only public container type; no `Bag`, `inspect`, `inspectCollection`, `inspectGraph`, `createScope`, `fork`, `ScopeOptions`, `CheckedScopeLifetimes`, or `DisjointScopeSelection` declaration.

- [ ] **Step 1: Add contract tests before deleting names**

Append to `tests/container-names.test.ts`:

```ts
test('retired container members are absent at runtime', async () => {
  const container = DiBag.createBuilder().buildContainer();
  for (const name of ['inspect', 'inspectCollection', 'inspectGraph', 'createScope', 'fork']) expect(name in container).toBe(false);
  await container.close();
});
```

Append these lines to `tests/types/negative/api-renaming.ts` (and use the file's post-codemod root import):

```ts
// diagnostic: no exported member
import type { Bag } from '../../../src';
// diagnostic: no exported member
import type { ScopeOptions } from '../../../src';
// diagnostic: no exported member
import type { CheckedScopeLifetimes } from '../../../src';
// diagnostic: no exported member
import type { DisjointScopeSelection } from '../../../src';
const retiredContainer = DiBag.createBuilder().buildContainer();
// diagnostic: does not exist
retiredContainer.inspect('value');
// diagnostic: does not exist
retiredContainer.inspectCollection('value');
// diagnostic: does not exist
retiredContainer.inspectGraph();
// diagnostic: does not exist
retiredContainer.createScope();
// diagnostic: does not exist
retiredContainer.fork();
```

Because a single invalid import may suppress useful member diagnostics, split the type imports into one statement per retired export if the fixture harness reports fewer diagnostics than markers.

Run the negative-fixture test and `bun test tests/container-names.test.ts`. Expected: fail because old exports/members remain.

- [ ] **Step 2: Rename the class and every public-context helper**

In `src/di-bag.ts`, rename the declaration and exact export:

```ts
class Container<ServiceRegistrations extends Registrations, Constraints extends NeedConstraint = never> { /* existing body */ }
export type { Container, Builder };
```

Every `new Bag`, return type, `this` type, builder `buildContainer` return, JSDoc `{@link Bag...}`, example variable, and public-facing prose becomes `Container`/`container`. Audit identifier names matching `BuildBag|BagBuild|BuiltBag` and rename any phase-5 helper to the equivalent `BuildContainer|ContainerBuild|BuiltContainer` form. Export `Container` from `src/index.ts` and remove `Bag`.

Remove Task6's temporary `Bag as Container` export alias while renaming the class; the final declaration exports only the renamed `Container` and `Builder` types. Preserve the alias prerequisite's migrated consumer assertions.

Keep `BagRuntime`: it is an internal runtime/ownership engine, never exported, and renaming it would add churn without changing user vocabulary. Keep `DiBag`, every `DiBag*Error`, the package name, and `DI_BAG_*` codes because the spec explicitly preserves them.

- [ ] **Step 3: Remove old methods and support types**

Delete `inspect`, `inspectCollection`, `inspectGraph`, all `createScope` overloads/body, all `fork` overloads/body, `selectScope`, `ScopeOptions`, `CheckedScopeLifetimes`, and `DisjointScopeSelection`. Remove their imports and old JSDoc. If Task 6 produced two adjacent byte-identical direct `serviceSnapshot<never>` controls from the expand-old and expand-new lines, delete one now; retain one direct control and the reflected declaration-consumer control. Export these exact phase-6 types from `src/index.ts`:

```ts
export type { Container, Builder, DiBagApi, ConfigurationOptions } from './di-bag';
export type { CreateChildContainerOptions, CreateIndependentContainerOptions, DisjointChildContainerSelection, UnsharedAliases, ScopedAliases, SharedAliasProviders } from './scope-types';
export type { CheckedLifetimes, CheckedChildContainerLifetimes, LifetimeObligation, Reach } from './lifetime-types';
```

Retain all seven phase-5 callable facades: `BuilderWithServices`, `BuilderWithTokenService`, `BuilderWithServiceAlias`, `BuilderWithReplacedService`, `BuilderBuildModule`, and `BuilderWithInstalledModules` from `./builder-method-types`, plus `BuilderWithCollectionContribution` from `./contribution-types`. The block above changes only the named container/scope/lifetime exports. Keep `builder-renames` registered in the existing physical producer-deletion matrix when removing `src/node.ts`; its source and physical imports migrate to the root entry with the other fixtures, and must continue proving all callable facades and both replacement paths. These future root-entry declarations remain uncompiled until this phase.

No extra sharing-only options type is exported: `CreateChildContainerOptions` covers that overload through its defaulted replacement generics.

- [ ] **Step 4: Update container terminology except deferred message families**

Change user-facing comments/JSDoc in `src/` from bag/scope/fork to container/child container/independent container. Change `startup.ts` links from `Bag.close` to `Container.close` and authorized “Bag close” prose to “Container close”. Do **not** modify these three runtime constructions:

```ts
diagnosticMessage('DI_BAG_CLOSING', 'bag is closing')
diagnosticMessage('DI_BAG_CLOSED', `bag is ${state}`)
```

The exact code may have two acquisition sites and one runtime site. Preserve all 10 `toThrow('bag is closing')` and 5 `toThrow('bag is closed')` assertions for plan 12 (phase 11). Run:

```bash
grep -rhoE "toThrow\((/|['\x60])[^)]*" tests | grep -iE '\bbag is (closing|closed)\b' | sort | uniq -c
```

Expected: `10 ...bag is closing` and `5 ...bag is closed`. No replacement command is run in this phase.

- [ ] **Step 5: Run contract tests and audits**

```bash
bun test tests/container-names.test.ts
bun test tests/types.test.ts --test-name-pattern 'api-renaming|container derivation|container-derivation'
grep -rnE '^class Bag\b|export type \{[^}]*\bBag\b|\b(ScopeOptions|CheckedScopeLifetimes|DisjointScopeSelection|ObserverOptions)\b' src tests examples scripts tools/graph AGENTS.md docs/agent --exclude='api-renaming.ts' --exclude-dir='container-renames'
grep -rnE '\.(createScope|fork|inspect|inspectCollection|inspectGraph|renameExport)\(' src tests examples scripts tools/graph AGENTS.md docs/agent --exclude='api-renaming.ts' --exclude-dir='container-renames'
grep -rnE "operation: '(inspect|inspectGraph|createScope|fork|renameExport)'|\b(observers|onEvent|onError)\s*:" src tests examples scripts tools/graph AGENTS.md docs/agent --exclude-dir='container-renames'
```

Expected: tests pass. At this contract point, the first two greps show only the Task-9 observer/module expand declarations, explicit negative/codemod-input fixtures, and the preserved private inspection channels: `this.#runtime.inspect`, `inspectCollection` and `inspectGraph` in `src/di-bag.ts`, acquisition-owner `inspect` calls in `src/acquisition.ts`, and `this.acquisitions.inspect` in `src/runtime.ts`. These internal calls are not retired public container members. The operation grep has no public container-operation hit. Record every allowed path and receiver, and carry the same precise internal-channel classification into the final Task-12 audit. `BagRuntime`, `DiBag*`, package names, codes, and graph `kind: "bag"` remain intentionally.

- [ ] **Step 6: Keep the checked contract changes uncommitted**

Record the Step-5 results, run `git diff --check`, and continue directly into Task 9. Do not stage or commit: module/observer contraction, node-entry removal, regenerated reference files, and the source declaration removals must land together in Task 11's coherent green contract commit.

---

