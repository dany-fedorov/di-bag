import ts from '/tmp/di-bag-resume-20260921/phase06/node_modules/@typescript/old/lib/typescript.js';
import { diagnostics } from '/tmp/di-bag-resume-20260921/phase06/tests/compiler.ts';
const path = '/tmp/di-bag-resume-20260921/phase06/tests/types/negative/collection-tokens.ts';
for (const d of diagnostics(path)) {
  const lc = d.file && d.start !== undefined ? d.file.getLineAndCharacterOfPosition(d.start) : undefined;
  console.log(JSON.stringify({ line: lc ? lc.line + 1 : null, code: d.code, message: ts.flattenDiagnosticMessageText(d.messageText, '\n') }));
}
