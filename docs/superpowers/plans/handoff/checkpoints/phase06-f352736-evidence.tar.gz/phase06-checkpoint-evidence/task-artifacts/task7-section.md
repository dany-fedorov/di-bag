### Task 7: Migrate generated strings, graph tooling, and shipped agent material

**Files:**
- Modify: `tests/compiler.ts`, package/native/token/release tests, `tests/host-builtin-module.ts`, `tests/*.node.mjs`
- Modify: `scripts/benchmark-types.ts`, `scripts/compiler-case.ts`, `scripts/benchmark-compiler-ceiling.ts`, `scripts/runtime-benchmark-child.ts`, `scripts/performance-evidence.ts`, `tests/benchmarks/runtime-scenarios.ts`, `tests/runtime-benchmark-child.test.ts`, `scripts/platform-evidence.ts`, `scripts/react-browser-lane.ts`, `scripts/agent-eval/**`
- Modify: `tools/graph/lib/extract.mjs`, `tools/graph/README.md`, `tools/graph/test/**`
- Modify: `AGENTS.md`, `docs/agent/recipes.md`, `docs/agent/errors.md`, `tools/docs/api-card-tasks.json`
- Create: `/tmp/di-bag-phase-06/reshape-untyped.mjs` (untracked migration helper)

**Interfaces:**
- Consumes: all adopted phase-6 names and phase 5's `moduleLabel` option.
- Produces: generated/runtime source on 0.5.0 names; graph schema stays version 1 with `Unit.kind: 'bag' | 'module'`.

- [ ] **Step 1: Migrate generated-source templates**

Create `/tmp/di-bag-phase-06/reshape-untyped.mjs` first. It performs only context-free declaration/member/import renames, records exact per-file counts, and refuses to leave a positional derivation call for a human to overlook:

```js
import { globSync, readFileSync, writeFileSync } from 'node:fs';

const patterns = [
  'tests/**/*.{ts,tsx,mjs}', 'scripts/**/*.{ts,tsx,mjs}',
  'tools/graph/**/*.{ts,tsx,mjs,md}', 'AGENTS.md', 'docs/agent/*.md',
];
const excluded = /(?:api-renaming\.ts|docs\/agent\/api-card\.md$|tests\/benchmarks\/runtime-scenarios\.ts|scripts\/runtime-benchmark-child\.ts|tools\/codemod\/test\/fixtures|tools\/graph\/test\/fixtures\/.*0-4)/;
const files = [...new Set(patterns.flatMap(pattern => globSync(pattern)))].filter(file => !excluded.test(file)).sort();
const rules = [
  [/(['"])(di-bag\/node)\1/g, (_m, quote) => `${quote}di-bag${quote}`, 'root import'],
  [/(\/src)\/node(?=['"])/g, '$1', 'source root import'],
  [/\bCheckedScopeLifetimes\b/g, 'CheckedChildContainerLifetimes', 'lifetime type'],
  [/\bDisjointScopeSelection\b/g, 'DisjointChildContainerSelection', 'disjoint type'],
  [/\bScopeOptions\b/g, 'CreateChildContainerOptions', 'child options type'],
  [/\bObserverOptions\b/g, 'LifecycleObserver', 'observer type'],
  [/\.inspectGraph\(/g, '.graphSnapshot(', 'graph snapshot'],
  [/\.inspectCollection\(/g, '.serviceSnapshot(', 'collection snapshot'],
  [/\.inspect\(/g, '.serviceSnapshot(', 'service snapshot'],
  [/\.renameExport\(\s*([^,()]+?)\s*,\s*([^,()]+?)\s*\)/g, '.withRenamedExport({ currentExportKey: $1, newExportKey: $2 })', 'module export bag'],
  [/\bobservers\s*:/g, 'lifecycleObservers:', 'observer list field'],
  [/\bonEvent\s*:/g, 'onLifecycleEvent:', 'observer event field'],
  [/\bonError\s*:/g, 'onObserverFailure:', 'observer failure field'],
  [/\bonEvent\s*\(/g, 'onLifecycleEvent(', 'observer event method'],
  [/\bonError\s*\(/g, 'onObserverFailure(', 'observer failure method'],
];
const inventory = { before: {}, changes: {}, after: {} };
const retired = /\.(?:createScope|fork|inspect|inspectCollection|inspectGraph|renameExport)\(|\b(?:ScopeOptions|CheckedScopeLifetimes|DisjointScopeSelection|ObserverOptions)\b|\b(?:observers|onEvent|onError)\s*:/g;
for (const file of files) {
  const unresolved = readFileSync(file, 'utf8').match(/\.(?:createScope|fork)\s*\(/g) ?? [];
  if (unresolved.length) throw new Error(`${file}: ${unresolved.length} derivation call(s) require an explicit migration to the selected container signature before this script writes anything`);
}
for (const file of files) {
  let text = readFileSync(file, 'utf8');
  inventory.before[file] = [...text.matchAll(retired)].length;
  const counts = {};
  for (const [pattern, replacement, label] of rules) {
    let count = 0;
    text = text.replace(pattern, (...args) => {
      count++;
      return typeof replacement === 'function' ? replacement(...args) : replacement.replace(/\$(\d+)/g, (_m, n) => args[Number(n)]);
    });
    if (count) counts[label] = count;
  }
  inventory.changes[file] = counts;
  inventory.after[file] = [...text.matchAll(retired)].length;
  if (inventory.before[file] > 0 && Object.keys(counts).length === 0) throw new Error(`${file}: retired inventory changed by no rule`);
  writeFileSync(file, text);
}
writeFileSync('/tmp/di-bag-phase-06/untyped-inventory.json', `${JSON.stringify(inventory, null, 2)}\n`);
if (Object.values(inventory.after).some(count => count !== 0)) throw new Error('retired names remain; inspect untyped-inventory.json');
```

Run it after the exact derivation-call edits in Steps 1 through 4. Expected before inventory: every nonzero file belongs to the explicit file groups in this task. Expected after inventory: every value is `0`. Review `changes` file by file; reject an empty change record for a nonzero input. The script deliberately aborts on a retired `createScope` or `fork` call; edit that specific source string to one of the selected signatures shown below, then rerun from the task commit's clean starting tree. Do not add a permissive regex.

Before editing, capture the positional derivation inventory from the phase entry tree:

```bash
rg -n '\.(createScope|fork)\(' tests/*.node.mjs tests/compiler.ts tests/package.test.ts tests/native-package.test.ts tests/token-package.test.ts tests/release-artifacts.test.ts tests/host-builtin-module.ts scripts --glob '!scripts/agent-eval/**' > /tmp/di-bag-phase-06/untyped-derivations.before.txt
cat /tmp/di-bag-phase-06/untyped-derivations.before.txt
test "$(wc -l < /tmp/di-bag-phase-06/untyped-derivations.before.txt)" -eq 10
```

The expected ten calls and their exact replacements are:

| File | Count | Entry call | Exact replacement |
| --- | ---: | --- | --- |
| `tests/runtime-scale.node.mjs` | 1 | `bag.createScope()` | `bag.createChildContainer()` |
| `tests/native-package.test.ts` generated source | 2 | `parent.createScope()`; `child.fork()` | `parent.createChildContainer()`; `child.createIndependentContainer()` |
| `tests/token-package.test.ts` generated source | 1 | `root.fork([samePublicToken], { [publicKey]: () => childValue })` | `root.createIndependentContainer([samePublicToken], { [publicKey]: () => childValue })` |
| `tests/package.test.ts` generated source | 2 | `parent.createScope()`; `scope.fork()` | `parent.createChildContainer()`; `scope.createIndependentContainer()` |
| `tests/package.test.ts` generated source | 1 | multiline `bag.fork(['clock'], { ... })` | `bag.createIndependentContainer(['clock'], { ... })` with the provider object and its indentation unchanged |
| `tests/package.test.ts` generated source | 1 | `bag.fork()` | `bag.createIndependentContainer()` |
| `tests/package.test.ts` generated source | 1 | `composed.fork(['clock'], { clock: () => ({ ... }) })` | `composed.createIndependentContainer(['clock'], { clock: () => ({ ... }) })` |
| `tests/package.test.ts` generated source | 1 | `composed.fork(['clock', 'promised'], asyncOverrides)` | `composed.createIndependentContainer(['clock', 'promised'], asyncOverrides)` |

Apply only those ten replacements before running `reshape-untyped.mjs`. Then run the same `rg` into `/tmp/di-bag-phase-06/untyped-derivations.after.txt`; expected output is empty and `test ! -s` passes. `scripts/agent-eval/**` is excluded because Task 6 sends those real TypeScript calls through the checker-backed codemod. The graph tool's 0.4 fixtures remain deliberately excluded compatibility inputs.

The separate S5 untyped snapshot inventory has one current executable call: `tests/acquisition-retention.node.mjs` uses `bag.inspectCollection(token)[0]`. Its explicit collection-snapshot rule changes this to `bag.serviceSnapshot(token)[0]` while preserving every retention assertion. The private `BagRuntime.inspectCollection` channel remains unchanged. `scripts/phase05-strings.py` is historical migration evidence, outside this script's input globs: do not execute or rewrite its old replacement literals, and distinguish that exact file in residual textual audits.

In `tests/compiler.ts` and all three compiler scripts, apply the codemod table inside source strings: positional replacement pairs with optional checked sharing bags, `Container`, snapshots, module bag, and observer fields. Keep the twelve cases logically identical.

`tests/benchmarks/runtime-scenarios.ts` is a deliberate bilingual executable fixture, not an untyped migration input. Phase 5 selects a current or pinned-739b509 adapter from the child request lane before timing. Exclude this file and `scripts/runtime-benchmark-child.ts` from `reshape-untyped.mjs`; migrate only the current adapter's container operations by hand (`inspect` to `serviceSnapshot` and `createScope` to `createChildContainer`; `resolve` and `close` stay shared because this phase does not rename them). Retain the actual pinned-739b509 adapter members byte-for-byte: `begin`/`add`/`end`, `factory` with `acquisition`, and container `scope`/`inspect`. Its remaining retired-name rows are exact path/adapter allowlist entries, not permission for another old executable call. Run the focused current and exact pinned-`739b509` archive child smokes after the hand edit; do not add a performance matrix or threshold gate.

```bash
node scripts/evidence-cases.mjs --compare docs/superpowers/plans/evidence/baseline.md --json /tmp/di-bag-phase-06/migrated-generators.json
```

Expected: twelve accepted rows and no token diagnostics. Replace Task 1's provisional phase values with these final values in `phase-06.md`.

- [ ] **Step 2: Migrate package/runtime strings**

Apply the same rewrites in `tests/package.test.ts`, `tests/native-package.test.ts`, `tests/token-package.test.ts`, `tests/release-artifacts.test.ts`, `tests/host-builtin-module.ts`, the three `.node.mjs` suites, and generated code under `scripts/`. Every current-API `di-bag/node` import becomes `di-bag`; preserve only the exact baseline native-Promise branch described below. Compile strings import `type Container`. Keep the runtime assertion that type-only `Container`, `Module`, and `Provider` are not constructible exports. Release-artifact expected entries become `['di-bag']`.

`tests/token-package.test.ts` still compares ESM and CJS views of the root package for canonical token identity. In `scripts/runtime-benchmark-child.ts`, select the entry by both lane and scenario: only the pinned-739b509 `baseline` lane's `node-native-promise` request loads `di-bag/node`; every `current` request and every other baseline scenario loads `di-bag`. This preserves the historical native-promise boundary while proving the current root-only entry. Reject an unknown lane before import/preparation. Update `runRuntimeArchiveSmoke` in `scripts/performance-evidence.ts` and its assertions in `tests/runtime-benchmark-child.test.ts` to use the same lane-and-scenario entry rule: only baseline native-Promise expects `dist/node.js`; every other row expects `dist/index.js`. The direct current scenario tests must use root `DiBag` for every scenario and remove their old `NodeDiBag` import/selection. Preserve all seven paired archive scenarios, the exact baseline commit assertion, archive identities and canonical results. `scripts/platform-evidence.ts` replaces the node-subpath boundary fact with root-entry coverage. Leave the `scripts/react-browser-lane.ts` assertion about `src/node.ts` until Task 10 deletes that file.

- [ ] **Step 3: Update graph recognition without changing JSON**

Preserve Phase 5's reviewed bilingual extractor and tests in `tools/graph`: all old/current terminals, service and alias bags, positional token/replacement calls, module bags, inline/constant ordered module lists, and repeated-contribution omission parity. Extend only renamed-export parsing for this step: read `withRenamedExport({ currentExportKey, newExportKey })` beside positional `renameExport`; a spread or nonliteral options bag remains untraceable. Do not replace the existing broader recognition with a reduced set of branches.

For the new method, trace only statically known string values; a shorthand or identifier value must never be interpreted as its identifier's spelling. Leaving those values opaque is acceptable and keeps this parser bounded. A same-name rename is an identity operation: unwrap it without deleting the export in the rename map. Keep discriminating controls for literal mixed chains, same-name identity, shorthand constants and unknown-value opacity; preserve the existing positional parser.

Keep output `kind: 'bag'`. `tools/graph/README.md` must say a source `buildContainer()` emits established schema-v1 `kind: "bag"`. Do not change expected JSON kind values.

Run: `npm run graph:check`

Expected: exit 0; every unit kind remains `bag` or `module`.

- [ ] **Step 4: Migrate agent-eval and shipped agent docs**

Migrate `scripts/agent-eval/reference/**`, `scripts/agent-eval/skeleton/**`, `AGENTS.md`, and authored `docs/agent/*.md`, excluding generated `docs/agent/api-card.md`. The helper excludes that exact file too; Task11 regenerates it from the final declarations. Its old spellings during this intermediate task are documented generated drift, not an unowned executable call. Use these canonical shapes:

```ts
const child = container.createChildContainer(
  ['request'],
  { request: () => requestContext },
  { sharedParentServiceKeys: ['client'] },
);
const testContainer = container.createIndependentContainer(
  ['clock'],
  { clock: (): Clock => ({ now: () => 0 }) },
);
```

Update `tools/docs/api-card-tasks.json` rows exactly:

```json
{ "task": "Replace services for a test", "call": "container.createIndependentContainer" }
{ "task": "Open a child container", "call": "container.createChildContainer" }
```

Use receiver `container` for close, readiness, and snapshot rows. Delete a summary-exception id only if that exact renamed task id is present. Replace lines in `AGENTS.md`; never add lines.

- [ ] **Step 5: Audit and test**

```bash
node /tmp/di-bag-phase-06/reshape-untyped.mjs
cat /tmp/di-bag-phase-06/untyped-inventory.json
rg -n '\.(createScope|fork)\(' tests/*.node.mjs tests/compiler.ts tests/package.test.ts tests/native-package.test.ts tests/token-package.test.ts tests/release-artifacts.test.ts tests/host-builtin-module.ts scripts --glob '!scripts/agent-eval/**' > /tmp/di-bag-phase-06/untyped-derivations.after.txt
test ! -s /tmp/di-bag-phase-06/untyped-derivations.after.txt
grep -rnE '\.(createScope|fork|inspect|inspectCollection|inspectGraph|renameExport)\(' tests examples scripts tools/graph AGENTS.md docs/agent --exclude='api-renaming.ts' --exclude-dir='container-renames'
grep -rnE '\b(Bag|ScopeOptions|CheckedScopeLifetimes|DisjointScopeSelection|ObserverOptions)\b' tests examples scripts tools/graph AGENTS.md docs/agent --exclude='api-renaming.ts' --exclude-dir='container-renames'
grep -rnE '\b(observers|onEvent|onError)\s*:' tests examples scripts tools/graph AGENTS.md docs/agent --exclude-dir='container-renames'
wc -l AGENTS.md
npm run agent-eval:test
npm run graph:check
bun test tests/runtime-benchmark-child.test.ts
```

Expected: only deliberate compatibility/rejection fixtures remain; line count is 150 or less; both suites pass.

- [ ] **Step 6: Commit**

```bash
git add tests examples scripts tools/graph tools/docs/api-card-tasks.json AGENTS.md docs/agent docs/superpowers/plans/evidence/phase-06.md
git commit -m "refactor!: migrate generated and agent container calls"
```

---

