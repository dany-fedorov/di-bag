import { globSync, readFileSync, writeFileSync } from 'node:fs';

const patterns = [
  'tests/**/*.{ts,tsx,mjs}', 'scripts/**/*.{ts,tsx,mjs}',
  'tools/graph/**/*.{ts,tsx,mjs,md}', 'AGENTS.md', 'docs/agent/*.md',
];
const excluded = /(?:api-renaming\.ts|docs\/agent\/api-card\.md$|tests\/benchmarks\/runtime-scenarios\.ts|scripts\/runtime-benchmark-child\.ts|tools\/codemod\/test\/fixtures|tools\/graph\/test\/fixtures\/.*0-4|tools\/graph\/test\/renamed-exports\.test\.mjs$|tests\/container-names\.test\.ts$|tests\/fixtures\/api-naming\/)/;
const files = [...new Set(patterns.flatMap(pattern => globSync(pattern)))].filter(file => !excluded.test(file)).sort();
const rules = [
  [/(['"])(di-bag\/node)\1/g, (_m, quote) => `${quote}di-bag${quote}`, 'root import'],
  [/(\/src)\/node(?=['"])/g, '$1', 'source root import'],
  [/\bCheckedScopeLifetimes\b/g, 'CheckedChildContainerLifetimes', 'lifetime type'],
  [/\bDisjointScopeSelection\b/g, 'DisjointChildContainerSelection', 'disjoint type'],
  [/\bScopeOptions\b/g, 'CreateChildContainerOptions', 'child options type'],
  [/\bObserverOptions\b/g, 'LifecycleObserver', 'observer type'],
  [/\.inspectGraph\(/g, '.graphSnapshot(', 'graph snapshot'],
  [/\.inspectCollection\(/g, '.serviceSnapshot(', 'collection snapshot'],
  [/\.inspect\(/g, '.serviceSnapshot(', 'service snapshot'],
  [/\.renameExport\(\s*([^,()]+?)\s*,\s*([^,()]+?)\s*\)/g, '.withRenamedExport({ currentExportKey: $1, newExportKey: $2 })', 'module export bag'],
  [/\bobservers\s*:/g, 'lifecycleObservers:', 'observer list field'],
  [/\bonEvent\s*:/g, 'onLifecycleEvent:', 'observer event field'],
  [/\bonError\s*:/g, 'onObserverFailure:', 'observer failure field'],
  [/\bonEvent\s*\(/g, 'onLifecycleEvent(', 'observer event method'],
  [/\bonError\s*\(/g, 'onObserverFailure(', 'observer failure method'],
];
const inventory = { before: {}, changes: {}, after: {} };
const retired = /\.(?:createScope|fork|inspect|inspectCollection|inspectGraph|renameExport)\(|\b(?:ScopeOptions|CheckedScopeLifetimes|DisjointScopeSelection|ObserverOptions)\b|\b(?:observers\s*:|onEvent\s*[:(]|onError\s*[:(])/g;
for (const file of files) {
  const unresolved = readFileSync(file, 'utf8').match(/\.(?:createScope|fork)\s*\(/g) ?? [];
  if (unresolved.length) throw new Error(`${file}: ${unresolved.length} derivation call(s) require an explicit migration to the selected container signature before this script writes anything`);
}
for (const file of files) {
  let text = readFileSync(file, 'utf8');
  inventory.before[file] = [...text.matchAll(retired)].length;
  const counts = {};
  for (const [pattern, replacement, label] of rules) {
    let count = 0;
    text = text.replace(pattern, (...args) => {
      count++;
      return typeof replacement === 'function' ? replacement(...args) : replacement.replace(/\$(\d+)/g, (_m, n) => args[Number(n)]);
    });
    if (count) counts[label] = count;
  }
  inventory.changes[file] = counts;
  inventory.after[file] = [...text.matchAll(retired)].length;
  if (inventory.before[file] > 0 && Object.keys(counts).length === 0) throw new Error(`${file}: retired inventory changed by no rule`);
  writeFileSync(file, text);
}
writeFileSync('/tmp/di-bag-phase-06/untyped-inventory.json', `${JSON.stringify(inventory, null, 2)}\n`);
if (Object.values(inventory.after).some(count => count !== 0)) throw new Error('retired names remain; inspect untyped-inventory.json');
