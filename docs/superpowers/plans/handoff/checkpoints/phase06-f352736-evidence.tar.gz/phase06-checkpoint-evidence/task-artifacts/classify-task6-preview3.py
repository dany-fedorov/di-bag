import json
from pathlib import Path
p=Path('/tmp/di-bag-phase-06/task6-preview3-post-alias-report.txt')
d=json.loads(p.read_text())
rows=[]
for x in d['manual']:
 f,r,t=x['file'],x['reason'],x['text']
 owner=action=None
 if 'buildModule is referenced without being called' in r:
  owner,action='current-method-reference','retain current buildModule reference unchanged'
 elif 'this import names the file with an extension' in r:
  owner,action='runtime-import-control','retain explicit source-file import control unchanged'
 elif ('receiver of of has type any' in r or 'of is destructured' in r or 'of is referenced without' in r or 'token creation cannot be traced' in r):
  owner,action='single-token-control','retain .of single-service token creation unchanged'
 elif 'withConfiguration' in r and f=='tests/container-names.test.ts':
  owner,action='task4-expand-control','retain deliberate observers+lifecycleObservers conflict unchanged through Task9'
 elif 'withConfiguration' in r and f=='tests/runtime-diagnostics.test.ts':
  owner,action='malformed-runtime-control','retain null malformed-argument probe unchanged'
 elif 'argument 1 of close is not a literal' in r:
  owner,action='task6-hand-options','rename signal/timeoutMs at the options construction site'
 elif 'renameExport' in r:
  owner,action='task6-hand-member','rename receiver member/reference to withRenamedExport and preserve payload'
 elif 'createScope' in r:
  owner,action='task6-hand-derivation','migrate member/reference to createChildContainer and adapt positional/options shape while preserving invalid controls'
 elif 'fork' in r:
  owner,action='task6-hand-derivation','migrate member/reference to createIndependentContainer and adapt positional shape while preserving invalid controls'
 elif 'receiver of inspect has type any' in r:
  owner,action='task6-hand-snapshot','rename to serviceSnapshot and preserve assertions/invalid payload'
 elif f.startswith('tools/graph/test/fixtures/') and any(f'receiver of {m}' in r for m in ('register','installModule','build','buildModule')):
  owner,action='task6-current-graph-fixture','hand migrate old builder member and argument shape; preserve split-builder unresolved semantics'
 elif f.startswith('scripts/agent-eval/') and 'receiver of buildModule' in r:
  owner,action='task6-agent-fixture','hand migrate module options shape without completing skeleton'
 elif f=='tests/platform/portable/contract.ts' and 'receiver of buildModule' in r:
  owner,action='current-erased-portable-control','retain already-current erased buildModule call and options unchanged'
 elif f=='tests/final-adversarial-runtime-fixture.ts' and any(f'receiver of {m}' in r for m in ('buildModule','register','installModule')):
  owner,action='current-erased-runtime-control','retain already-current erased member and options unchanged'
 else:
  owner,action='UNCLASSIFIED','UNCLASSIFIED'
 rows.append({**x,'owner':owner,'action':action})
Path('/tmp/di-bag-phase-06/task6-preview3-manual-classification.json').write_text(json.dumps(rows,indent=2)+'\n')
from collections import Counter
summary=Counter(x['owner'] for x in rows)
Path('/tmp/di-bag-phase-06/task6-preview3-manual-classification-summary.txt').write_text('\n'.join(f'{n:3} {k}' for k,n in sorted(summary.items()))+'\n')
print(Path('/tmp/di-bag-phase-06/task6-preview3-manual-classification-summary.txt').read_text(),end='')
print('unclassified',sum(x['owner']=='UNCLASSIFIED' for x in rows))
