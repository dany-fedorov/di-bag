### Task 6: Run the codemod once over typed call sites

**Files:**
- Modify: typed `.ts` and `.tsx` files under `tests/`, `examples/`, `scripts/agent-eval/`, and `tools/graph/test/fixtures/`
- Modify: older codemod expected fixtures that emit a phase-6 name
- Create: `/tmp/di-bag-phase-06/codemod-report.txt` (untracked)

**Interfaces:**
- Consumes: dual old/new declarations and Task 5's codemod.
- Produces: typed code on phase-6 names except explicit negative and codemod-input fixtures.

- [ ] **Step 1: Rebuild, preview, and read every manual item**

```bash
npm run build
node tools/codemod/cli.mjs --project tsconfig.json --library-root src --library-root dist --extra-files 'tests/types/negative/*.ts' --extra-files 'scripts/agent-eval/**/*.ts' --extra-files 'tools/graph/test/fixtures/ready-chain.ts' --extra-files 'tools/graph/test/fixtures/split-builder.ts' --extra-files 'tools/graph/test/fixtures/cross-module/*.ts' --extra-files 'tools/graph/test/fixtures/consumer/src/**/*.ts' --report /tmp/di-bag-phase-06/codemod-report.txt
```

Expected: rewrites outside `src`; every manual item has a file, line, and exact Task-5 reason. The explicit extra-file roots include the 31 agent-eval TypeScript files and 13 current graph fixture files absent from the root project. Preserve `tools/graph/test/fixtures/builder-names-0-4.ts` as the original compatibility input and the already-current `builder-names-0-5.ts`; neither is a write target. Keep `split-builder.ts` and its intentional unresolved-graph semantics in the migrated scope.

- [ ] **Step 2: Apply exactly once and resolve manual items**

```bash
node tools/codemod/cli.mjs --project tsconfig.json --library-root src --library-root dist --extra-files 'tests/types/negative/*.ts' --extra-files 'scripts/agent-eval/**/*.ts' --extra-files 'tools/graph/test/fixtures/ready-chain.ts' --extra-files 'tools/graph/test/fixtures/split-builder.ts' --extra-files 'tools/graph/test/fixtures/cross-module/*.ts' --extra-files 'tools/graph/test/fixtures/consumer/src/**/*.ts' --write --report /tmp/di-bag-phase-06/codemod-report.txt
```

Migrate each reported `ScopeOptions` annotation, receiver typed `any`, spread, or indirect options object at its construction site. Do not rerun the codemod.

**Selected S5 spelling requires an explicit hand migration.** The shipped map remains original-0.4 `Bag.inspectAll -> serviceSnapshot`. The engine's initial name gates use only `from` spellings, so current `inspectCollection` calls and references are neither rewritten nor reported. Do not add a fictional 0.4 map entry or a transitive map hop. Capture a separate exact `inspectCollection` inventory before the write, then retain its hand-edit diff separately from the checker report. The reviewed Phase 6 entry inventory has 26 textual rows in eleven typed files: seven in `tests/collection-tokens.test.ts` (including an operation literal), two in `tests/contributions-runtime-fixture.ts`, three in `tests/contributions.test.ts`, and one each in `tests/final-adversarial-runtime-fixture.ts`, `tests/nested-modules.test.ts`, `tests/observers-runtime-fixture.ts`, `tests/observers.test.ts`, and `tests/types/collection-tokens.ts`; six in `tests/types/negative/contributions.ts`; and three old reflected-binding rows across `tests/types/contributions.ts` and its consumer. Recount at execution and explain any delta.

Migrate those member uses to `serviceSnapshot`, preserving all other negative markers and output assertions. Preserve the old collection-only reflected producer context: rename its binding to `collectionSnapshotMethod`, assign `bag.serviceSnapshot`, and update its existing consumer import/call without deleting the `reflectedSnapshots` exact assertion. Keep Task3's separate `serviceSnapshotMethod` on `aggregateBag`; that fixture additionally proves named snapshots in a different registration context.

The two old method-specific wrong-kind checks in `tests/collection-tokens.test.ts` need a deliberate semantic adaptation: `inspect(collection)` and `inspectCollection(single)` both become valid `serviceSnapshot` calls. Assert lazy collection-array and single-service snapshots for those valid calls, then retain two genuine token-kind rejections by passing a forged single-service token for the collection graph's symbol and a forged collection token for the single-service graph's symbol. Both must assert `DI_BAG_WRONG_TOKEN_KIND` and exact `serviceSnapshot` operation/kind details. Keep the separate `resolve` and `resolveCollection` wrong-kind assertions unchanged. This follows the specified snapshot consolidation and does not waive graph-kind validation.

- [ ] **Step 3: Audit and test**

```bash
git diff --check
git diff --stat
git diff -- tests/types/negative
grep -rnE '\.(createScope|fork|inspect|inspectCollection|inspectGraph|renameExport)\(' tests examples scripts/agent-eval tools/graph/test/fixtures --include='*.ts' --include='*.tsx'
grep -rnE "from ['\"](di-bag/node|.*src/node)['\"]" tests examples scripts/agent-eval tools/graph/test/fixtures --include='*.ts' --include='*.tsx'
npm run typecheck
bun test tests/container-derivation.test.ts tests/container-names.test.ts tests/scopes.test.ts tests/selected-scopes.test.ts tests/modules.test.ts tests/observers.test.ts
```

Expected: greps show only explicit rejection/codemod inputs; checks pass.

- [ ] **Step 4: Commit the mechanical rewrite by itself**

Preserve the exact checker-written patch before resolving manual items and retain each hand-migration patch separately. Commit the mechanical rewrite separately only if that tree passes its required gates; otherwise review and commit the coherent tested result while reporting the mechanical and hand-written provenance precisely. The heading does not authorize an unverified intermediate source commit or attributing the `inspectCollection` migration to the checker.

```bash
git add tests examples scripts/agent-eval tools/graph/test/fixtures tools/codemod/test/fixtures
git commit -F - <<'MSG'
refactor!: move typed call sites to container APIs

node tools/codemod/cli.mjs --project tsconfig.json --library-root src --library-root dist --extra-files 'tests/types/negative/*.ts' --extra-files 'scripts/agent-eval/**/*.ts' --extra-files 'tools/graph/test/fixtures/ready-chain.ts' --extra-files 'tools/graph/test/fixtures/split-builder.ts' --extra-files 'tools/graph/test/fixtures/cross-module/*.ts' --extra-files 'tools/graph/test/fixtures/consumer/src/**/*.ts' --write

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01URAuHKzgTPsPixaqiUvysL
MSG
```

---

