import { resolve } from 'node:path';
import { writeFileSync } from 'node:fs';
import ts from '/tmp/di-bag-resume-20260921/phase06/node_modules/typescript/lib/typescript.js';

const root = '/tmp/di-bag-resume-20260921/phase06';
const producerPath = resolve(root, 'tests/types/lifetimes.ts');
const output = resolve('/tmp/di-bag-phase-06/lifetimes-declaration-output');
const options = {
  strict: true,
  noUncheckedIndexedAccess: true,
  exactOptionalPropertyTypes: true,
  skipLibCheck: true,
  types: [],
  target: ts.ScriptTarget.ES2022,
  module: ts.ModuleKind.NodeNext,
  moduleResolution: ts.ModuleResolutionKind.NodeNext,
  declaration: true,
  emitDeclarationOnly: true,
  rootDir: root,
  outDir: output,
};
const declarations = new Map();
const host = ts.createCompilerHost(options);
host.writeFile = (name, text) => declarations.set(name, text);
const program = ts.createProgram([producerPath], options, host);
const emitted = program.emit();
const diagnostics = [...ts.getPreEmitDiagnostics(program), ...emitted.diagnostics];
if (diagnostics.length) {
  console.error(diagnostics.map(error => ts.flattenDiagnosticMessageText(error.messageText, '\n')).join('\n'));
  process.exit(1);
}
const path = resolve(output, 'tests/types/lifetimes.d.ts');
const declaration = declarations.get(path);
if (declaration === undefined) throw new Error(`missing ${path}`);
const lines = declaration.split('\n').filter(line => line.includes('Container') || line.includes('defaultBag'));
writeFileSync('/tmp/di-bag-phase-06/task6-container-alias-emitted-excerpt.txt', lines.join('\n') + '\n');
console.log(lines.join('\n'));
