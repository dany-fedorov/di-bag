# Phase 6 Task 5 implementation report

Candidate: working tree over `867ba421fc45f9490c499d3d806ae3971b3525b3`

## Result

- Added the closed Phase 6 rename-map entries while retaining every Phase 1–5 entry and original-0.4 owner.
- Added and registered `container-derivation`; selected fallback output keeps key/provider pairs positional and rewrites only the share-only/third options object field.
- The transform obtains method and field targets from the entry-bound APIs, quotes the alternate `parent-keys` role safely, preserves nested rewrites/trivia through `assemble`, and reports nonliteral/malformed scope options without partial writes.
- Added the complete vendored-0.4 fixture with all three scope forms, both fork forms, exact one-row manual report, nested transforms, import/type/property renames, and collection-token/read composition.
- Updated only the two shipped-map collection goldens from the Phase 4 intermediate `inspectCollection` target to final `serviceSnapshot`; custom-map fixtures are unchanged.
- Added the transform to the exact package inventory and retained all five transform registrations.

## TDD evidence

- Preliminary isolated Node run `phase06-task5-codemod-red` exited 1 but exposed only file-wrapper failures. It is retained as runner/setup evidence and is not claimed as the meaningful RED.
- Authentic RED: `phase06-task5-codemod-authentic-red`, Node 24.20.0 with `--test-isolation=none`, exit 1, `resourceStopped:false`, minimum 14.25 GiB. Assertions showed the container fixture retained old derivation/import/type names and `inspectCollection`, the registry lacked `container-derivation`, and the alternate role-name call stayed unchanged.
- Focused GREEN: `phase06-task5-codemod-focused-green`, 6/6 pass, exit 0, `resourceStopped:false`, minimum 14.19 GiB.
- Full attempt 1: `phase06-task5-codemod-full`, exit 1, 0.4 fixture rejected the plan's three-argument `ScopeOptions`; no implementation test failed.
- Controller ruling removed only that impossible input/expected declaration. Evidence: `tools/codemod/test/fixtures/node_modules/di-bag/dist/scope-types.d.ts:13` defines exactly `ScopeOptions<R,S>`.
- Full attempt 2: `phase06-task5-codemod-full-r2`, 74/75 pass, exit 1, `resourceStopped:false`, minimum 14.06 GiB. The remaining printed nested override returned a `Bag` where service `a` required `number`.
- Controller ruling changed that provider to resolve the nested `inner` service, preserving the nested transform proof and returning `number`.
- Final full GREEN: `phase06-task5-codemod-full-r3`, Node 24.20.0, `--test-isolation=none`, 75/75 pass, exit 0, `resourceStopped:false`, minimum 14.41 GiB. It includes the escalated nested `npm pack --dry-run --json --ignore-scripts` inventory assertion.

Guard JSON/logs are under `/tmp/di-bag-resume-20260921/gates-phase00/` with the labels above.

## Review scope

- Exact package: `.superpowers/sdd/2026-09-21-07-container-renames/review-867ba42..working.diff`
- Eleven owned files under `tools/codemod`; no source, docs, plan, dependency, index, or branch mutation.
- `git diff --check`, JavaScript syntax checks, and JSON parsing pass.
- No commit was created; independent review is required before the standard-trailer commit.
