# Phase 6 Task 7 Step 3 graph report

Candidate: working tree over `cff5a2b25109089fcdb6952a76cd6499dd9e87b9`

## Result

- Extended only installed-module rename unwrapping with `withRenamedExport({ currentExportKey, newExportKey })`.
- A bag is traceable only when it is one object literal containing exactly the two plain named properties and both explicit values are statically literal strings after outer-expression unwrapping. String-literal property names remain valid; shorthand and identifier-valued properties, spread, computed, extra, duplicate, missing, and nonliteral bags stop traversal and leave the entire install opaque.
- Mixed positional `renameExport` and bag `withRenamedExport` calls retain source application order through the existing outer-to-inner walk plus `unshift` behavior.
- A same-name `withRenamedExport` is unwrapped as an identity operation, so it preserves the module export and its resolved host dependency.
- Existing positional parsing, terminal recognition, builder shapes, module lists, contribution omission parity, graph schema, and `kind: 'bag'` values are unchanged.
- README now states explicitly that source `buildContainer()` emits schema-v1 `kind: "bag"`.

## TDD and gate evidence

- RED `phase06-task7-graph-red`: the mixed chain remained a raw multiline install expression instead of resolving to module `graph.ts:3`; exit 1, `resourceStopped:false`, minimum 12.36 GiB.
- Focused GREEN `phase06-task7-graph-focused-green`: 1/1 passed, exit 0, `resourceStopped:false`, minimum 10.19 GiB.
- Full graph GREEN `phase06-task7-graph-full`: 23/23 passed under Node 24.20.0 with `--test-isolation=none`, including package inventory; exit 0, `resourceStopped:false`, minimum 12.65 GiB.
- Review RED `phase06-task7-graph-fix1-red2`: one aggregate assertion exposed all three concrete defects in the reviewed candidate: same-name renames produced an unresolved dependency, while shorthand and identifier-valued bags were falsely resolved to the module. The focused test failed as required; exit 1, `resourceStopped:false`, minimum 14.52 GiB.
- Review focused GREEN `phase06-task7-graph-fix1-green`: the same test passed 1/1 after the narrow literal-only and identity handling fix; exit 0, `resourceStopped:false`, minimum 14.31 GiB.
- Review full GREEN `phase06-task7-graph-fix1-full`: 23/23 passed under Node 24.20.0 with `--test-isolation=none`, including package inventory; exit 0, `resourceStopped:false`, minimum 13.80 GiB.
- Logs and guard JSON are under `/tmp/di-bag-resume-20260921/gates-phase00/` with those labels.

## Review scope

- Superseded initial package: `.superpowers/sdd/2026-09-21-07-container-renames/review-cff5a2b..working-graph.diff`
- Final fix-round package: `.superpowers/sdd/2026-09-21-07-container-renames/review-cff5a2b..working-graph-r2.diff`
- Files: `tools/graph/lib/extract.mjs`, `tools/graph/README.md`, and new `tools/graph/test/renamed-exports.test.mjs` only.
- `git diff --check` and JavaScript syntax checks pass. No TypeScript fixture, schema JSON, source, docs tree, plan, index, or branch mutation.
- No commit was created; independent review is required.
