# Task 5 — codemod map and derivation transform

Authoritative range: plan07 lines 1344–1720.

- Add exact closed rename-map entries and the `container-derivation` transform; retain entry-bound `transformNames`/`nameForRole` composition.
- Reshape all three `createScope` and both `fork` forms. Preserve comments, whitespace, trailing commas, nested transforms, and manual whole-call behavior for uncertain/spread cases.
- Keep owner strings on 0.4 declarations. Do not change dispatcher/no-op semantics.
- Fixture must pin exact output plus exact manual report; retain all older Phase 5 fixture behavior.
- Run focused transform/map/package tests and full `codemod:check`.
- Commit `tools/codemod` only as `feat(codemod): migrate container APIs`.

## Reviewed entry corrections

Read the latest authoritative root plan07 Task5: retain all five registered transforms, use a bound const collection symbol in both new fixture forms, and change only the two named shipped-map collection expected outputs to serviceSnapshot. Custom-map fixtures keep their own contracts. See /tmp/di-bag-resume-20260921/phase06-task5-entry-audit.md.


## Controller update: e6df58b

The authoritative plan is /home/df/wd/personal/di-bag/docs/superpowers/plans/2026-09-21-07-container-renames.md (root next e6df58b), not this worktree's entry copy. S3 preferred bag failed all three serious candidates. Selected replacements are positional; preserve no-argument/empty-bag/undefined/share-only forms. Root plan explicitly records the independently reviewed fallback dependency annotations and four precise negative marker changes, preserving rejected bag evidence. Task5 goldens and mapped-role test now use positional pairs and a quoted `parent-keys` sharing field; Task7 current-call examples and inventory are positional. Compiler and declaration focused checks passed before additional required regression controls; cumulative measurement and combined review still pending at this update.
