# Phase 6 Task 7 graph review

Reviewed frozen diff `c17d1c2aa8e5e25825b211f3ec2ce0d48c48b3f07d11af2bc0c45e675b0930a2` over `cff5a2b25109089fcdb6952a76cd6499dd9e87b9` and report `c0a2fd8f885300fe3567f812a7dbec85d1866a784c85b6e212e445ad5b6ecf95`.

## Findings

- **Important — shorthand/identifier option values are interpreted as variable names rather than their string values** (`tools/graph/lib/extract.mjs:151-164`). `keyText(identifier)` returns the identifier spelling. Thus `const currentExportKey = 'clock'; const newExportKey = 'time'; module.withRenamedExport({ currentExportKey, newExportKey })` is recorded as `currentExportKey -> newExportKey`, not `clock -> time`, and can emit a false unresolved issue. Explicit identifier-valued properties have the same problem. The new parser should resolve statically evident string-literal constants (including `as const`) or classify the whole bag opaque; it must not guess a value. Add one discriminating shorthand/constant case and one unknown-value opacity case. This is confined to the new bag parser; existing positional parsing need not change.

## Spec review

- `renamedExportPair` admits only a one-argument object literal with exactly the two plain, unique option properties. Spread, computed, extra, duplicate, missing, and nonliteral bags cannot be partially interpreted. Value certainty still needs the fix above.
- An untraceable outer or inner bag leaves the whole install unresolved, so the extractor does not apply a guessed prefix of a rename chain.
- The outer-to-inner walk and `unshift` preserve runtime application order. The mixed `clock -> time -> now` fixture proves composition across positional `renameExport` and bag `withRenamedExport`.
- Existing positional parsing remains in place. The full 23-test graph suite covers the retained bilingual terminals, builder shapes, module lists, contribution behavior, inventory, and schema.
- Output vocabulary is unchanged: source `buildContainer()` remains schema-v1 `kind: "bag"`, and the README now states that compatibility contract.

## Evidence

- Meaningful RED `phase06-task7-graph-red`: exit 1 because the new chain was still opaque.
- Focused GREEN `phase06-task7-graph-focused-green`: 1/1 passed, exit 0, no resource stop.
- Full GREEN `phase06-task7-graph-full`: 23/23 passed, exit 0, no resource stop.
- The frozen diff hash and report hash match the supplied package; `git diff --check` is clean.

## R2 closure

Reviewed final fix package `f6b56e096e1cd0d4af0c01fd3e2595a8fef4100106574c733593a62cc56a9313` and updated report `8dd1ab7e7a83afc0433adf9614db2b5f8003d1b09aa61be18389ad13fcb76654`.

- The new bag parser now accepts only explicit statically literal string values after outer-expression unwrapping. Shorthand, explicit identifier values, nonliteral bags, and spread bags remain wholly opaque, so identifier spellings cannot be mistaken for runtime export names.
- Same-name `withRenamedExport` produces an empty rename step while still unwrapping its receiver. The host-resolution control proves the original export survives; it is no longer deleted by `set` followed by `delete`.
- The mixed-chain control still proves source-order composition. The old positional branch is unchanged semantically and the broader bilingual suite remains intact.
- Review RED exposed all three defects; focused GREEN passes 1/1 and full graph GREEN passes 23/23, with no resource stop.

The Important finding and the independently identified same-name identity defect are addressed. No open findings.

**Verdict:** Spec compliant and quality approved. Ready to commit before Task 6 migrates the current graph fixtures.
