import type { ReplacementOutput } from '../src/types';
import type { ReplacementOutput as LegacyOutput } from './legacy-types';
import type { Registrations, Registration } from '../src/registration';
import type { Provider } from '../src/provider';
type Equal<A, B> = (<T>() => T extends A ? 1 : 2) extends (<T>() => T extends B ? 1 : 2) ? true : false;
type Assert<T extends true> = T;
declare const token: unique symbol;
type Consumer<N extends object> = (deps: N) => void;
type Maps = [
    never,
    any,
    {},
    Registrations,
    {
        value: () => number;
    },
    {
        value: () => number;
        use: Consumer<{
            value: number;
        }>;
    },
    {
        value: () => number;
        a: Consumer<{
            value: number;
        }>;
        b: Consumer<{
            value: string;
        }>;
    },
    {
        value: () => number;
        use: Consumer<{
            value: number | string;
        }>;
    },
    {
        value: () => number;
        use: Consumer<{
            value?: number;
        }>;
    },
    {
        value: () => number;
        use: Consumer<{
            value?: number | undefined;
        }>;
    },
    {
        value: () => number;
        use?: Consumer<{
            value: number;
        }>;
    },
    {
        readonly value: () => number;
        readonly use: Consumer<{
            readonly value: number;
        }>;
    },
    {
        [token]: () => number;
        use: Consumer<{
            [token]: number;
        }>;
    },
    {
        0: () => number;
        use: Consumer<{
            0: number;
        }>;
    },
    {
        value: () => number;
        use: Consumer<{
            value: number;
        }> | Consumer<{
            value: string;
        }>;
    },
    {
        value: () => number;
        use: Consumer<{
            value: number;
        }>;
    } | {
        value: () => string;
        use: Consumer<{
            value: string;
        }>;
    },
    {
        value: () => number;
        first: Consumer<{
            value: number;
        }>;
    } | {
        value: () => string;
        second: Consumer<{
            value: string;
        }>;
    },
    {
        value: () => number;
        use: Registration;
    },
    {
        value: () => number;
        use: never;
    },
    {
        value: () => number;
        use: any;
    },
    {
        value: () => number;
        use: Provider<Consumer<{
            value: number;
        }>>;
    },
    {
        value: Consumer<{
            value: number;
        }>;
    },
    {
        [key: string]: Consumer<{
            value: number;
        }>;
    },
    {
        [key: number]: Consumer<{
            value: number;
        }>;
    },
    {
        [key: symbol]: Consumer<{
            value: number;
        }>;
    },
    {
        value: () => number;
        use: Consumer<{
            value: number;
        }>;
    } & {
        other: Consumer<{
            value: string;
        }>;
    },
    {
        value: () => number;
        use: Consumer<{
            value: never;
        }>;
    },
    {
        value: () => number;
        use: Consumer<{
            value: any;
        }>;
    },
    {
        value: () => number;
        use: Consumer<{
            value: unknown;
        }>;
    },
    {
        value: () => number;
        use: Consumer<{
            value: number;
        }> | Consumer<{
            other: string;
        }>;
    }
];
type Keys = [never, any, 'value', 'use', 'missing', 'value' | 'other', string, number, symbol, typeof token, 0, PropertyKey];
type Constraints = [never, any, unknown, {
    readonly needs: {
        value: number;
    };
}, {
    readonly needs: {
        value: string | number;
    };
}, {
    readonly needs: {
        value?: number;
    };
}, {
    readonly needs: {
        value: number;
    };
} | {
    readonly needs: {
        value: string;
    };
}, {
    readonly needs: {
        [token]: number;
    };
}];
export type ExactUnion = Assert<Equal<ReplacementOutput<Maps[7], 'value'>, number | string>>;
export type ExactAcrossConsumers = Assert<Equal<ReplacementOutput<Maps[6], 'value'>, never>>;
export type ExactOptional = Assert<Equal<ReplacementOutput<Maps[8], 'value'>, number>>;
export type ExactExplicitUndefined = Assert<Equal<ReplacementOutput<Maps[9], 'value'>, number | undefined>>;
export type ExactNoOldSelf = Assert<Equal<ReplacementOutput<Maps[21], 'value'>, unknown>>;
export type Case_0_0 = Assert<Equal<ReplacementOutput<Maps[0], Keys[0]>, LegacyOutput<Maps[0], Keys[0]>>>;
export type Case_0_1 = Assert<Equal<ReplacementOutput<Maps[0], Keys[1]>, LegacyOutput<Maps[0], Keys[1]>>>;
export type Case_0_2 = Assert<Equal<ReplacementOutput<Maps[0], Keys[2]>, LegacyOutput<Maps[0], Keys[2]>>>;
export type Case_0_3 = Assert<Equal<ReplacementOutput<Maps[0], Keys[3]>, LegacyOutput<Maps[0], Keys[3]>>>;
export type Case_0_4 = Assert<Equal<ReplacementOutput<Maps[0], Keys[4]>, LegacyOutput<Maps[0], Keys[4]>>>;
export type Case_0_5 = Assert<Equal<ReplacementOutput<Maps[0], Keys[5]>, LegacyOutput<Maps[0], Keys[5]>>>;
export type Case_0_6 = Assert<Equal<ReplacementOutput<Maps[0], Keys[6]>, LegacyOutput<Maps[0], Keys[6]>>>;
export type Case_0_7 = Assert<Equal<ReplacementOutput<Maps[0], Keys[7]>, LegacyOutput<Maps[0], Keys[7]>>>;
export type Case_0_8 = Assert<Equal<ReplacementOutput<Maps[0], Keys[8]>, LegacyOutput<Maps[0], Keys[8]>>>;
export type Case_0_9 = Assert<Equal<ReplacementOutput<Maps[0], Keys[9]>, LegacyOutput<Maps[0], Keys[9]>>>;
export type Case_0_10 = Assert<Equal<ReplacementOutput<Maps[0], Keys[10]>, LegacyOutput<Maps[0], Keys[10]>>>;
export type Case_0_11 = Assert<Equal<ReplacementOutput<Maps[0], Keys[11]>, LegacyOutput<Maps[0], Keys[11]>>>;
export type Case_1_0 = Assert<Equal<ReplacementOutput<Maps[1], Keys[0]>, LegacyOutput<Maps[1], Keys[0]>>>;
export type Case_1_1 = Assert<Equal<ReplacementOutput<Maps[1], Keys[1]>, LegacyOutput<Maps[1], Keys[1]>>>;
export type Case_1_2 = Assert<Equal<ReplacementOutput<Maps[1], Keys[2]>, LegacyOutput<Maps[1], Keys[2]>>>;
export type Case_1_3 = Assert<Equal<ReplacementOutput<Maps[1], Keys[3]>, LegacyOutput<Maps[1], Keys[3]>>>;
export type Case_1_4 = Assert<Equal<ReplacementOutput<Maps[1], Keys[4]>, LegacyOutput<Maps[1], Keys[4]>>>;
export type Case_1_5 = Assert<Equal<ReplacementOutput<Maps[1], Keys[5]>, LegacyOutput<Maps[1], Keys[5]>>>;
export type Case_1_6 = Assert<Equal<ReplacementOutput<Maps[1], Keys[6]>, LegacyOutput<Maps[1], Keys[6]>>>;
export type Case_1_7 = Assert<Equal<ReplacementOutput<Maps[1], Keys[7]>, LegacyOutput<Maps[1], Keys[7]>>>;
export type Case_1_8 = Assert<Equal<ReplacementOutput<Maps[1], Keys[8]>, LegacyOutput<Maps[1], Keys[8]>>>;
export type Case_1_9 = Assert<Equal<ReplacementOutput<Maps[1], Keys[9]>, LegacyOutput<Maps[1], Keys[9]>>>;
export type Case_1_10 = Assert<Equal<ReplacementOutput<Maps[1], Keys[10]>, LegacyOutput<Maps[1], Keys[10]>>>;
export type Case_1_11 = Assert<Equal<ReplacementOutput<Maps[1], Keys[11]>, LegacyOutput<Maps[1], Keys[11]>>>;
export type Case_2_0 = Assert<Equal<ReplacementOutput<Maps[2], Keys[0]>, LegacyOutput<Maps[2], Keys[0]>>>;
export type Case_2_1 = Assert<Equal<ReplacementOutput<Maps[2], Keys[1]>, LegacyOutput<Maps[2], Keys[1]>>>;
export type Case_2_2 = Assert<Equal<ReplacementOutput<Maps[2], Keys[2]>, LegacyOutput<Maps[2], Keys[2]>>>;
export type Case_2_3 = Assert<Equal<ReplacementOutput<Maps[2], Keys[3]>, LegacyOutput<Maps[2], Keys[3]>>>;
export type Case_2_4 = Assert<Equal<ReplacementOutput<Maps[2], Keys[4]>, LegacyOutput<Maps[2], Keys[4]>>>;
export type Case_2_5 = Assert<Equal<ReplacementOutput<Maps[2], Keys[5]>, LegacyOutput<Maps[2], Keys[5]>>>;
export type Case_2_6 = Assert<Equal<ReplacementOutput<Maps[2], Keys[6]>, LegacyOutput<Maps[2], Keys[6]>>>;
export type Case_2_7 = Assert<Equal<ReplacementOutput<Maps[2], Keys[7]>, LegacyOutput<Maps[2], Keys[7]>>>;
export type Case_2_8 = Assert<Equal<ReplacementOutput<Maps[2], Keys[8]>, LegacyOutput<Maps[2], Keys[8]>>>;
export type Case_2_9 = Assert<Equal<ReplacementOutput<Maps[2], Keys[9]>, LegacyOutput<Maps[2], Keys[9]>>>;
export type Case_2_10 = Assert<Equal<ReplacementOutput<Maps[2], Keys[10]>, LegacyOutput<Maps[2], Keys[10]>>>;
export type Case_2_11 = Assert<Equal<ReplacementOutput<Maps[2], Keys[11]>, LegacyOutput<Maps[2], Keys[11]>>>;
export type Case_3_0 = Assert<Equal<ReplacementOutput<Maps[3], Keys[0]>, LegacyOutput<Maps[3], Keys[0]>>>;
export type Case_3_1 = Assert<Equal<ReplacementOutput<Maps[3], Keys[1]>, LegacyOutput<Maps[3], Keys[1]>>>;
export type Case_3_2 = Assert<Equal<ReplacementOutput<Maps[3], Keys[2]>, LegacyOutput<Maps[3], Keys[2]>>>;
export type Case_3_3 = Assert<Equal<ReplacementOutput<Maps[3], Keys[3]>, LegacyOutput<Maps[3], Keys[3]>>>;
export type Case_3_4 = Assert<Equal<ReplacementOutput<Maps[3], Keys[4]>, LegacyOutput<Maps[3], Keys[4]>>>;
export type Case_3_5 = Assert<Equal<ReplacementOutput<Maps[3], Keys[5]>, LegacyOutput<Maps[3], Keys[5]>>>;
export type Case_3_6 = Assert<Equal<ReplacementOutput<Maps[3], Keys[6]>, LegacyOutput<Maps[3], Keys[6]>>>;
export type Case_3_7 = Assert<Equal<ReplacementOutput<Maps[3], Keys[7]>, LegacyOutput<Maps[3], Keys[7]>>>;
export type Case_3_8 = Assert<Equal<ReplacementOutput<Maps[3], Keys[8]>, LegacyOutput<Maps[3], Keys[8]>>>;
export type Case_3_9 = Assert<Equal<ReplacementOutput<Maps[3], Keys[9]>, LegacyOutput<Maps[3], Keys[9]>>>;
export type Case_3_10 = Assert<Equal<ReplacementOutput<Maps[3], Keys[10]>, LegacyOutput<Maps[3], Keys[10]>>>;
export type Case_3_11 = Assert<Equal<ReplacementOutput<Maps[3], Keys[11]>, LegacyOutput<Maps[3], Keys[11]>>>;
export type Case_4_0 = Assert<Equal<ReplacementOutput<Maps[4], Keys[0]>, LegacyOutput<Maps[4], Keys[0]>>>;
export type Case_4_1 = Assert<Equal<ReplacementOutput<Maps[4], Keys[1]>, LegacyOutput<Maps[4], Keys[1]>>>;
export type Case_4_2 = Assert<Equal<ReplacementOutput<Maps[4], Keys[2]>, LegacyOutput<Maps[4], Keys[2]>>>;
export type Case_4_3 = Assert<Equal<ReplacementOutput<Maps[4], Keys[3]>, LegacyOutput<Maps[4], Keys[3]>>>;
export type Case_4_4 = Assert<Equal<ReplacementOutput<Maps[4], Keys[4]>, LegacyOutput<Maps[4], Keys[4]>>>;
export type Case_4_5 = Assert<Equal<ReplacementOutput<Maps[4], Keys[5]>, LegacyOutput<Maps[4], Keys[5]>>>;
export type Case_4_6 = Assert<Equal<ReplacementOutput<Maps[4], Keys[6]>, LegacyOutput<Maps[4], Keys[6]>>>;
export type Case_4_7 = Assert<Equal<ReplacementOutput<Maps[4], Keys[7]>, LegacyOutput<Maps[4], Keys[7]>>>;
export type Case_4_8 = Assert<Equal<ReplacementOutput<Maps[4], Keys[8]>, LegacyOutput<Maps[4], Keys[8]>>>;
export type Case_4_9 = Assert<Equal<ReplacementOutput<Maps[4], Keys[9]>, LegacyOutput<Maps[4], Keys[9]>>>;
export type Case_4_10 = Assert<Equal<ReplacementOutput<Maps[4], Keys[10]>, LegacyOutput<Maps[4], Keys[10]>>>;
export type Case_4_11 = Assert<Equal<ReplacementOutput<Maps[4], Keys[11]>, LegacyOutput<Maps[4], Keys[11]>>>;
export type Case_5_0 = Assert<Equal<ReplacementOutput<Maps[5], Keys[0]>, LegacyOutput<Maps[5], Keys[0]>>>;
export type Case_5_1 = Assert<Equal<ReplacementOutput<Maps[5], Keys[1]>, LegacyOutput<Maps[5], Keys[1]>>>;
export type Case_5_2 = Assert<Equal<ReplacementOutput<Maps[5], Keys[2]>, LegacyOutput<Maps[5], Keys[2]>>>;
export type Case_5_3 = Assert<Equal<ReplacementOutput<Maps[5], Keys[3]>, LegacyOutput<Maps[5], Keys[3]>>>;
export type Case_5_4 = Assert<Equal<ReplacementOutput<Maps[5], Keys[4]>, LegacyOutput<Maps[5], Keys[4]>>>;
export type Case_5_5 = Assert<Equal<ReplacementOutput<Maps[5], Keys[5]>, LegacyOutput<Maps[5], Keys[5]>>>;
export type Case_5_6 = Assert<Equal<ReplacementOutput<Maps[5], Keys[6]>, LegacyOutput<Maps[5], Keys[6]>>>;
export type Case_5_7 = Assert<Equal<ReplacementOutput<Maps[5], Keys[7]>, LegacyOutput<Maps[5], Keys[7]>>>;
export type Case_5_8 = Assert<Equal<ReplacementOutput<Maps[5], Keys[8]>, LegacyOutput<Maps[5], Keys[8]>>>;
export type Case_5_9 = Assert<Equal<ReplacementOutput<Maps[5], Keys[9]>, LegacyOutput<Maps[5], Keys[9]>>>;
export type Case_5_10 = Assert<Equal<ReplacementOutput<Maps[5], Keys[10]>, LegacyOutput<Maps[5], Keys[10]>>>;
export type Case_5_11 = Assert<Equal<ReplacementOutput<Maps[5], Keys[11]>, LegacyOutput<Maps[5], Keys[11]>>>;
export type Case_6_0 = Assert<Equal<ReplacementOutput<Maps[6], Keys[0]>, LegacyOutput<Maps[6], Keys[0]>>>;
export type Case_6_1 = Assert<Equal<ReplacementOutput<Maps[6], Keys[1]>, LegacyOutput<Maps[6], Keys[1]>>>;
export type Case_6_2 = Assert<Equal<ReplacementOutput<Maps[6], Keys[2]>, LegacyOutput<Maps[6], Keys[2]>>>;
export type Case_6_3 = Assert<Equal<ReplacementOutput<Maps[6], Keys[3]>, LegacyOutput<Maps[6], Keys[3]>>>;
export type Case_6_4 = Assert<Equal<ReplacementOutput<Maps[6], Keys[4]>, LegacyOutput<Maps[6], Keys[4]>>>;
export type Case_6_5 = Assert<Equal<ReplacementOutput<Maps[6], Keys[5]>, LegacyOutput<Maps[6], Keys[5]>>>;
export type Case_6_6 = Assert<Equal<ReplacementOutput<Maps[6], Keys[6]>, LegacyOutput<Maps[6], Keys[6]>>>;
export type Case_6_7 = Assert<Equal<ReplacementOutput<Maps[6], Keys[7]>, LegacyOutput<Maps[6], Keys[7]>>>;
export type Case_6_8 = Assert<Equal<ReplacementOutput<Maps[6], Keys[8]>, LegacyOutput<Maps[6], Keys[8]>>>;
export type Case_6_9 = Assert<Equal<ReplacementOutput<Maps[6], Keys[9]>, LegacyOutput<Maps[6], Keys[9]>>>;
export type Case_6_10 = Assert<Equal<ReplacementOutput<Maps[6], Keys[10]>, LegacyOutput<Maps[6], Keys[10]>>>;
export type Case_6_11 = Assert<Equal<ReplacementOutput<Maps[6], Keys[11]>, LegacyOutput<Maps[6], Keys[11]>>>;
export type Case_7_0 = Assert<Equal<ReplacementOutput<Maps[7], Keys[0]>, LegacyOutput<Maps[7], Keys[0]>>>;
export type Case_7_1 = Assert<Equal<ReplacementOutput<Maps[7], Keys[1]>, LegacyOutput<Maps[7], Keys[1]>>>;
export type Case_7_2 = Assert<Equal<ReplacementOutput<Maps[7], Keys[2]>, LegacyOutput<Maps[7], Keys[2]>>>;
export type Case_7_3 = Assert<Equal<ReplacementOutput<Maps[7], Keys[3]>, LegacyOutput<Maps[7], Keys[3]>>>;
export type Case_7_4 = Assert<Equal<ReplacementOutput<Maps[7], Keys[4]>, LegacyOutput<Maps[7], Keys[4]>>>;
export type Case_7_5 = Assert<Equal<ReplacementOutput<Maps[7], Keys[5]>, LegacyOutput<Maps[7], Keys[5]>>>;
export type Case_7_6 = Assert<Equal<ReplacementOutput<Maps[7], Keys[6]>, LegacyOutput<Maps[7], Keys[6]>>>;
export type Case_7_7 = Assert<Equal<ReplacementOutput<Maps[7], Keys[7]>, LegacyOutput<Maps[7], Keys[7]>>>;
export type Case_7_8 = Assert<Equal<ReplacementOutput<Maps[7], Keys[8]>, LegacyOutput<Maps[7], Keys[8]>>>;
export type Case_7_9 = Assert<Equal<ReplacementOutput<Maps[7], Keys[9]>, LegacyOutput<Maps[7], Keys[9]>>>;
export type Case_7_10 = Assert<Equal<ReplacementOutput<Maps[7], Keys[10]>, LegacyOutput<Maps[7], Keys[10]>>>;
export type Case_7_11 = Assert<Equal<ReplacementOutput<Maps[7], Keys[11]>, LegacyOutput<Maps[7], Keys[11]>>>;
export type Case_8_0 = Assert<Equal<ReplacementOutput<Maps[8], Keys[0]>, LegacyOutput<Maps[8], Keys[0]>>>;
export type Case_8_1 = Assert<Equal<ReplacementOutput<Maps[8], Keys[1]>, LegacyOutput<Maps[8], Keys[1]>>>;
export type Case_8_2 = Assert<Equal<ReplacementOutput<Maps[8], Keys[2]>, LegacyOutput<Maps[8], Keys[2]>>>;
export type Case_8_3 = Assert<Equal<ReplacementOutput<Maps[8], Keys[3]>, LegacyOutput<Maps[8], Keys[3]>>>;
export type Case_8_4 = Assert<Equal<ReplacementOutput<Maps[8], Keys[4]>, LegacyOutput<Maps[8], Keys[4]>>>;
export type Case_8_5 = Assert<Equal<ReplacementOutput<Maps[8], Keys[5]>, LegacyOutput<Maps[8], Keys[5]>>>;
export type Case_8_6 = Assert<Equal<ReplacementOutput<Maps[8], Keys[6]>, LegacyOutput<Maps[8], Keys[6]>>>;
export type Case_8_7 = Assert<Equal<ReplacementOutput<Maps[8], Keys[7]>, LegacyOutput<Maps[8], Keys[7]>>>;
export type Case_8_8 = Assert<Equal<ReplacementOutput<Maps[8], Keys[8]>, LegacyOutput<Maps[8], Keys[8]>>>;
export type Case_8_9 = Assert<Equal<ReplacementOutput<Maps[8], Keys[9]>, LegacyOutput<Maps[8], Keys[9]>>>;
export type Case_8_10 = Assert<Equal<ReplacementOutput<Maps[8], Keys[10]>, LegacyOutput<Maps[8], Keys[10]>>>;
export type Case_8_11 = Assert<Equal<ReplacementOutput<Maps[8], Keys[11]>, LegacyOutput<Maps[8], Keys[11]>>>;
export type Case_9_0 = Assert<Equal<ReplacementOutput<Maps[9], Keys[0]>, LegacyOutput<Maps[9], Keys[0]>>>;
export type Case_9_1 = Assert<Equal<ReplacementOutput<Maps[9], Keys[1]>, LegacyOutput<Maps[9], Keys[1]>>>;
export type Case_9_2 = Assert<Equal<ReplacementOutput<Maps[9], Keys[2]>, LegacyOutput<Maps[9], Keys[2]>>>;
export type Case_9_3 = Assert<Equal<ReplacementOutput<Maps[9], Keys[3]>, LegacyOutput<Maps[9], Keys[3]>>>;
export type Case_9_4 = Assert<Equal<ReplacementOutput<Maps[9], Keys[4]>, LegacyOutput<Maps[9], Keys[4]>>>;
export type Case_9_5 = Assert<Equal<ReplacementOutput<Maps[9], Keys[5]>, LegacyOutput<Maps[9], Keys[5]>>>;
export type Case_9_6 = Assert<Equal<ReplacementOutput<Maps[9], Keys[6]>, LegacyOutput<Maps[9], Keys[6]>>>;
export type Case_9_7 = Assert<Equal<ReplacementOutput<Maps[9], Keys[7]>, LegacyOutput<Maps[9], Keys[7]>>>;
export type Case_9_8 = Assert<Equal<ReplacementOutput<Maps[9], Keys[8]>, LegacyOutput<Maps[9], Keys[8]>>>;
export type Case_9_9 = Assert<Equal<ReplacementOutput<Maps[9], Keys[9]>, LegacyOutput<Maps[9], Keys[9]>>>;
export type Case_9_10 = Assert<Equal<ReplacementOutput<Maps[9], Keys[10]>, LegacyOutput<Maps[9], Keys[10]>>>;
export type Case_9_11 = Assert<Equal<ReplacementOutput<Maps[9], Keys[11]>, LegacyOutput<Maps[9], Keys[11]>>>;
export type Case_10_0 = Assert<Equal<ReplacementOutput<Maps[10], Keys[0]>, LegacyOutput<Maps[10], Keys[0]>>>;
export type Case_10_1 = Assert<Equal<ReplacementOutput<Maps[10], Keys[1]>, LegacyOutput<Maps[10], Keys[1]>>>;
export type Case_10_2 = Assert<Equal<ReplacementOutput<Maps[10], Keys[2]>, LegacyOutput<Maps[10], Keys[2]>>>;
export type Case_10_3 = Assert<Equal<ReplacementOutput<Maps[10], Keys[3]>, LegacyOutput<Maps[10], Keys[3]>>>;
export type Case_10_4 = Assert<Equal<ReplacementOutput<Maps[10], Keys[4]>, LegacyOutput<Maps[10], Keys[4]>>>;
export type Case_10_5 = Assert<Equal<ReplacementOutput<Maps[10], Keys[5]>, LegacyOutput<Maps[10], Keys[5]>>>;
export type Case_10_6 = Assert<Equal<ReplacementOutput<Maps[10], Keys[6]>, LegacyOutput<Maps[10], Keys[6]>>>;
export type Case_10_7 = Assert<Equal<ReplacementOutput<Maps[10], Keys[7]>, LegacyOutput<Maps[10], Keys[7]>>>;
export type Case_10_8 = Assert<Equal<ReplacementOutput<Maps[10], Keys[8]>, LegacyOutput<Maps[10], Keys[8]>>>;
export type Case_10_9 = Assert<Equal<ReplacementOutput<Maps[10], Keys[9]>, LegacyOutput<Maps[10], Keys[9]>>>;
export type Case_10_10 = Assert<Equal<ReplacementOutput<Maps[10], Keys[10]>, LegacyOutput<Maps[10], Keys[10]>>>;
export type Case_10_11 = Assert<Equal<ReplacementOutput<Maps[10], Keys[11]>, LegacyOutput<Maps[10], Keys[11]>>>;
export type Case_11_0 = Assert<Equal<ReplacementOutput<Maps[11], Keys[0]>, LegacyOutput<Maps[11], Keys[0]>>>;
export type Case_11_1 = Assert<Equal<ReplacementOutput<Maps[11], Keys[1]>, LegacyOutput<Maps[11], Keys[1]>>>;
export type Case_11_2 = Assert<Equal<ReplacementOutput<Maps[11], Keys[2]>, LegacyOutput<Maps[11], Keys[2]>>>;
export type Case_11_3 = Assert<Equal<ReplacementOutput<Maps[11], Keys[3]>, LegacyOutput<Maps[11], Keys[3]>>>;
export type Case_11_4 = Assert<Equal<ReplacementOutput<Maps[11], Keys[4]>, LegacyOutput<Maps[11], Keys[4]>>>;
export type Case_11_5 = Assert<Equal<ReplacementOutput<Maps[11], Keys[5]>, LegacyOutput<Maps[11], Keys[5]>>>;
export type Case_11_6 = Assert<Equal<ReplacementOutput<Maps[11], Keys[6]>, LegacyOutput<Maps[11], Keys[6]>>>;
export type Case_11_7 = Assert<Equal<ReplacementOutput<Maps[11], Keys[7]>, LegacyOutput<Maps[11], Keys[7]>>>;
export type Case_11_8 = Assert<Equal<ReplacementOutput<Maps[11], Keys[8]>, LegacyOutput<Maps[11], Keys[8]>>>;
export type Case_11_9 = Assert<Equal<ReplacementOutput<Maps[11], Keys[9]>, LegacyOutput<Maps[11], Keys[9]>>>;
export type Case_11_10 = Assert<Equal<ReplacementOutput<Maps[11], Keys[10]>, LegacyOutput<Maps[11], Keys[10]>>>;
export type Case_11_11 = Assert<Equal<ReplacementOutput<Maps[11], Keys[11]>, LegacyOutput<Maps[11], Keys[11]>>>;
export type Case_12_0 = Assert<Equal<ReplacementOutput<Maps[12], Keys[0]>, LegacyOutput<Maps[12], Keys[0]>>>;
export type Case_12_1 = Assert<Equal<ReplacementOutput<Maps[12], Keys[1]>, LegacyOutput<Maps[12], Keys[1]>>>;
export type Case_12_2 = Assert<Equal<ReplacementOutput<Maps[12], Keys[2]>, LegacyOutput<Maps[12], Keys[2]>>>;
export type Case_12_3 = Assert<Equal<ReplacementOutput<Maps[12], Keys[3]>, LegacyOutput<Maps[12], Keys[3]>>>;
export type Case_12_4 = Assert<Equal<ReplacementOutput<Maps[12], Keys[4]>, LegacyOutput<Maps[12], Keys[4]>>>;
export type Case_12_5 = Assert<Equal<ReplacementOutput<Maps[12], Keys[5]>, LegacyOutput<Maps[12], Keys[5]>>>;
export type Case_12_6 = Assert<Equal<ReplacementOutput<Maps[12], Keys[6]>, LegacyOutput<Maps[12], Keys[6]>>>;
export type Case_12_7 = Assert<Equal<ReplacementOutput<Maps[12], Keys[7]>, LegacyOutput<Maps[12], Keys[7]>>>;
export type Case_12_8 = Assert<Equal<ReplacementOutput<Maps[12], Keys[8]>, LegacyOutput<Maps[12], Keys[8]>>>;
export type Case_12_9 = Assert<Equal<ReplacementOutput<Maps[12], Keys[9]>, LegacyOutput<Maps[12], Keys[9]>>>;
export type Case_12_10 = Assert<Equal<ReplacementOutput<Maps[12], Keys[10]>, LegacyOutput<Maps[12], Keys[10]>>>;
export type Case_12_11 = Assert<Equal<ReplacementOutput<Maps[12], Keys[11]>, LegacyOutput<Maps[12], Keys[11]>>>;
export type Case_13_0 = Assert<Equal<ReplacementOutput<Maps[13], Keys[0]>, LegacyOutput<Maps[13], Keys[0]>>>;
export type Case_13_1 = Assert<Equal<ReplacementOutput<Maps[13], Keys[1]>, LegacyOutput<Maps[13], Keys[1]>>>;
export type Case_13_2 = Assert<Equal<ReplacementOutput<Maps[13], Keys[2]>, LegacyOutput<Maps[13], Keys[2]>>>;
export type Case_13_3 = Assert<Equal<ReplacementOutput<Maps[13], Keys[3]>, LegacyOutput<Maps[13], Keys[3]>>>;
export type Case_13_4 = Assert<Equal<ReplacementOutput<Maps[13], Keys[4]>, LegacyOutput<Maps[13], Keys[4]>>>;
export type Case_13_5 = Assert<Equal<ReplacementOutput<Maps[13], Keys[5]>, LegacyOutput<Maps[13], Keys[5]>>>;
export type Case_13_6 = Assert<Equal<ReplacementOutput<Maps[13], Keys[6]>, LegacyOutput<Maps[13], Keys[6]>>>;
export type Case_13_7 = Assert<Equal<ReplacementOutput<Maps[13], Keys[7]>, LegacyOutput<Maps[13], Keys[7]>>>;
export type Case_13_8 = Assert<Equal<ReplacementOutput<Maps[13], Keys[8]>, LegacyOutput<Maps[13], Keys[8]>>>;
export type Case_13_9 = Assert<Equal<ReplacementOutput<Maps[13], Keys[9]>, LegacyOutput<Maps[13], Keys[9]>>>;
export type Case_13_10 = Assert<Equal<ReplacementOutput<Maps[13], Keys[10]>, LegacyOutput<Maps[13], Keys[10]>>>;
export type Case_13_11 = Assert<Equal<ReplacementOutput<Maps[13], Keys[11]>, LegacyOutput<Maps[13], Keys[11]>>>;
export type Case_14_0 = Assert<Equal<ReplacementOutput<Maps[14], Keys[0]>, LegacyOutput<Maps[14], Keys[0]>>>;
export type Case_14_1 = Assert<Equal<ReplacementOutput<Maps[14], Keys[1]>, LegacyOutput<Maps[14], Keys[1]>>>;
export type Case_14_2 = Assert<Equal<ReplacementOutput<Maps[14], Keys[2]>, LegacyOutput<Maps[14], Keys[2]>>>;
export type Case_14_3 = Assert<Equal<ReplacementOutput<Maps[14], Keys[3]>, LegacyOutput<Maps[14], Keys[3]>>>;
export type Case_14_4 = Assert<Equal<ReplacementOutput<Maps[14], Keys[4]>, LegacyOutput<Maps[14], Keys[4]>>>;
export type Case_14_5 = Assert<Equal<ReplacementOutput<Maps[14], Keys[5]>, LegacyOutput<Maps[14], Keys[5]>>>;
export type Case_14_6 = Assert<Equal<ReplacementOutput<Maps[14], Keys[6]>, LegacyOutput<Maps[14], Keys[6]>>>;
export type Case_14_7 = Assert<Equal<ReplacementOutput<Maps[14], Keys[7]>, LegacyOutput<Maps[14], Keys[7]>>>;
export type Case_14_8 = Assert<Equal<ReplacementOutput<Maps[14], Keys[8]>, LegacyOutput<Maps[14], Keys[8]>>>;
export type Case_14_9 = Assert<Equal<ReplacementOutput<Maps[14], Keys[9]>, LegacyOutput<Maps[14], Keys[9]>>>;
export type Case_14_10 = Assert<Equal<ReplacementOutput<Maps[14], Keys[10]>, LegacyOutput<Maps[14], Keys[10]>>>;
export type Case_14_11 = Assert<Equal<ReplacementOutput<Maps[14], Keys[11]>, LegacyOutput<Maps[14], Keys[11]>>>;
export type Case_15_0 = Assert<Equal<ReplacementOutput<Maps[15], Keys[0]>, LegacyOutput<Maps[15], Keys[0]>>>;
export type Case_15_1 = Assert<Equal<ReplacementOutput<Maps[15], Keys[1]>, LegacyOutput<Maps[15], Keys[1]>>>;
export type Case_15_2 = Assert<Equal<ReplacementOutput<Maps[15], Keys[2]>, LegacyOutput<Maps[15], Keys[2]>>>;
export type Case_15_3 = Assert<Equal<ReplacementOutput<Maps[15], Keys[3]>, LegacyOutput<Maps[15], Keys[3]>>>;
export type Case_15_4 = Assert<Equal<ReplacementOutput<Maps[15], Keys[4]>, LegacyOutput<Maps[15], Keys[4]>>>;
export type Case_15_5 = Assert<Equal<ReplacementOutput<Maps[15], Keys[5]>, LegacyOutput<Maps[15], Keys[5]>>>;
export type Case_15_6 = Assert<Equal<ReplacementOutput<Maps[15], Keys[6]>, LegacyOutput<Maps[15], Keys[6]>>>;
export type Case_15_7 = Assert<Equal<ReplacementOutput<Maps[15], Keys[7]>, LegacyOutput<Maps[15], Keys[7]>>>;
export type Case_15_8 = Assert<Equal<ReplacementOutput<Maps[15], Keys[8]>, LegacyOutput<Maps[15], Keys[8]>>>;
export type Case_15_9 = Assert<Equal<ReplacementOutput<Maps[15], Keys[9]>, LegacyOutput<Maps[15], Keys[9]>>>;
export type Case_15_10 = Assert<Equal<ReplacementOutput<Maps[15], Keys[10]>, LegacyOutput<Maps[15], Keys[10]>>>;
export type Case_15_11 = Assert<Equal<ReplacementOutput<Maps[15], Keys[11]>, LegacyOutput<Maps[15], Keys[11]>>>;
export type Case_16_0 = Assert<Equal<ReplacementOutput<Maps[16], Keys[0]>, LegacyOutput<Maps[16], Keys[0]>>>;
export type Case_16_1 = Assert<Equal<ReplacementOutput<Maps[16], Keys[1]>, LegacyOutput<Maps[16], Keys[1]>>>;
export type Case_16_2 = Assert<Equal<ReplacementOutput<Maps[16], Keys[2]>, LegacyOutput<Maps[16], Keys[2]>>>;
export type Case_16_3 = Assert<Equal<ReplacementOutput<Maps[16], Keys[3]>, LegacyOutput<Maps[16], Keys[3]>>>;
export type Case_16_4 = Assert<Equal<ReplacementOutput<Maps[16], Keys[4]>, LegacyOutput<Maps[16], Keys[4]>>>;
export type Case_16_5 = Assert<Equal<ReplacementOutput<Maps[16], Keys[5]>, LegacyOutput<Maps[16], Keys[5]>>>;
export type Case_16_6 = Assert<Equal<ReplacementOutput<Maps[16], Keys[6]>, LegacyOutput<Maps[16], Keys[6]>>>;
export type Case_16_7 = Assert<Equal<ReplacementOutput<Maps[16], Keys[7]>, LegacyOutput<Maps[16], Keys[7]>>>;
export type Case_16_8 = Assert<Equal<ReplacementOutput<Maps[16], Keys[8]>, LegacyOutput<Maps[16], Keys[8]>>>;
export type Case_16_9 = Assert<Equal<ReplacementOutput<Maps[16], Keys[9]>, LegacyOutput<Maps[16], Keys[9]>>>;
export type Case_16_10 = Assert<Equal<ReplacementOutput<Maps[16], Keys[10]>, LegacyOutput<Maps[16], Keys[10]>>>;
export type Case_16_11 = Assert<Equal<ReplacementOutput<Maps[16], Keys[11]>, LegacyOutput<Maps[16], Keys[11]>>>;
export type Case_17_0 = Assert<Equal<ReplacementOutput<Maps[17], Keys[0]>, LegacyOutput<Maps[17], Keys[0]>>>;
export type Case_17_1 = Assert<Equal<ReplacementOutput<Maps[17], Keys[1]>, LegacyOutput<Maps[17], Keys[1]>>>;
export type Case_17_2 = Assert<Equal<ReplacementOutput<Maps[17], Keys[2]>, LegacyOutput<Maps[17], Keys[2]>>>;
export type Case_17_3 = Assert<Equal<ReplacementOutput<Maps[17], Keys[3]>, LegacyOutput<Maps[17], Keys[3]>>>;
export type Case_17_4 = Assert<Equal<ReplacementOutput<Maps[17], Keys[4]>, LegacyOutput<Maps[17], Keys[4]>>>;
export type Case_17_5 = Assert<Equal<ReplacementOutput<Maps[17], Keys[5]>, LegacyOutput<Maps[17], Keys[5]>>>;
export type Case_17_6 = Assert<Equal<ReplacementOutput<Maps[17], Keys[6]>, LegacyOutput<Maps[17], Keys[6]>>>;
export type Case_17_7 = Assert<Equal<ReplacementOutput<Maps[17], Keys[7]>, LegacyOutput<Maps[17], Keys[7]>>>;
export type Case_17_8 = Assert<Equal<ReplacementOutput<Maps[17], Keys[8]>, LegacyOutput<Maps[17], Keys[8]>>>;
export type Case_17_9 = Assert<Equal<ReplacementOutput<Maps[17], Keys[9]>, LegacyOutput<Maps[17], Keys[9]>>>;
export type Case_17_10 = Assert<Equal<ReplacementOutput<Maps[17], Keys[10]>, LegacyOutput<Maps[17], Keys[10]>>>;
export type Case_17_11 = Assert<Equal<ReplacementOutput<Maps[17], Keys[11]>, LegacyOutput<Maps[17], Keys[11]>>>;
export type Case_18_0 = Assert<Equal<ReplacementOutput<Maps[18], Keys[0]>, LegacyOutput<Maps[18], Keys[0]>>>;
export type Case_18_1 = Assert<Equal<ReplacementOutput<Maps[18], Keys[1]>, LegacyOutput<Maps[18], Keys[1]>>>;
export type Case_18_2 = Assert<Equal<ReplacementOutput<Maps[18], Keys[2]>, LegacyOutput<Maps[18], Keys[2]>>>;
export type Case_18_3 = Assert<Equal<ReplacementOutput<Maps[18], Keys[3]>, LegacyOutput<Maps[18], Keys[3]>>>;
export type Case_18_4 = Assert<Equal<ReplacementOutput<Maps[18], Keys[4]>, LegacyOutput<Maps[18], Keys[4]>>>;
export type Case_18_5 = Assert<Equal<ReplacementOutput<Maps[18], Keys[5]>, LegacyOutput<Maps[18], Keys[5]>>>;
export type Case_18_6 = Assert<Equal<ReplacementOutput<Maps[18], Keys[6]>, LegacyOutput<Maps[18], Keys[6]>>>;
export type Case_18_7 = Assert<Equal<ReplacementOutput<Maps[18], Keys[7]>, LegacyOutput<Maps[18], Keys[7]>>>;
export type Case_18_8 = Assert<Equal<ReplacementOutput<Maps[18], Keys[8]>, LegacyOutput<Maps[18], Keys[8]>>>;
export type Case_18_9 = Assert<Equal<ReplacementOutput<Maps[18], Keys[9]>, LegacyOutput<Maps[18], Keys[9]>>>;
export type Case_18_10 = Assert<Equal<ReplacementOutput<Maps[18], Keys[10]>, LegacyOutput<Maps[18], Keys[10]>>>;
export type Case_18_11 = Assert<Equal<ReplacementOutput<Maps[18], Keys[11]>, LegacyOutput<Maps[18], Keys[11]>>>;
export type Case_19_0 = Assert<Equal<ReplacementOutput<Maps[19], Keys[0]>, LegacyOutput<Maps[19], Keys[0]>>>;
export type Case_19_1 = Assert<Equal<ReplacementOutput<Maps[19], Keys[1]>, LegacyOutput<Maps[19], Keys[1]>>>;
export type Case_19_2 = Assert<Equal<ReplacementOutput<Maps[19], Keys[2]>, LegacyOutput<Maps[19], Keys[2]>>>;
export type Case_19_3 = Assert<Equal<ReplacementOutput<Maps[19], Keys[3]>, LegacyOutput<Maps[19], Keys[3]>>>;
export type Case_19_4 = Assert<Equal<ReplacementOutput<Maps[19], Keys[4]>, LegacyOutput<Maps[19], Keys[4]>>>;
export type Case_19_5 = Assert<Equal<ReplacementOutput<Maps[19], Keys[5]>, LegacyOutput<Maps[19], Keys[5]>>>;
export type Case_19_6 = Assert<Equal<ReplacementOutput<Maps[19], Keys[6]>, LegacyOutput<Maps[19], Keys[6]>>>;
export type Case_19_7 = Assert<Equal<ReplacementOutput<Maps[19], Keys[7]>, LegacyOutput<Maps[19], Keys[7]>>>;
export type Case_19_8 = Assert<Equal<ReplacementOutput<Maps[19], Keys[8]>, LegacyOutput<Maps[19], Keys[8]>>>;
export type Case_19_9 = Assert<Equal<ReplacementOutput<Maps[19], Keys[9]>, LegacyOutput<Maps[19], Keys[9]>>>;
export type Case_19_10 = Assert<Equal<ReplacementOutput<Maps[19], Keys[10]>, LegacyOutput<Maps[19], Keys[10]>>>;
export type Case_19_11 = Assert<Equal<ReplacementOutput<Maps[19], Keys[11]>, LegacyOutput<Maps[19], Keys[11]>>>;
export type Case_20_0 = Assert<Equal<ReplacementOutput<Maps[20], Keys[0]>, LegacyOutput<Maps[20], Keys[0]>>>;
export type Case_20_1 = Assert<Equal<ReplacementOutput<Maps[20], Keys[1]>, LegacyOutput<Maps[20], Keys[1]>>>;
export type Case_20_2 = Assert<Equal<ReplacementOutput<Maps[20], Keys[2]>, LegacyOutput<Maps[20], Keys[2]>>>;
export type Case_20_3 = Assert<Equal<ReplacementOutput<Maps[20], Keys[3]>, LegacyOutput<Maps[20], Keys[3]>>>;
export type Case_20_4 = Assert<Equal<ReplacementOutput<Maps[20], Keys[4]>, LegacyOutput<Maps[20], Keys[4]>>>;
export type Case_20_5 = Assert<Equal<ReplacementOutput<Maps[20], Keys[5]>, LegacyOutput<Maps[20], Keys[5]>>>;
export type Case_20_6 = Assert<Equal<ReplacementOutput<Maps[20], Keys[6]>, LegacyOutput<Maps[20], Keys[6]>>>;
export type Case_20_7 = Assert<Equal<ReplacementOutput<Maps[20], Keys[7]>, LegacyOutput<Maps[20], Keys[7]>>>;
export type Case_20_8 = Assert<Equal<ReplacementOutput<Maps[20], Keys[8]>, LegacyOutput<Maps[20], Keys[8]>>>;
export type Case_20_9 = Assert<Equal<ReplacementOutput<Maps[20], Keys[9]>, LegacyOutput<Maps[20], Keys[9]>>>;
export type Case_20_10 = Assert<Equal<ReplacementOutput<Maps[20], Keys[10]>, LegacyOutput<Maps[20], Keys[10]>>>;
export type Case_20_11 = Assert<Equal<ReplacementOutput<Maps[20], Keys[11]>, LegacyOutput<Maps[20], Keys[11]>>>;
export type Case_21_0 = Assert<Equal<ReplacementOutput<Maps[21], Keys[0]>, LegacyOutput<Maps[21], Keys[0]>>>;
export type Case_21_1 = Assert<Equal<ReplacementOutput<Maps[21], Keys[1]>, LegacyOutput<Maps[21], Keys[1]>>>;
export type Case_21_2 = Assert<Equal<ReplacementOutput<Maps[21], Keys[2]>, LegacyOutput<Maps[21], Keys[2]>>>;
export type Case_21_3 = Assert<Equal<ReplacementOutput<Maps[21], Keys[3]>, LegacyOutput<Maps[21], Keys[3]>>>;
export type Case_21_4 = Assert<Equal<ReplacementOutput<Maps[21], Keys[4]>, LegacyOutput<Maps[21], Keys[4]>>>;
export type Case_21_5 = Assert<Equal<ReplacementOutput<Maps[21], Keys[5]>, LegacyOutput<Maps[21], Keys[5]>>>;
export type Case_21_6 = Assert<Equal<ReplacementOutput<Maps[21], Keys[6]>, LegacyOutput<Maps[21], Keys[6]>>>;
export type Case_21_7 = Assert<Equal<ReplacementOutput<Maps[21], Keys[7]>, LegacyOutput<Maps[21], Keys[7]>>>;
export type Case_21_8 = Assert<Equal<ReplacementOutput<Maps[21], Keys[8]>, LegacyOutput<Maps[21], Keys[8]>>>;
export type Case_21_9 = Assert<Equal<ReplacementOutput<Maps[21], Keys[9]>, LegacyOutput<Maps[21], Keys[9]>>>;
export type Case_21_10 = Assert<Equal<ReplacementOutput<Maps[21], Keys[10]>, LegacyOutput<Maps[21], Keys[10]>>>;
export type Case_21_11 = Assert<Equal<ReplacementOutput<Maps[21], Keys[11]>, LegacyOutput<Maps[21], Keys[11]>>>;
export type Case_22_0 = Assert<Equal<ReplacementOutput<Maps[22], Keys[0]>, LegacyOutput<Maps[22], Keys[0]>>>;
export type Case_22_1 = Assert<Equal<ReplacementOutput<Maps[22], Keys[1]>, LegacyOutput<Maps[22], Keys[1]>>>;
export type Case_22_2 = Assert<Equal<ReplacementOutput<Maps[22], Keys[2]>, LegacyOutput<Maps[22], Keys[2]>>>;
export type Case_22_3 = Assert<Equal<ReplacementOutput<Maps[22], Keys[3]>, LegacyOutput<Maps[22], Keys[3]>>>;
export type Case_22_4 = Assert<Equal<ReplacementOutput<Maps[22], Keys[4]>, LegacyOutput<Maps[22], Keys[4]>>>;
export type Case_22_5 = Assert<Equal<ReplacementOutput<Maps[22], Keys[5]>, LegacyOutput<Maps[22], Keys[5]>>>;
export type Case_22_6 = Assert<Equal<ReplacementOutput<Maps[22], Keys[6]>, LegacyOutput<Maps[22], Keys[6]>>>;
export type Case_22_7 = Assert<Equal<ReplacementOutput<Maps[22], Keys[7]>, LegacyOutput<Maps[22], Keys[7]>>>;
export type Case_22_8 = Assert<Equal<ReplacementOutput<Maps[22], Keys[8]>, LegacyOutput<Maps[22], Keys[8]>>>;
export type Case_22_9 = Assert<Equal<ReplacementOutput<Maps[22], Keys[9]>, LegacyOutput<Maps[22], Keys[9]>>>;
export type Case_22_10 = Assert<Equal<ReplacementOutput<Maps[22], Keys[10]>, LegacyOutput<Maps[22], Keys[10]>>>;
export type Case_22_11 = Assert<Equal<ReplacementOutput<Maps[22], Keys[11]>, LegacyOutput<Maps[22], Keys[11]>>>;
export type Case_23_0 = Assert<Equal<ReplacementOutput<Maps[23], Keys[0]>, LegacyOutput<Maps[23], Keys[0]>>>;
export type Case_23_1 = Assert<Equal<ReplacementOutput<Maps[23], Keys[1]>, LegacyOutput<Maps[23], Keys[1]>>>;
export type Case_23_2 = Assert<Equal<ReplacementOutput<Maps[23], Keys[2]>, LegacyOutput<Maps[23], Keys[2]>>>;
export type Case_23_3 = Assert<Equal<ReplacementOutput<Maps[23], Keys[3]>, LegacyOutput<Maps[23], Keys[3]>>>;
export type Case_23_4 = Assert<Equal<ReplacementOutput<Maps[23], Keys[4]>, LegacyOutput<Maps[23], Keys[4]>>>;
export type Case_23_5 = Assert<Equal<ReplacementOutput<Maps[23], Keys[5]>, LegacyOutput<Maps[23], Keys[5]>>>;
export type Case_23_6 = Assert<Equal<ReplacementOutput<Maps[23], Keys[6]>, LegacyOutput<Maps[23], Keys[6]>>>;
export type Case_23_7 = Assert<Equal<ReplacementOutput<Maps[23], Keys[7]>, LegacyOutput<Maps[23], Keys[7]>>>;
export type Case_23_8 = Assert<Equal<ReplacementOutput<Maps[23], Keys[8]>, LegacyOutput<Maps[23], Keys[8]>>>;
export type Case_23_9 = Assert<Equal<ReplacementOutput<Maps[23], Keys[9]>, LegacyOutput<Maps[23], Keys[9]>>>;
export type Case_23_10 = Assert<Equal<ReplacementOutput<Maps[23], Keys[10]>, LegacyOutput<Maps[23], Keys[10]>>>;
export type Case_23_11 = Assert<Equal<ReplacementOutput<Maps[23], Keys[11]>, LegacyOutput<Maps[23], Keys[11]>>>;
export type Case_24_0 = Assert<Equal<ReplacementOutput<Maps[24], Keys[0]>, LegacyOutput<Maps[24], Keys[0]>>>;
export type Case_24_1 = Assert<Equal<ReplacementOutput<Maps[24], Keys[1]>, LegacyOutput<Maps[24], Keys[1]>>>;
export type Case_24_2 = Assert<Equal<ReplacementOutput<Maps[24], Keys[2]>, LegacyOutput<Maps[24], Keys[2]>>>;
export type Case_24_3 = Assert<Equal<ReplacementOutput<Maps[24], Keys[3]>, LegacyOutput<Maps[24], Keys[3]>>>;
export type Case_24_4 = Assert<Equal<ReplacementOutput<Maps[24], Keys[4]>, LegacyOutput<Maps[24], Keys[4]>>>;
export type Case_24_5 = Assert<Equal<ReplacementOutput<Maps[24], Keys[5]>, LegacyOutput<Maps[24], Keys[5]>>>;
export type Case_24_6 = Assert<Equal<ReplacementOutput<Maps[24], Keys[6]>, LegacyOutput<Maps[24], Keys[6]>>>;
export type Case_24_7 = Assert<Equal<ReplacementOutput<Maps[24], Keys[7]>, LegacyOutput<Maps[24], Keys[7]>>>;
export type Case_24_8 = Assert<Equal<ReplacementOutput<Maps[24], Keys[8]>, LegacyOutput<Maps[24], Keys[8]>>>;
export type Case_24_9 = Assert<Equal<ReplacementOutput<Maps[24], Keys[9]>, LegacyOutput<Maps[24], Keys[9]>>>;
export type Case_24_10 = Assert<Equal<ReplacementOutput<Maps[24], Keys[10]>, LegacyOutput<Maps[24], Keys[10]>>>;
export type Case_24_11 = Assert<Equal<ReplacementOutput<Maps[24], Keys[11]>, LegacyOutput<Maps[24], Keys[11]>>>;
export type Case_25_0 = Assert<Equal<ReplacementOutput<Maps[25], Keys[0]>, LegacyOutput<Maps[25], Keys[0]>>>;
export type Case_25_1 = Assert<Equal<ReplacementOutput<Maps[25], Keys[1]>, LegacyOutput<Maps[25], Keys[1]>>>;
export type Case_25_2 = Assert<Equal<ReplacementOutput<Maps[25], Keys[2]>, LegacyOutput<Maps[25], Keys[2]>>>;
export type Case_25_3 = Assert<Equal<ReplacementOutput<Maps[25], Keys[3]>, LegacyOutput<Maps[25], Keys[3]>>>;
export type Case_25_4 = Assert<Equal<ReplacementOutput<Maps[25], Keys[4]>, LegacyOutput<Maps[25], Keys[4]>>>;
export type Case_25_5 = Assert<Equal<ReplacementOutput<Maps[25], Keys[5]>, LegacyOutput<Maps[25], Keys[5]>>>;
export type Case_25_6 = Assert<Equal<ReplacementOutput<Maps[25], Keys[6]>, LegacyOutput<Maps[25], Keys[6]>>>;
export type Case_25_7 = Assert<Equal<ReplacementOutput<Maps[25], Keys[7]>, LegacyOutput<Maps[25], Keys[7]>>>;
export type Case_25_8 = Assert<Equal<ReplacementOutput<Maps[25], Keys[8]>, LegacyOutput<Maps[25], Keys[8]>>>;
export type Case_25_9 = Assert<Equal<ReplacementOutput<Maps[25], Keys[9]>, LegacyOutput<Maps[25], Keys[9]>>>;
export type Case_25_10 = Assert<Equal<ReplacementOutput<Maps[25], Keys[10]>, LegacyOutput<Maps[25], Keys[10]>>>;
export type Case_25_11 = Assert<Equal<ReplacementOutput<Maps[25], Keys[11]>, LegacyOutput<Maps[25], Keys[11]>>>;
export type Case_26_0 = Assert<Equal<ReplacementOutput<Maps[26], Keys[0]>, LegacyOutput<Maps[26], Keys[0]>>>;
export type Case_26_1 = Assert<Equal<ReplacementOutput<Maps[26], Keys[1]>, LegacyOutput<Maps[26], Keys[1]>>>;
export type Case_26_2 = Assert<Equal<ReplacementOutput<Maps[26], Keys[2]>, LegacyOutput<Maps[26], Keys[2]>>>;
export type Case_26_3 = Assert<Equal<ReplacementOutput<Maps[26], Keys[3]>, LegacyOutput<Maps[26], Keys[3]>>>;
export type Case_26_4 = Assert<Equal<ReplacementOutput<Maps[26], Keys[4]>, LegacyOutput<Maps[26], Keys[4]>>>;
export type Case_26_5 = Assert<Equal<ReplacementOutput<Maps[26], Keys[5]>, LegacyOutput<Maps[26], Keys[5]>>>;
export type Case_26_6 = Assert<Equal<ReplacementOutput<Maps[26], Keys[6]>, LegacyOutput<Maps[26], Keys[6]>>>;
export type Case_26_7 = Assert<Equal<ReplacementOutput<Maps[26], Keys[7]>, LegacyOutput<Maps[26], Keys[7]>>>;
export type Case_26_8 = Assert<Equal<ReplacementOutput<Maps[26], Keys[8]>, LegacyOutput<Maps[26], Keys[8]>>>;
export type Case_26_9 = Assert<Equal<ReplacementOutput<Maps[26], Keys[9]>, LegacyOutput<Maps[26], Keys[9]>>>;
export type Case_26_10 = Assert<Equal<ReplacementOutput<Maps[26], Keys[10]>, LegacyOutput<Maps[26], Keys[10]>>>;
export type Case_26_11 = Assert<Equal<ReplacementOutput<Maps[26], Keys[11]>, LegacyOutput<Maps[26], Keys[11]>>>;
export type Case_27_0 = Assert<Equal<ReplacementOutput<Maps[27], Keys[0]>, LegacyOutput<Maps[27], Keys[0]>>>;
export type Case_27_1 = Assert<Equal<ReplacementOutput<Maps[27], Keys[1]>, LegacyOutput<Maps[27], Keys[1]>>>;
export type Case_27_2 = Assert<Equal<ReplacementOutput<Maps[27], Keys[2]>, LegacyOutput<Maps[27], Keys[2]>>>;
export type Case_27_3 = Assert<Equal<ReplacementOutput<Maps[27], Keys[3]>, LegacyOutput<Maps[27], Keys[3]>>>;
export type Case_27_4 = Assert<Equal<ReplacementOutput<Maps[27], Keys[4]>, LegacyOutput<Maps[27], Keys[4]>>>;
export type Case_27_5 = Assert<Equal<ReplacementOutput<Maps[27], Keys[5]>, LegacyOutput<Maps[27], Keys[5]>>>;
export type Case_27_6 = Assert<Equal<ReplacementOutput<Maps[27], Keys[6]>, LegacyOutput<Maps[27], Keys[6]>>>;
export type Case_27_7 = Assert<Equal<ReplacementOutput<Maps[27], Keys[7]>, LegacyOutput<Maps[27], Keys[7]>>>;
export type Case_27_8 = Assert<Equal<ReplacementOutput<Maps[27], Keys[8]>, LegacyOutput<Maps[27], Keys[8]>>>;
export type Case_27_9 = Assert<Equal<ReplacementOutput<Maps[27], Keys[9]>, LegacyOutput<Maps[27], Keys[9]>>>;
export type Case_27_10 = Assert<Equal<ReplacementOutput<Maps[27], Keys[10]>, LegacyOutput<Maps[27], Keys[10]>>>;
export type Case_27_11 = Assert<Equal<ReplacementOutput<Maps[27], Keys[11]>, LegacyOutput<Maps[27], Keys[11]>>>;
export type Case_28_0 = Assert<Equal<ReplacementOutput<Maps[28], Keys[0]>, LegacyOutput<Maps[28], Keys[0]>>>;
export type Case_28_1 = Assert<Equal<ReplacementOutput<Maps[28], Keys[1]>, LegacyOutput<Maps[28], Keys[1]>>>;
export type Case_28_2 = Assert<Equal<ReplacementOutput<Maps[28], Keys[2]>, LegacyOutput<Maps[28], Keys[2]>>>;
export type Case_28_3 = Assert<Equal<ReplacementOutput<Maps[28], Keys[3]>, LegacyOutput<Maps[28], Keys[3]>>>;
export type Case_28_4 = Assert<Equal<ReplacementOutput<Maps[28], Keys[4]>, LegacyOutput<Maps[28], Keys[4]>>>;
export type Case_28_5 = Assert<Equal<ReplacementOutput<Maps[28], Keys[5]>, LegacyOutput<Maps[28], Keys[5]>>>;
export type Case_28_6 = Assert<Equal<ReplacementOutput<Maps[28], Keys[6]>, LegacyOutput<Maps[28], Keys[6]>>>;
export type Case_28_7 = Assert<Equal<ReplacementOutput<Maps[28], Keys[7]>, LegacyOutput<Maps[28], Keys[7]>>>;
export type Case_28_8 = Assert<Equal<ReplacementOutput<Maps[28], Keys[8]>, LegacyOutput<Maps[28], Keys[8]>>>;
export type Case_28_9 = Assert<Equal<ReplacementOutput<Maps[28], Keys[9]>, LegacyOutput<Maps[28], Keys[9]>>>;
export type Case_28_10 = Assert<Equal<ReplacementOutput<Maps[28], Keys[10]>, LegacyOutput<Maps[28], Keys[10]>>>;
export type Case_28_11 = Assert<Equal<ReplacementOutput<Maps[28], Keys[11]>, LegacyOutput<Maps[28], Keys[11]>>>;
export type Case_29_0 = Assert<Equal<ReplacementOutput<Maps[29], Keys[0]>, LegacyOutput<Maps[29], Keys[0]>>>;
export type Case_29_1 = Assert<Equal<ReplacementOutput<Maps[29], Keys[1]>, LegacyOutput<Maps[29], Keys[1]>>>;
export type Case_29_2 = Assert<Equal<ReplacementOutput<Maps[29], Keys[2]>, LegacyOutput<Maps[29], Keys[2]>>>;
export type Case_29_3 = Assert<Equal<ReplacementOutput<Maps[29], Keys[3]>, LegacyOutput<Maps[29], Keys[3]>>>;
export type Case_29_4 = Assert<Equal<ReplacementOutput<Maps[29], Keys[4]>, LegacyOutput<Maps[29], Keys[4]>>>;
export type Case_29_5 = Assert<Equal<ReplacementOutput<Maps[29], Keys[5]>, LegacyOutput<Maps[29], Keys[5]>>>;
export type Case_29_6 = Assert<Equal<ReplacementOutput<Maps[29], Keys[6]>, LegacyOutput<Maps[29], Keys[6]>>>;
export type Case_29_7 = Assert<Equal<ReplacementOutput<Maps[29], Keys[7]>, LegacyOutput<Maps[29], Keys[7]>>>;
export type Case_29_8 = Assert<Equal<ReplacementOutput<Maps[29], Keys[8]>, LegacyOutput<Maps[29], Keys[8]>>>;
export type Case_29_9 = Assert<Equal<ReplacementOutput<Maps[29], Keys[9]>, LegacyOutput<Maps[29], Keys[9]>>>;
export type Case_29_10 = Assert<Equal<ReplacementOutput<Maps[29], Keys[10]>, LegacyOutput<Maps[29], Keys[10]>>>;
export type Case_29_11 = Assert<Equal<ReplacementOutput<Maps[29], Keys[11]>, LegacyOutput<Maps[29], Keys[11]>>>;
export type Retained_0_0 = Assert<Equal<ReplacementOutput<Maps[0], "value", Constraints[0]>, LegacyOutput<Maps[0], "value", Constraints[0]>>>;
export type Retained_0_1 = Assert<Equal<ReplacementOutput<Maps[0], "value", Constraints[1]>, LegacyOutput<Maps[0], "value", Constraints[1]>>>;
export type Retained_0_2 = Assert<Equal<ReplacementOutput<Maps[0], "value", Constraints[2]>, LegacyOutput<Maps[0], "value", Constraints[2]>>>;
export type Retained_0_3 = Assert<Equal<ReplacementOutput<Maps[0], "value", Constraints[3]>, LegacyOutput<Maps[0], "value", Constraints[3]>>>;
export type Retained_0_4 = Assert<Equal<ReplacementOutput<Maps[0], "value", Constraints[4]>, LegacyOutput<Maps[0], "value", Constraints[4]>>>;
export type Retained_0_5 = Assert<Equal<ReplacementOutput<Maps[0], "value", Constraints[5]>, LegacyOutput<Maps[0], "value", Constraints[5]>>>;
export type Retained_0_6 = Assert<Equal<ReplacementOutput<Maps[0], "value", Constraints[6]>, LegacyOutput<Maps[0], "value", Constraints[6]>>>;
export type Retained_0_7 = Assert<Equal<ReplacementOutput<Maps[0], "value", Constraints[7]>, LegacyOutput<Maps[0], "value", Constraints[7]>>>;
export type Retained_1_0 = Assert<Equal<ReplacementOutput<Maps[1], "value", Constraints[0]>, LegacyOutput<Maps[1], "value", Constraints[0]>>>;
export type Retained_1_1 = Assert<Equal<ReplacementOutput<Maps[1], "value", Constraints[1]>, LegacyOutput<Maps[1], "value", Constraints[1]>>>;
export type Retained_1_2 = Assert<Equal<ReplacementOutput<Maps[1], "value", Constraints[2]>, LegacyOutput<Maps[1], "value", Constraints[2]>>>;
export type Retained_1_3 = Assert<Equal<ReplacementOutput<Maps[1], "value", Constraints[3]>, LegacyOutput<Maps[1], "value", Constraints[3]>>>;
export type Retained_1_4 = Assert<Equal<ReplacementOutput<Maps[1], "value", Constraints[4]>, LegacyOutput<Maps[1], "value", Constraints[4]>>>;
export type Retained_1_5 = Assert<Equal<ReplacementOutput<Maps[1], "value", Constraints[5]>, LegacyOutput<Maps[1], "value", Constraints[5]>>>;
export type Retained_1_6 = Assert<Equal<ReplacementOutput<Maps[1], "value", Constraints[6]>, LegacyOutput<Maps[1], "value", Constraints[6]>>>;
export type Retained_1_7 = Assert<Equal<ReplacementOutput<Maps[1], "value", Constraints[7]>, LegacyOutput<Maps[1], "value", Constraints[7]>>>;
export type Retained_2_0 = Assert<Equal<ReplacementOutput<Maps[2], "value", Constraints[0]>, LegacyOutput<Maps[2], "value", Constraints[0]>>>;
export type Retained_2_1 = Assert<Equal<ReplacementOutput<Maps[2], "value", Constraints[1]>, LegacyOutput<Maps[2], "value", Constraints[1]>>>;
export type Retained_2_2 = Assert<Equal<ReplacementOutput<Maps[2], "value", Constraints[2]>, LegacyOutput<Maps[2], "value", Constraints[2]>>>;
export type Retained_2_3 = Assert<Equal<ReplacementOutput<Maps[2], "value", Constraints[3]>, LegacyOutput<Maps[2], "value", Constraints[3]>>>;
export type Retained_2_4 = Assert<Equal<ReplacementOutput<Maps[2], "value", Constraints[4]>, LegacyOutput<Maps[2], "value", Constraints[4]>>>;
export type Retained_2_5 = Assert<Equal<ReplacementOutput<Maps[2], "value", Constraints[5]>, LegacyOutput<Maps[2], "value", Constraints[5]>>>;
export type Retained_2_6 = Assert<Equal<ReplacementOutput<Maps[2], "value", Constraints[6]>, LegacyOutput<Maps[2], "value", Constraints[6]>>>;
export type Retained_2_7 = Assert<Equal<ReplacementOutput<Maps[2], "value", Constraints[7]>, LegacyOutput<Maps[2], "value", Constraints[7]>>>;
export type Retained_3_0 = Assert<Equal<ReplacementOutput<Maps[3], "value", Constraints[0]>, LegacyOutput<Maps[3], "value", Constraints[0]>>>;
export type Retained_3_1 = Assert<Equal<ReplacementOutput<Maps[3], "value", Constraints[1]>, LegacyOutput<Maps[3], "value", Constraints[1]>>>;
export type Retained_3_2 = Assert<Equal<ReplacementOutput<Maps[3], "value", Constraints[2]>, LegacyOutput<Maps[3], "value", Constraints[2]>>>;
export type Retained_3_3 = Assert<Equal<ReplacementOutput<Maps[3], "value", Constraints[3]>, LegacyOutput<Maps[3], "value", Constraints[3]>>>;
export type Retained_3_4 = Assert<Equal<ReplacementOutput<Maps[3], "value", Constraints[4]>, LegacyOutput<Maps[3], "value", Constraints[4]>>>;
export type Retained_3_5 = Assert<Equal<ReplacementOutput<Maps[3], "value", Constraints[5]>, LegacyOutput<Maps[3], "value", Constraints[5]>>>;
export type Retained_3_6 = Assert<Equal<ReplacementOutput<Maps[3], "value", Constraints[6]>, LegacyOutput<Maps[3], "value", Constraints[6]>>>;
export type Retained_3_7 = Assert<Equal<ReplacementOutput<Maps[3], "value", Constraints[7]>, LegacyOutput<Maps[3], "value", Constraints[7]>>>;
export type Retained_4_0 = Assert<Equal<ReplacementOutput<Maps[4], "value", Constraints[0]>, LegacyOutput<Maps[4], "value", Constraints[0]>>>;
export type Retained_4_1 = Assert<Equal<ReplacementOutput<Maps[4], "value", Constraints[1]>, LegacyOutput<Maps[4], "value", Constraints[1]>>>;
export type Retained_4_2 = Assert<Equal<ReplacementOutput<Maps[4], "value", Constraints[2]>, LegacyOutput<Maps[4], "value", Constraints[2]>>>;
export type Retained_4_3 = Assert<Equal<ReplacementOutput<Maps[4], "value", Constraints[3]>, LegacyOutput<Maps[4], "value", Constraints[3]>>>;
export type Retained_4_4 = Assert<Equal<ReplacementOutput<Maps[4], "value", Constraints[4]>, LegacyOutput<Maps[4], "value", Constraints[4]>>>;
export type Retained_4_5 = Assert<Equal<ReplacementOutput<Maps[4], "value", Constraints[5]>, LegacyOutput<Maps[4], "value", Constraints[5]>>>;
export type Retained_4_6 = Assert<Equal<ReplacementOutput<Maps[4], "value", Constraints[6]>, LegacyOutput<Maps[4], "value", Constraints[6]>>>;
export type Retained_4_7 = Assert<Equal<ReplacementOutput<Maps[4], "value", Constraints[7]>, LegacyOutput<Maps[4], "value", Constraints[7]>>>;
export type Retained_5_0 = Assert<Equal<ReplacementOutput<Maps[5], "value", Constraints[0]>, LegacyOutput<Maps[5], "value", Constraints[0]>>>;
export type Retained_5_1 = Assert<Equal<ReplacementOutput<Maps[5], "value", Constraints[1]>, LegacyOutput<Maps[5], "value", Constraints[1]>>>;
export type Retained_5_2 = Assert<Equal<ReplacementOutput<Maps[5], "value", Constraints[2]>, LegacyOutput<Maps[5], "value", Constraints[2]>>>;
export type Retained_5_3 = Assert<Equal<ReplacementOutput<Maps[5], "value", Constraints[3]>, LegacyOutput<Maps[5], "value", Constraints[3]>>>;
export type Retained_5_4 = Assert<Equal<ReplacementOutput<Maps[5], "value", Constraints[4]>, LegacyOutput<Maps[5], "value", Constraints[4]>>>;
export type Retained_5_5 = Assert<Equal<ReplacementOutput<Maps[5], "value", Constraints[5]>, LegacyOutput<Maps[5], "value", Constraints[5]>>>;
export type Retained_5_6 = Assert<Equal<ReplacementOutput<Maps[5], "value", Constraints[6]>, LegacyOutput<Maps[5], "value", Constraints[6]>>>;
export type Retained_5_7 = Assert<Equal<ReplacementOutput<Maps[5], "value", Constraints[7]>, LegacyOutput<Maps[5], "value", Constraints[7]>>>;
export type Retained_6_0 = Assert<Equal<ReplacementOutput<Maps[6], "value", Constraints[0]>, LegacyOutput<Maps[6], "value", Constraints[0]>>>;
export type Retained_6_1 = Assert<Equal<ReplacementOutput<Maps[6], "value", Constraints[1]>, LegacyOutput<Maps[6], "value", Constraints[1]>>>;
export type Retained_6_2 = Assert<Equal<ReplacementOutput<Maps[6], "value", Constraints[2]>, LegacyOutput<Maps[6], "value", Constraints[2]>>>;
export type Retained_6_3 = Assert<Equal<ReplacementOutput<Maps[6], "value", Constraints[3]>, LegacyOutput<Maps[6], "value", Constraints[3]>>>;
export type Retained_6_4 = Assert<Equal<ReplacementOutput<Maps[6], "value", Constraints[4]>, LegacyOutput<Maps[6], "value", Constraints[4]>>>;
export type Retained_6_5 = Assert<Equal<ReplacementOutput<Maps[6], "value", Constraints[5]>, LegacyOutput<Maps[6], "value", Constraints[5]>>>;
export type Retained_6_6 = Assert<Equal<ReplacementOutput<Maps[6], "value", Constraints[6]>, LegacyOutput<Maps[6], "value", Constraints[6]>>>;
export type Retained_6_7 = Assert<Equal<ReplacementOutput<Maps[6], "value", Constraints[7]>, LegacyOutput<Maps[6], "value", Constraints[7]>>>;
export type Retained_7_0 = Assert<Equal<ReplacementOutput<Maps[7], "value", Constraints[0]>, LegacyOutput<Maps[7], "value", Constraints[0]>>>;
export type Retained_7_1 = Assert<Equal<ReplacementOutput<Maps[7], "value", Constraints[1]>, LegacyOutput<Maps[7], "value", Constraints[1]>>>;
export type Retained_7_2 = Assert<Equal<ReplacementOutput<Maps[7], "value", Constraints[2]>, LegacyOutput<Maps[7], "value", Constraints[2]>>>;
export type Retained_7_3 = Assert<Equal<ReplacementOutput<Maps[7], "value", Constraints[3]>, LegacyOutput<Maps[7], "value", Constraints[3]>>>;
export type Retained_7_4 = Assert<Equal<ReplacementOutput<Maps[7], "value", Constraints[4]>, LegacyOutput<Maps[7], "value", Constraints[4]>>>;
export type Retained_7_5 = Assert<Equal<ReplacementOutput<Maps[7], "value", Constraints[5]>, LegacyOutput<Maps[7], "value", Constraints[5]>>>;
export type Retained_7_6 = Assert<Equal<ReplacementOutput<Maps[7], "value", Constraints[6]>, LegacyOutput<Maps[7], "value", Constraints[6]>>>;
export type Retained_7_7 = Assert<Equal<ReplacementOutput<Maps[7], "value", Constraints[7]>, LegacyOutput<Maps[7], "value", Constraints[7]>>>;
export type Retained_8_0 = Assert<Equal<ReplacementOutput<Maps[8], "value", Constraints[0]>, LegacyOutput<Maps[8], "value", Constraints[0]>>>;
export type Retained_8_1 = Assert<Equal<ReplacementOutput<Maps[8], "value", Constraints[1]>, LegacyOutput<Maps[8], "value", Constraints[1]>>>;
export type Retained_8_2 = Assert<Equal<ReplacementOutput<Maps[8], "value", Constraints[2]>, LegacyOutput<Maps[8], "value", Constraints[2]>>>;
export type Retained_8_3 = Assert<Equal<ReplacementOutput<Maps[8], "value", Constraints[3]>, LegacyOutput<Maps[8], "value", Constraints[3]>>>;
export type Retained_8_4 = Assert<Equal<ReplacementOutput<Maps[8], "value", Constraints[4]>, LegacyOutput<Maps[8], "value", Constraints[4]>>>;
export type Retained_8_5 = Assert<Equal<ReplacementOutput<Maps[8], "value", Constraints[5]>, LegacyOutput<Maps[8], "value", Constraints[5]>>>;
export type Retained_8_6 = Assert<Equal<ReplacementOutput<Maps[8], "value", Constraints[6]>, LegacyOutput<Maps[8], "value", Constraints[6]>>>;
export type Retained_8_7 = Assert<Equal<ReplacementOutput<Maps[8], "value", Constraints[7]>, LegacyOutput<Maps[8], "value", Constraints[7]>>>;
export type Retained_9_0 = Assert<Equal<ReplacementOutput<Maps[9], "value", Constraints[0]>, LegacyOutput<Maps[9], "value", Constraints[0]>>>;
export type Retained_9_1 = Assert<Equal<ReplacementOutput<Maps[9], "value", Constraints[1]>, LegacyOutput<Maps[9], "value", Constraints[1]>>>;
export type Retained_9_2 = Assert<Equal<ReplacementOutput<Maps[9], "value", Constraints[2]>, LegacyOutput<Maps[9], "value", Constraints[2]>>>;
export type Retained_9_3 = Assert<Equal<ReplacementOutput<Maps[9], "value", Constraints[3]>, LegacyOutput<Maps[9], "value", Constraints[3]>>>;
export type Retained_9_4 = Assert<Equal<ReplacementOutput<Maps[9], "value", Constraints[4]>, LegacyOutput<Maps[9], "value", Constraints[4]>>>;
export type Retained_9_5 = Assert<Equal<ReplacementOutput<Maps[9], "value", Constraints[5]>, LegacyOutput<Maps[9], "value", Constraints[5]>>>;
export type Retained_9_6 = Assert<Equal<ReplacementOutput<Maps[9], "value", Constraints[6]>, LegacyOutput<Maps[9], "value", Constraints[6]>>>;
export type Retained_9_7 = Assert<Equal<ReplacementOutput<Maps[9], "value", Constraints[7]>, LegacyOutput<Maps[9], "value", Constraints[7]>>>;
export type Retained_10_0 = Assert<Equal<ReplacementOutput<Maps[10], "value", Constraints[0]>, LegacyOutput<Maps[10], "value", Constraints[0]>>>;
export type Retained_10_1 = Assert<Equal<ReplacementOutput<Maps[10], "value", Constraints[1]>, LegacyOutput<Maps[10], "value", Constraints[1]>>>;
export type Retained_10_2 = Assert<Equal<ReplacementOutput<Maps[10], "value", Constraints[2]>, LegacyOutput<Maps[10], "value", Constraints[2]>>>;
export type Retained_10_3 = Assert<Equal<ReplacementOutput<Maps[10], "value", Constraints[3]>, LegacyOutput<Maps[10], "value", Constraints[3]>>>;
export type Retained_10_4 = Assert<Equal<ReplacementOutput<Maps[10], "value", Constraints[4]>, LegacyOutput<Maps[10], "value", Constraints[4]>>>;
export type Retained_10_5 = Assert<Equal<ReplacementOutput<Maps[10], "value", Constraints[5]>, LegacyOutput<Maps[10], "value", Constraints[5]>>>;
export type Retained_10_6 = Assert<Equal<ReplacementOutput<Maps[10], "value", Constraints[6]>, LegacyOutput<Maps[10], "value", Constraints[6]>>>;
export type Retained_10_7 = Assert<Equal<ReplacementOutput<Maps[10], "value", Constraints[7]>, LegacyOutput<Maps[10], "value", Constraints[7]>>>;
export type Retained_11_0 = Assert<Equal<ReplacementOutput<Maps[11], "value", Constraints[0]>, LegacyOutput<Maps[11], "value", Constraints[0]>>>;
export type Retained_11_1 = Assert<Equal<ReplacementOutput<Maps[11], "value", Constraints[1]>, LegacyOutput<Maps[11], "value", Constraints[1]>>>;
export type Retained_11_2 = Assert<Equal<ReplacementOutput<Maps[11], "value", Constraints[2]>, LegacyOutput<Maps[11], "value", Constraints[2]>>>;
export type Retained_11_3 = Assert<Equal<ReplacementOutput<Maps[11], "value", Constraints[3]>, LegacyOutput<Maps[11], "value", Constraints[3]>>>;
export type Retained_11_4 = Assert<Equal<ReplacementOutput<Maps[11], "value", Constraints[4]>, LegacyOutput<Maps[11], "value", Constraints[4]>>>;
export type Retained_11_5 = Assert<Equal<ReplacementOutput<Maps[11], "value", Constraints[5]>, LegacyOutput<Maps[11], "value", Constraints[5]>>>;
export type Retained_11_6 = Assert<Equal<ReplacementOutput<Maps[11], "value", Constraints[6]>, LegacyOutput<Maps[11], "value", Constraints[6]>>>;
export type Retained_11_7 = Assert<Equal<ReplacementOutput<Maps[11], "value", Constraints[7]>, LegacyOutput<Maps[11], "value", Constraints[7]>>>;
export type Retained_12_0 = Assert<Equal<ReplacementOutput<Maps[12], "value", Constraints[0]>, LegacyOutput<Maps[12], "value", Constraints[0]>>>;
export type Retained_12_1 = Assert<Equal<ReplacementOutput<Maps[12], "value", Constraints[1]>, LegacyOutput<Maps[12], "value", Constraints[1]>>>;
export type Retained_12_2 = Assert<Equal<ReplacementOutput<Maps[12], "value", Constraints[2]>, LegacyOutput<Maps[12], "value", Constraints[2]>>>;
export type Retained_12_3 = Assert<Equal<ReplacementOutput<Maps[12], "value", Constraints[3]>, LegacyOutput<Maps[12], "value", Constraints[3]>>>;
export type Retained_12_4 = Assert<Equal<ReplacementOutput<Maps[12], "value", Constraints[4]>, LegacyOutput<Maps[12], "value", Constraints[4]>>>;
export type Retained_12_5 = Assert<Equal<ReplacementOutput<Maps[12], "value", Constraints[5]>, LegacyOutput<Maps[12], "value", Constraints[5]>>>;
export type Retained_12_6 = Assert<Equal<ReplacementOutput<Maps[12], "value", Constraints[6]>, LegacyOutput<Maps[12], "value", Constraints[6]>>>;
export type Retained_12_7 = Assert<Equal<ReplacementOutput<Maps[12], "value", Constraints[7]>, LegacyOutput<Maps[12], "value", Constraints[7]>>>;
export type Retained_13_0 = Assert<Equal<ReplacementOutput<Maps[13], "value", Constraints[0]>, LegacyOutput<Maps[13], "value", Constraints[0]>>>;
export type Retained_13_1 = Assert<Equal<ReplacementOutput<Maps[13], "value", Constraints[1]>, LegacyOutput<Maps[13], "value", Constraints[1]>>>;
export type Retained_13_2 = Assert<Equal<ReplacementOutput<Maps[13], "value", Constraints[2]>, LegacyOutput<Maps[13], "value", Constraints[2]>>>;
export type Retained_13_3 = Assert<Equal<ReplacementOutput<Maps[13], "value", Constraints[3]>, LegacyOutput<Maps[13], "value", Constraints[3]>>>;
export type Retained_13_4 = Assert<Equal<ReplacementOutput<Maps[13], "value", Constraints[4]>, LegacyOutput<Maps[13], "value", Constraints[4]>>>;
export type Retained_13_5 = Assert<Equal<ReplacementOutput<Maps[13], "value", Constraints[5]>, LegacyOutput<Maps[13], "value", Constraints[5]>>>;
export type Retained_13_6 = Assert<Equal<ReplacementOutput<Maps[13], "value", Constraints[6]>, LegacyOutput<Maps[13], "value", Constraints[6]>>>;
export type Retained_13_7 = Assert<Equal<ReplacementOutput<Maps[13], "value", Constraints[7]>, LegacyOutput<Maps[13], "value", Constraints[7]>>>;
export type Retained_14_0 = Assert<Equal<ReplacementOutput<Maps[14], "value", Constraints[0]>, LegacyOutput<Maps[14], "value", Constraints[0]>>>;
export type Retained_14_1 = Assert<Equal<ReplacementOutput<Maps[14], "value", Constraints[1]>, LegacyOutput<Maps[14], "value", Constraints[1]>>>;
export type Retained_14_2 = Assert<Equal<ReplacementOutput<Maps[14], "value", Constraints[2]>, LegacyOutput<Maps[14], "value", Constraints[2]>>>;
export type Retained_14_3 = Assert<Equal<ReplacementOutput<Maps[14], "value", Constraints[3]>, LegacyOutput<Maps[14], "value", Constraints[3]>>>;
export type Retained_14_4 = Assert<Equal<ReplacementOutput<Maps[14], "value", Constraints[4]>, LegacyOutput<Maps[14], "value", Constraints[4]>>>;
export type Retained_14_5 = Assert<Equal<ReplacementOutput<Maps[14], "value", Constraints[5]>, LegacyOutput<Maps[14], "value", Constraints[5]>>>;
export type Retained_14_6 = Assert<Equal<ReplacementOutput<Maps[14], "value", Constraints[6]>, LegacyOutput<Maps[14], "value", Constraints[6]>>>;
export type Retained_14_7 = Assert<Equal<ReplacementOutput<Maps[14], "value", Constraints[7]>, LegacyOutput<Maps[14], "value", Constraints[7]>>>;
export type Retained_15_0 = Assert<Equal<ReplacementOutput<Maps[15], "value", Constraints[0]>, LegacyOutput<Maps[15], "value", Constraints[0]>>>;
export type Retained_15_1 = Assert<Equal<ReplacementOutput<Maps[15], "value", Constraints[1]>, LegacyOutput<Maps[15], "value", Constraints[1]>>>;
export type Retained_15_2 = Assert<Equal<ReplacementOutput<Maps[15], "value", Constraints[2]>, LegacyOutput<Maps[15], "value", Constraints[2]>>>;
export type Retained_15_3 = Assert<Equal<ReplacementOutput<Maps[15], "value", Constraints[3]>, LegacyOutput<Maps[15], "value", Constraints[3]>>>;
export type Retained_15_4 = Assert<Equal<ReplacementOutput<Maps[15], "value", Constraints[4]>, LegacyOutput<Maps[15], "value", Constraints[4]>>>;
export type Retained_15_5 = Assert<Equal<ReplacementOutput<Maps[15], "value", Constraints[5]>, LegacyOutput<Maps[15], "value", Constraints[5]>>>;
export type Retained_15_6 = Assert<Equal<ReplacementOutput<Maps[15], "value", Constraints[6]>, LegacyOutput<Maps[15], "value", Constraints[6]>>>;
export type Retained_15_7 = Assert<Equal<ReplacementOutput<Maps[15], "value", Constraints[7]>, LegacyOutput<Maps[15], "value", Constraints[7]>>>;
export type Retained_16_0 = Assert<Equal<ReplacementOutput<Maps[16], "value", Constraints[0]>, LegacyOutput<Maps[16], "value", Constraints[0]>>>;
export type Retained_16_1 = Assert<Equal<ReplacementOutput<Maps[16], "value", Constraints[1]>, LegacyOutput<Maps[16], "value", Constraints[1]>>>;
export type Retained_16_2 = Assert<Equal<ReplacementOutput<Maps[16], "value", Constraints[2]>, LegacyOutput<Maps[16], "value", Constraints[2]>>>;
export type Retained_16_3 = Assert<Equal<ReplacementOutput<Maps[16], "value", Constraints[3]>, LegacyOutput<Maps[16], "value", Constraints[3]>>>;
export type Retained_16_4 = Assert<Equal<ReplacementOutput<Maps[16], "value", Constraints[4]>, LegacyOutput<Maps[16], "value", Constraints[4]>>>;
export type Retained_16_5 = Assert<Equal<ReplacementOutput<Maps[16], "value", Constraints[5]>, LegacyOutput<Maps[16], "value", Constraints[5]>>>;
export type Retained_16_6 = Assert<Equal<ReplacementOutput<Maps[16], "value", Constraints[6]>, LegacyOutput<Maps[16], "value", Constraints[6]>>>;
export type Retained_16_7 = Assert<Equal<ReplacementOutput<Maps[16], "value", Constraints[7]>, LegacyOutput<Maps[16], "value", Constraints[7]>>>;
export type Retained_17_0 = Assert<Equal<ReplacementOutput<Maps[17], "value", Constraints[0]>, LegacyOutput<Maps[17], "value", Constraints[0]>>>;
export type Retained_17_1 = Assert<Equal<ReplacementOutput<Maps[17], "value", Constraints[1]>, LegacyOutput<Maps[17], "value", Constraints[1]>>>;
export type Retained_17_2 = Assert<Equal<ReplacementOutput<Maps[17], "value", Constraints[2]>, LegacyOutput<Maps[17], "value", Constraints[2]>>>;
export type Retained_17_3 = Assert<Equal<ReplacementOutput<Maps[17], "value", Constraints[3]>, LegacyOutput<Maps[17], "value", Constraints[3]>>>;
export type Retained_17_4 = Assert<Equal<ReplacementOutput<Maps[17], "value", Constraints[4]>, LegacyOutput<Maps[17], "value", Constraints[4]>>>;
export type Retained_17_5 = Assert<Equal<ReplacementOutput<Maps[17], "value", Constraints[5]>, LegacyOutput<Maps[17], "value", Constraints[5]>>>;
export type Retained_17_6 = Assert<Equal<ReplacementOutput<Maps[17], "value", Constraints[6]>, LegacyOutput<Maps[17], "value", Constraints[6]>>>;
export type Retained_17_7 = Assert<Equal<ReplacementOutput<Maps[17], "value", Constraints[7]>, LegacyOutput<Maps[17], "value", Constraints[7]>>>;
export type Retained_18_0 = Assert<Equal<ReplacementOutput<Maps[18], "value", Constraints[0]>, LegacyOutput<Maps[18], "value", Constraints[0]>>>;
export type Retained_18_1 = Assert<Equal<ReplacementOutput<Maps[18], "value", Constraints[1]>, LegacyOutput<Maps[18], "value", Constraints[1]>>>;
export type Retained_18_2 = Assert<Equal<ReplacementOutput<Maps[18], "value", Constraints[2]>, LegacyOutput<Maps[18], "value", Constraints[2]>>>;
export type Retained_18_3 = Assert<Equal<ReplacementOutput<Maps[18], "value", Constraints[3]>, LegacyOutput<Maps[18], "value", Constraints[3]>>>;
export type Retained_18_4 = Assert<Equal<ReplacementOutput<Maps[18], "value", Constraints[4]>, LegacyOutput<Maps[18], "value", Constraints[4]>>>;
export type Retained_18_5 = Assert<Equal<ReplacementOutput<Maps[18], "value", Constraints[5]>, LegacyOutput<Maps[18], "value", Constraints[5]>>>;
export type Retained_18_6 = Assert<Equal<ReplacementOutput<Maps[18], "value", Constraints[6]>, LegacyOutput<Maps[18], "value", Constraints[6]>>>;
export type Retained_18_7 = Assert<Equal<ReplacementOutput<Maps[18], "value", Constraints[7]>, LegacyOutput<Maps[18], "value", Constraints[7]>>>;
export type Retained_19_0 = Assert<Equal<ReplacementOutput<Maps[19], "value", Constraints[0]>, LegacyOutput<Maps[19], "value", Constraints[0]>>>;
export type Retained_19_1 = Assert<Equal<ReplacementOutput<Maps[19], "value", Constraints[1]>, LegacyOutput<Maps[19], "value", Constraints[1]>>>;
export type Retained_19_2 = Assert<Equal<ReplacementOutput<Maps[19], "value", Constraints[2]>, LegacyOutput<Maps[19], "value", Constraints[2]>>>;
export type Retained_19_3 = Assert<Equal<ReplacementOutput<Maps[19], "value", Constraints[3]>, LegacyOutput<Maps[19], "value", Constraints[3]>>>;
export type Retained_19_4 = Assert<Equal<ReplacementOutput<Maps[19], "value", Constraints[4]>, LegacyOutput<Maps[19], "value", Constraints[4]>>>;
export type Retained_19_5 = Assert<Equal<ReplacementOutput<Maps[19], "value", Constraints[5]>, LegacyOutput<Maps[19], "value", Constraints[5]>>>;
export type Retained_19_6 = Assert<Equal<ReplacementOutput<Maps[19], "value", Constraints[6]>, LegacyOutput<Maps[19], "value", Constraints[6]>>>;
export type Retained_19_7 = Assert<Equal<ReplacementOutput<Maps[19], "value", Constraints[7]>, LegacyOutput<Maps[19], "value", Constraints[7]>>>;
export type Retained_20_0 = Assert<Equal<ReplacementOutput<Maps[20], "value", Constraints[0]>, LegacyOutput<Maps[20], "value", Constraints[0]>>>;
export type Retained_20_1 = Assert<Equal<ReplacementOutput<Maps[20], "value", Constraints[1]>, LegacyOutput<Maps[20], "value", Constraints[1]>>>;
export type Retained_20_2 = Assert<Equal<ReplacementOutput<Maps[20], "value", Constraints[2]>, LegacyOutput<Maps[20], "value", Constraints[2]>>>;
export type Retained_20_3 = Assert<Equal<ReplacementOutput<Maps[20], "value", Constraints[3]>, LegacyOutput<Maps[20], "value", Constraints[3]>>>;
export type Retained_20_4 = Assert<Equal<ReplacementOutput<Maps[20], "value", Constraints[4]>, LegacyOutput<Maps[20], "value", Constraints[4]>>>;
export type Retained_20_5 = Assert<Equal<ReplacementOutput<Maps[20], "value", Constraints[5]>, LegacyOutput<Maps[20], "value", Constraints[5]>>>;
export type Retained_20_6 = Assert<Equal<ReplacementOutput<Maps[20], "value", Constraints[6]>, LegacyOutput<Maps[20], "value", Constraints[6]>>>;
export type Retained_20_7 = Assert<Equal<ReplacementOutput<Maps[20], "value", Constraints[7]>, LegacyOutput<Maps[20], "value", Constraints[7]>>>;
export type Retained_21_0 = Assert<Equal<ReplacementOutput<Maps[21], "value", Constraints[0]>, LegacyOutput<Maps[21], "value", Constraints[0]>>>;
export type Retained_21_1 = Assert<Equal<ReplacementOutput<Maps[21], "value", Constraints[1]>, LegacyOutput<Maps[21], "value", Constraints[1]>>>;
export type Retained_21_2 = Assert<Equal<ReplacementOutput<Maps[21], "value", Constraints[2]>, LegacyOutput<Maps[21], "value", Constraints[2]>>>;
export type Retained_21_3 = Assert<Equal<ReplacementOutput<Maps[21], "value", Constraints[3]>, LegacyOutput<Maps[21], "value", Constraints[3]>>>;
export type Retained_21_4 = Assert<Equal<ReplacementOutput<Maps[21], "value", Constraints[4]>, LegacyOutput<Maps[21], "value", Constraints[4]>>>;
export type Retained_21_5 = Assert<Equal<ReplacementOutput<Maps[21], "value", Constraints[5]>, LegacyOutput<Maps[21], "value", Constraints[5]>>>;
export type Retained_21_6 = Assert<Equal<ReplacementOutput<Maps[21], "value", Constraints[6]>, LegacyOutput<Maps[21], "value", Constraints[6]>>>;
export type Retained_21_7 = Assert<Equal<ReplacementOutput<Maps[21], "value", Constraints[7]>, LegacyOutput<Maps[21], "value", Constraints[7]>>>;
export type Retained_22_0 = Assert<Equal<ReplacementOutput<Maps[22], "value", Constraints[0]>, LegacyOutput<Maps[22], "value", Constraints[0]>>>;
export type Retained_22_1 = Assert<Equal<ReplacementOutput<Maps[22], "value", Constraints[1]>, LegacyOutput<Maps[22], "value", Constraints[1]>>>;
export type Retained_22_2 = Assert<Equal<ReplacementOutput<Maps[22], "value", Constraints[2]>, LegacyOutput<Maps[22], "value", Constraints[2]>>>;
export type Retained_22_3 = Assert<Equal<ReplacementOutput<Maps[22], "value", Constraints[3]>, LegacyOutput<Maps[22], "value", Constraints[3]>>>;
export type Retained_22_4 = Assert<Equal<ReplacementOutput<Maps[22], "value", Constraints[4]>, LegacyOutput<Maps[22], "value", Constraints[4]>>>;
export type Retained_22_5 = Assert<Equal<ReplacementOutput<Maps[22], "value", Constraints[5]>, LegacyOutput<Maps[22], "value", Constraints[5]>>>;
export type Retained_22_6 = Assert<Equal<ReplacementOutput<Maps[22], "value", Constraints[6]>, LegacyOutput<Maps[22], "value", Constraints[6]>>>;
export type Retained_22_7 = Assert<Equal<ReplacementOutput<Maps[22], "value", Constraints[7]>, LegacyOutput<Maps[22], "value", Constraints[7]>>>;
export type Retained_23_0 = Assert<Equal<ReplacementOutput<Maps[23], "value", Constraints[0]>, LegacyOutput<Maps[23], "value", Constraints[0]>>>;
export type Retained_23_1 = Assert<Equal<ReplacementOutput<Maps[23], "value", Constraints[1]>, LegacyOutput<Maps[23], "value", Constraints[1]>>>;
export type Retained_23_2 = Assert<Equal<ReplacementOutput<Maps[23], "value", Constraints[2]>, LegacyOutput<Maps[23], "value", Constraints[2]>>>;
export type Retained_23_3 = Assert<Equal<ReplacementOutput<Maps[23], "value", Constraints[3]>, LegacyOutput<Maps[23], "value", Constraints[3]>>>;
export type Retained_23_4 = Assert<Equal<ReplacementOutput<Maps[23], "value", Constraints[4]>, LegacyOutput<Maps[23], "value", Constraints[4]>>>;
export type Retained_23_5 = Assert<Equal<ReplacementOutput<Maps[23], "value", Constraints[5]>, LegacyOutput<Maps[23], "value", Constraints[5]>>>;
export type Retained_23_6 = Assert<Equal<ReplacementOutput<Maps[23], "value", Constraints[6]>, LegacyOutput<Maps[23], "value", Constraints[6]>>>;
export type Retained_23_7 = Assert<Equal<ReplacementOutput<Maps[23], "value", Constraints[7]>, LegacyOutput<Maps[23], "value", Constraints[7]>>>;
export type Retained_24_0 = Assert<Equal<ReplacementOutput<Maps[24], "value", Constraints[0]>, LegacyOutput<Maps[24], "value", Constraints[0]>>>;
export type Retained_24_1 = Assert<Equal<ReplacementOutput<Maps[24], "value", Constraints[1]>, LegacyOutput<Maps[24], "value", Constraints[1]>>>;
export type Retained_24_2 = Assert<Equal<ReplacementOutput<Maps[24], "value", Constraints[2]>, LegacyOutput<Maps[24], "value", Constraints[2]>>>;
export type Retained_24_3 = Assert<Equal<ReplacementOutput<Maps[24], "value", Constraints[3]>, LegacyOutput<Maps[24], "value", Constraints[3]>>>;
export type Retained_24_4 = Assert<Equal<ReplacementOutput<Maps[24], "value", Constraints[4]>, LegacyOutput<Maps[24], "value", Constraints[4]>>>;
export type Retained_24_5 = Assert<Equal<ReplacementOutput<Maps[24], "value", Constraints[5]>, LegacyOutput<Maps[24], "value", Constraints[5]>>>;
export type Retained_24_6 = Assert<Equal<ReplacementOutput<Maps[24], "value", Constraints[6]>, LegacyOutput<Maps[24], "value", Constraints[6]>>>;
export type Retained_24_7 = Assert<Equal<ReplacementOutput<Maps[24], "value", Constraints[7]>, LegacyOutput<Maps[24], "value", Constraints[7]>>>;
export type Retained_25_0 = Assert<Equal<ReplacementOutput<Maps[25], "value", Constraints[0]>, LegacyOutput<Maps[25], "value", Constraints[0]>>>;
export type Retained_25_1 = Assert<Equal<ReplacementOutput<Maps[25], "value", Constraints[1]>, LegacyOutput<Maps[25], "value", Constraints[1]>>>;
export type Retained_25_2 = Assert<Equal<ReplacementOutput<Maps[25], "value", Constraints[2]>, LegacyOutput<Maps[25], "value", Constraints[2]>>>;
export type Retained_25_3 = Assert<Equal<ReplacementOutput<Maps[25], "value", Constraints[3]>, LegacyOutput<Maps[25], "value", Constraints[3]>>>;
export type Retained_25_4 = Assert<Equal<ReplacementOutput<Maps[25], "value", Constraints[4]>, LegacyOutput<Maps[25], "value", Constraints[4]>>>;
export type Retained_25_5 = Assert<Equal<ReplacementOutput<Maps[25], "value", Constraints[5]>, LegacyOutput<Maps[25], "value", Constraints[5]>>>;
export type Retained_25_6 = Assert<Equal<ReplacementOutput<Maps[25], "value", Constraints[6]>, LegacyOutput<Maps[25], "value", Constraints[6]>>>;
export type Retained_25_7 = Assert<Equal<ReplacementOutput<Maps[25], "value", Constraints[7]>, LegacyOutput<Maps[25], "value", Constraints[7]>>>;
export type Retained_26_0 = Assert<Equal<ReplacementOutput<Maps[26], "value", Constraints[0]>, LegacyOutput<Maps[26], "value", Constraints[0]>>>;
export type Retained_26_1 = Assert<Equal<ReplacementOutput<Maps[26], "value", Constraints[1]>, LegacyOutput<Maps[26], "value", Constraints[1]>>>;
export type Retained_26_2 = Assert<Equal<ReplacementOutput<Maps[26], "value", Constraints[2]>, LegacyOutput<Maps[26], "value", Constraints[2]>>>;
export type Retained_26_3 = Assert<Equal<ReplacementOutput<Maps[26], "value", Constraints[3]>, LegacyOutput<Maps[26], "value", Constraints[3]>>>;
export type Retained_26_4 = Assert<Equal<ReplacementOutput<Maps[26], "value", Constraints[4]>, LegacyOutput<Maps[26], "value", Constraints[4]>>>;
export type Retained_26_5 = Assert<Equal<ReplacementOutput<Maps[26], "value", Constraints[5]>, LegacyOutput<Maps[26], "value", Constraints[5]>>>;
export type Retained_26_6 = Assert<Equal<ReplacementOutput<Maps[26], "value", Constraints[6]>, LegacyOutput<Maps[26], "value", Constraints[6]>>>;
export type Retained_26_7 = Assert<Equal<ReplacementOutput<Maps[26], "value", Constraints[7]>, LegacyOutput<Maps[26], "value", Constraints[7]>>>;
export type Retained_27_0 = Assert<Equal<ReplacementOutput<Maps[27], "value", Constraints[0]>, LegacyOutput<Maps[27], "value", Constraints[0]>>>;
export type Retained_27_1 = Assert<Equal<ReplacementOutput<Maps[27], "value", Constraints[1]>, LegacyOutput<Maps[27], "value", Constraints[1]>>>;
export type Retained_27_2 = Assert<Equal<ReplacementOutput<Maps[27], "value", Constraints[2]>, LegacyOutput<Maps[27], "value", Constraints[2]>>>;
export type Retained_27_3 = Assert<Equal<ReplacementOutput<Maps[27], "value", Constraints[3]>, LegacyOutput<Maps[27], "value", Constraints[3]>>>;
export type Retained_27_4 = Assert<Equal<ReplacementOutput<Maps[27], "value", Constraints[4]>, LegacyOutput<Maps[27], "value", Constraints[4]>>>;
export type Retained_27_5 = Assert<Equal<ReplacementOutput<Maps[27], "value", Constraints[5]>, LegacyOutput<Maps[27], "value", Constraints[5]>>>;
export type Retained_27_6 = Assert<Equal<ReplacementOutput<Maps[27], "value", Constraints[6]>, LegacyOutput<Maps[27], "value", Constraints[6]>>>;
export type Retained_27_7 = Assert<Equal<ReplacementOutput<Maps[27], "value", Constraints[7]>, LegacyOutput<Maps[27], "value", Constraints[7]>>>;
export type Retained_28_0 = Assert<Equal<ReplacementOutput<Maps[28], "value", Constraints[0]>, LegacyOutput<Maps[28], "value", Constraints[0]>>>;
export type Retained_28_1 = Assert<Equal<ReplacementOutput<Maps[28], "value", Constraints[1]>, LegacyOutput<Maps[28], "value", Constraints[1]>>>;
export type Retained_28_2 = Assert<Equal<ReplacementOutput<Maps[28], "value", Constraints[2]>, LegacyOutput<Maps[28], "value", Constraints[2]>>>;
export type Retained_28_3 = Assert<Equal<ReplacementOutput<Maps[28], "value", Constraints[3]>, LegacyOutput<Maps[28], "value", Constraints[3]>>>;
export type Retained_28_4 = Assert<Equal<ReplacementOutput<Maps[28], "value", Constraints[4]>, LegacyOutput<Maps[28], "value", Constraints[4]>>>;
export type Retained_28_5 = Assert<Equal<ReplacementOutput<Maps[28], "value", Constraints[5]>, LegacyOutput<Maps[28], "value", Constraints[5]>>>;
export type Retained_28_6 = Assert<Equal<ReplacementOutput<Maps[28], "value", Constraints[6]>, LegacyOutput<Maps[28], "value", Constraints[6]>>>;
export type Retained_28_7 = Assert<Equal<ReplacementOutput<Maps[28], "value", Constraints[7]>, LegacyOutput<Maps[28], "value", Constraints[7]>>>;
export type Retained_29_0 = Assert<Equal<ReplacementOutput<Maps[29], "value", Constraints[0]>, LegacyOutput<Maps[29], "value", Constraints[0]>>>;
export type Retained_29_1 = Assert<Equal<ReplacementOutput<Maps[29], "value", Constraints[1]>, LegacyOutput<Maps[29], "value", Constraints[1]>>>;
export type Retained_29_2 = Assert<Equal<ReplacementOutput<Maps[29], "value", Constraints[2]>, LegacyOutput<Maps[29], "value", Constraints[2]>>>;
export type Retained_29_3 = Assert<Equal<ReplacementOutput<Maps[29], "value", Constraints[3]>, LegacyOutput<Maps[29], "value", Constraints[3]>>>;
export type Retained_29_4 = Assert<Equal<ReplacementOutput<Maps[29], "value", Constraints[4]>, LegacyOutput<Maps[29], "value", Constraints[4]>>>;
export type Retained_29_5 = Assert<Equal<ReplacementOutput<Maps[29], "value", Constraints[5]>, LegacyOutput<Maps[29], "value", Constraints[5]>>>;
export type Retained_29_6 = Assert<Equal<ReplacementOutput<Maps[29], "value", Constraints[6]>, LegacyOutput<Maps[29], "value", Constraints[6]>>>;
export type Retained_29_7 = Assert<Equal<ReplacementOutput<Maps[29], "value", Constraints[7]>, LegacyOutput<Maps[29], "value", Constraints[7]>>>;
export type ExactUnionValued = Assert<Equal<ReplacementOutput<Maps[14], "value">, number | string>>;
export type ExactUnionMap = Assert<Equal<ReplacementOutput<Maps[15], "value">, number | string>>;
export type ExactDistinctMapKeys = Assert<Equal<ReplacementOutput<Maps[16], "value">, unknown>>;
export declare function allToOld<R extends Registrations, K extends PropertyKey, C>(x: ReplacementOutput<R, K, C>): LegacyOutput<R, K, C>;
export declare function allFromOld<R extends Registrations, K extends PropertyKey, C>(x: LegacyOutput<R, K, C>): ReplacementOutput<R, K, C>;
export declare function keyToOld_1<K extends PropertyKey>(x: ReplacementOutput<Maps[1], K>): LegacyOutput<Maps[1], K>;
export declare function keyFromOld_1<K extends PropertyKey>(x: LegacyOutput<Maps[1], K>): ReplacementOutput<Maps[1], K>;
export type OpenKey_2<K extends PropertyKey> = Assert<Equal<ReplacementOutput<Maps[2], K>, LegacyOutput<Maps[2], K>>>;
export declare function keyToOld_2<K extends PropertyKey>(x: ReplacementOutput<Maps[2], K>): LegacyOutput<Maps[2], K>;
export declare function keyFromOld_2<K extends PropertyKey>(x: LegacyOutput<Maps[2], K>): ReplacementOutput<Maps[2], K>;
export declare function keyToOld_3<K extends PropertyKey>(x: ReplacementOutput<Maps[3], K>): LegacyOutput<Maps[3], K>;
export declare function keyFromOld_3<K extends PropertyKey>(x: LegacyOutput<Maps[3], K>): ReplacementOutput<Maps[3], K>;
export declare function keyToOld_4<K extends PropertyKey>(x: ReplacementOutput<Maps[4], K>): LegacyOutput<Maps[4], K>;
export declare function keyFromOld_4<K extends PropertyKey>(x: LegacyOutput<Maps[4], K>): ReplacementOutput<Maps[4], K>;
export declare function keyToOld_16<K extends PropertyKey>(x: ReplacementOutput<Maps[16], K>): LegacyOutput<Maps[16], K>;
export declare function keyFromOld_16<K extends PropertyKey>(x: LegacyOutput<Maps[16], K>): ReplacementOutput<Maps[16], K>;
export declare function keyToOld_21<K extends PropertyKey>(x: ReplacementOutput<Maps[21], K>): LegacyOutput<Maps[21], K>;
export declare function keyFromOld_21<K extends PropertyKey>(x: LegacyOutput<Maps[21], K>): ReplacementOutput<Maps[21], K>;
export declare function keyToOld_22<K extends PropertyKey>(x: ReplacementOutput<Maps[22], K>): LegacyOutput<Maps[22], K>;
export declare function keyFromOld_22<K extends PropertyKey>(x: LegacyOutput<Maps[22], K>): ReplacementOutput<Maps[22], K>;
export declare function keyToOld_23<K extends PropertyKey>(x: ReplacementOutput<Maps[23], K>): LegacyOutput<Maps[23], K>;
export declare function keyFromOld_23<K extends PropertyKey>(x: LegacyOutput<Maps[23], K>): ReplacementOutput<Maps[23], K>;
export declare function keyToOld_24<K extends PropertyKey>(x: ReplacementOutput<Maps[24], K>): LegacyOutput<Maps[24], K>;
export declare function keyFromOld_24<K extends PropertyKey>(x: LegacyOutput<Maps[24], K>): ReplacementOutput<Maps[24], K>;
export declare function mapToOld_0<R extends Registrations>(x: ReplacementOutput<R, Keys[0]>): LegacyOutput<R, Keys[0]>;
export declare function mapFromOld_0<R extends Registrations>(x: LegacyOutput<R, Keys[0]>): ReplacementOutput<R, Keys[0]>;
export declare function mapToOld_1<R extends Registrations>(x: ReplacementOutput<R, Keys[1]>): LegacyOutput<R, Keys[1]>;
export declare function mapFromOld_1<R extends Registrations>(x: LegacyOutput<R, Keys[1]>): ReplacementOutput<R, Keys[1]>;
export declare function mapToOld_2<R extends Registrations>(x: ReplacementOutput<R, Keys[2]>): LegacyOutput<R, Keys[2]>;
export declare function mapFromOld_2<R extends Registrations>(x: LegacyOutput<R, Keys[2]>): ReplacementOutput<R, Keys[2]>;
export declare function mapToOld_3<R extends Registrations>(x: ReplacementOutput<R, Keys[3]>): LegacyOutput<R, Keys[3]>;
export declare function mapFromOld_3<R extends Registrations>(x: LegacyOutput<R, Keys[3]>): ReplacementOutput<R, Keys[3]>;
export declare function mapToOld_4<R extends Registrations>(x: ReplacementOutput<R, Keys[4]>): LegacyOutput<R, Keys[4]>;
export declare function mapFromOld_4<R extends Registrations>(x: LegacyOutput<R, Keys[4]>): ReplacementOutput<R, Keys[4]>;
export declare function mapToOld_5<R extends Registrations>(x: ReplacementOutput<R, Keys[5]>): LegacyOutput<R, Keys[5]>;
export declare function mapFromOld_5<R extends Registrations>(x: LegacyOutput<R, Keys[5]>): ReplacementOutput<R, Keys[5]>;
export declare function mapToOld_6<R extends Registrations>(x: ReplacementOutput<R, Keys[6]>): LegacyOutput<R, Keys[6]>;
export declare function mapFromOld_6<R extends Registrations>(x: LegacyOutput<R, Keys[6]>): ReplacementOutput<R, Keys[6]>;
export declare function mapToOld_7<R extends Registrations>(x: ReplacementOutput<R, Keys[7]>): LegacyOutput<R, Keys[7]>;
export declare function mapFromOld_7<R extends Registrations>(x: LegacyOutput<R, Keys[7]>): ReplacementOutput<R, Keys[7]>;
export declare function mapToOld_8<R extends Registrations>(x: ReplacementOutput<R, Keys[8]>): LegacyOutput<R, Keys[8]>;
export declare function mapFromOld_8<R extends Registrations>(x: LegacyOutput<R, Keys[8]>): ReplacementOutput<R, Keys[8]>;
export declare function mapToOld_9<R extends Registrations>(x: ReplacementOutput<R, Keys[9]>): LegacyOutput<R, Keys[9]>;
export declare function mapFromOld_9<R extends Registrations>(x: LegacyOutput<R, Keys[9]>): ReplacementOutput<R, Keys[9]>;
export declare function mapToOld_10<R extends Registrations>(x: ReplacementOutput<R, Keys[10]>): LegacyOutput<R, Keys[10]>;
export declare function mapFromOld_10<R extends Registrations>(x: LegacyOutput<R, Keys[10]>): ReplacementOutput<R, Keys[10]>;
export declare function mapToOld_11<R extends Registrations>(x: ReplacementOutput<R, Keys[11]>): LegacyOutput<R, Keys[11]>;
export declare function mapFromOld_11<R extends Registrations>(x: LegacyOutput<R, Keys[11]>): ReplacementOutput<R, Keys[11]>;
export {};
