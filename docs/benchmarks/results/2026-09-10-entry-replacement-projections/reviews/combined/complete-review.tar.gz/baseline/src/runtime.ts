import { Acquisitions } from './acquisition';
import { PersistentMap } from './persistent-map';
import { append, materialize } from './persistent-sequence';
import type { Sequence } from './persistent-sequence';
import { DiBagCleanupError } from './errors';
import type { CleanupFailure } from './errors';
import { normalize } from './registration';
import type { Registration, Registrations } from './registration';
import type { InspectionSnapshot } from './inspection';
import { requireClassificationCapability } from './acquisition-mode';
import type { RuntimeContext } from './acquisition-mode';

export type BindingId = symbol;
export type BindingKey = string | symbol;
export type BindingRef =
  | { readonly kind: 'private'; readonly id: BindingId }
  | { readonly kind: 'public'; readonly key: BindingKey };

export interface BindingDescription {
  readonly id: BindingId;
  readonly label: string;
  readonly registration: Registration;
  readonly localNames: ReadonlyMap<BindingKey, BindingRef>;
}

export interface GraphDescription {
  readonly bindings: ReadonlyMap<BindingId, BindingDescription>;
  readonly publicSlots: ReadonlyMap<BindingKey, BindingId>;
  readonly contributions?: ReadonlyMap<symbol, readonly BindingId[]>;
}

type Normalized = Readonly<ReturnType<typeof normalize>>;

type LexicalSnapshot = {
  readonly id: symbol;
  readonly names: ReadonlyMap<BindingKey, BindingRef>;
  readonly privateIds: readonly BindingId[];
};
type BindingEntry = {
  readonly description: BindingDescription;
  readonly normalized: Normalized;
  readonly lexical?: LexicalSnapshot;
};
const emptyContributions: readonly BindingId[] = Object.freeze([]);
const emptyNames: ReadonlyMap<BindingKey, BindingRef> = new Map();

/** Immutable descriptions and path-copied lookup storage. Retained maps never escape. */
export class BindingGraph {
  #bindings = new PersistentMap<BindingEntry>();
  #publicSlots = new PersistentMap<BindingId>();
  #publicReferences = new PersistentMap<number>();
  #lexicalUsers = new PersistentMap<number>();
  #privateReferences = new PersistentMap<number>();
  #contributed = new PersistentMap<true>();
  // Only former public bindings are candidates; constructor-only private
  // registrations remain available to whole-graph preflight.
  #obsolete = new PersistentMap<true>();
  #contributions = new PersistentMap<Sequence<BindingId>>();
  readonly #bindingCache = new Map<BindingId, BindingDescription>();
  readonly #registrationCache = new Map<BindingId, Normalized>();
  readonly #publicCache = new Map<BindingKey, BindingId>();
  readonly #contributionCache = new Map<symbol, readonly BindingId[]>();
  #explicitlyClassified = false;

  constructor(description: GraphDescription = { bindings: new Map(), publicSlots: new Map() }) {
    const lexicalSnapshots = new Map<BindingDescription['localNames'], LexicalSnapshot>();
    for (const [id, binding] of description.bindings) {
      let lexical = lexicalSnapshots.get(binding.localNames);
      if (!lexical) {
        const snapshot = new Map<BindingKey, BindingRef>();
        const privateIds: BindingId[] = [];
        for (const [name, ref] of binding.localNames) {
          const copiedRef = Object.freeze({ ...ref });
          snapshot.set(name, copiedRef);
          if (copiedRef.kind === 'private') privateIds.push(copiedRef.id);
        }
        lexical = { id: Symbol('lexical'), names: snapshot, privateIds };
        lexicalSnapshots.set(binding.localNames, lexical);
        for (const target of privateIds) this.#privateReferences = this.#privateReferences.set(target, (this.#privateReferences.get(target) ?? 0) + 1);
      }
      this.#lexicalUsers = this.#lexicalUsers.set(lexical.id, (this.#lexicalUsers.get(lexical.id) ?? 0) + 1);
      this.#bindings = this.#bindings.set(id, {
        lexical,
        description: Object.freeze({ id: binding.id, label: binding.label, registration: binding.registration, localNames: lexical.names }),
        normalized: Object.freeze(normalize(binding.registration)),
      });
    }
    for (const [key, id] of description.publicSlots) {
      this.#publicSlots = this.#publicSlots.set(key, id);
      this.#publicReferences = this.#publicReferences.set(id, (this.#publicReferences.get(id) ?? 0) + 1);
    }
    for (const [key, ids] of description.contributions ?? []) {
      const snapshot = Object.freeze([...ids]);
      this.#contributions = this.#contributions.set(key, { values: snapshot });
      for (const id of snapshot) this.#contributed = this.#contributed.set(id, true);
    }
  }

  /** Share only storage roots. Caches never retain ancestor wrappers or old arrays. */
  private copy(): BindingGraph {
    const graph = new BindingGraph();
    graph.#bindings = this.#bindings;
    graph.#publicSlots = this.#publicSlots;
    graph.#publicReferences = this.#publicReferences;
    graph.#lexicalUsers = this.#lexicalUsers;
    graph.#privateReferences = this.#privateReferences;
    graph.#contributed = this.#contributed;
    graph.#obsolete = this.#obsolete;
    graph.#contributions = this.#contributions;
    return graph;
  }

  private entry(id: BindingId): BindingEntry | undefined {
    const entry = this.#bindings.get(id);
    if (entry) {
      this.#bindingCache.set(id, entry.description);
      this.#registrationCache.set(id, entry.normalized);
    }
    return entry;
  }

  private slot(key: BindingKey): BindingId | undefined {
    const id = this.#publicSlots.get(key);
    if (id !== undefined) this.#publicCache.set(key, id);
    return id;
  }

  private addBinding(label: string, registration: Registration): BindingId {
    const id = Symbol(label);
    this.#bindings = this.#bindings.set(id, {
      description: Object.freeze({ id, label, registration, localNames: emptyNames }),
      normalized: Object.freeze(normalize(registration)),
    });
    return id;
  }

  contributionBindings(key: symbol): readonly BindingId[] {
    let ids = this.#contributionCache.get(key);
    if (!ids) {
      const sequence = this.#contributions.get(key);
      if (!sequence) return emptyContributions;
      ids = materialize(sequence);
      this.#contributionCache.set(key, ids);
    }
    return ids;
  }

  withContribution(key: symbol, registration: Registration): BindingGraph {
    const graph = this.copy();
    const id = graph.addBinding(`contribution:${String(key)}`, registration);
    graph.#contributions = graph.#contributions.set(key, append(graph.#contributions.get(key), { values: [id] }));
    graph.#contributed = graph.#contributed.set(id, true);
    return graph;
  }

  hasPublic(key: BindingKey): boolean { return this.#publicCache.has(key) || this.#publicSlots.has(key); }
  hasBinding(id: BindingId): boolean { return this.#bindings.has(id); }

  /** Immutable graphs need explicit-mode validation only once; configured forks are O(1). */
  preflight(context: RuntimeContext): void {
    if (context.isNativePromise || this.#explicitlyClassified) return;
    for (const [, { normalized: description }] of this.#bindings) {
      requireClassificationCapability([description.acquisition, ...description.operations.flatMap(operation =>
        'acquisition' in operation ? [operation.acquisition] : [])], context);
    }
    this.#explicitlyClassified = true;
  }

  publicBinding(key: BindingKey): BindingId {
    return this.#publicCache.get(key) ?? this.requirePublicBinding(key);
  }

  private requirePublicBinding(key: BindingKey): BindingId {
    const id = this.slot(key);
    if (id === undefined) throw new Error(`no factory for ${String(key)}`);
    return id;
  }

  findDependency(from: BindingId, localName: BindingKey): BindingId | undefined {
    const ref = (this.#bindingCache.get(from) ?? this.entry(from)?.description)?.localNames.get(localName);
    if (ref?.kind === 'private') return ref.id;
    const key = ref?.key ?? localName;
    return this.#publicCache.get(key) ?? this.slot(key);
  }

  dependency(from: BindingId, localName: BindingKey): BindingId {
    const ref = (this.#bindingCache.get(from) ?? this.entry(from)?.description)?.localNames.get(localName);
    return ref?.kind === 'private' ? ref.id : this.publicBinding(ref?.key ?? localName);
  }

  registration(id: BindingId): Normalized {
    return this.#registrationCache.get(id) ?? this.requireRegistration(id);
  }

  private requireRegistration(id: BindingId): Normalized {
    const registration = this.entry(id)?.normalized;
    if (!registration) throw new Error(`no factory for ${this.label(id)}`);
    return registration;
  }

  label(id: BindingId): string { return (this.#bindingCache.get(id) ?? this.entry(id)?.description)?.label ?? String(id); }

  withPublicRegistrations(registrations: Registrations): BindingGraph {
    return this.withPublicBindings(Object.keys(registrations).map(key => [key, registrations[key]!]));
  }

  /** Replace ordered slots and prune only unreferenced public replacement history. */
  withPublicBindings(entries: readonly (readonly [BindingKey, Registration])[]): BindingGraph {
    if (entries.length === 0) return this;
    const graph = this.copy();
    for (const [key, registration] of entries) {
      const previous = graph.#publicSlots.get(key);
      const id = graph.addBinding(String(key), registration);
      graph.#publicSlots = graph.#publicSlots.set(key, id);
      graph.#publicReferences = graph.#publicReferences.set(id, 1);
      if (previous !== undefined) {
        const remaining = (graph.#publicReferences.get(previous) ?? 1) - 1;
        if (remaining) graph.#publicReferences = graph.#publicReferences.set(previous, remaining);
        else {
          graph.#publicReferences = graph.#publicReferences.delete(previous);
          graph.#obsolete = graph.#obsolete.set(previous, true);
          graph.prune([previous]);
        }
      }
    }
    return graph;
  }

  withPublicBinding(key: BindingKey, registration: Registration): BindingGraph {
    return this.withPublicBindings([[key, registration]]);
  }

  private releaseLexical(entry: BindingEntry, pending: BindingId[]): void {
    const lexical = entry.lexical;
    if (!lexical) return;
    const remaining = this.#lexicalUsers.get(lexical.id)! - 1;
    if (remaining) { this.#lexicalUsers = this.#lexicalUsers.set(lexical.id, remaining); return; }
    this.#lexicalUsers = this.#lexicalUsers.delete(lexical.id);
    for (const id of lexical.privateIds) {
      const count = this.#privateReferences.get(id)! - 1;
      if (count) this.#privateReferences = this.#privateReferences.set(id, count);
      else { this.#privateReferences = this.#privateReferences.delete(id); pending.push(id); }
    }
  }

  /** No recursion or graph-wide scan, even when losing a snapshot unlocks a chain. */
  private prune(pending: BindingId[]): void {
    while (pending.length) {
      const id = pending.pop()!;
      if (!this.#obsolete.has(id) || this.#publicReferences.has(id) || this.#privateReferences.has(id) || this.#contributed.has(id)) continue;
      const entry = this.#bindings.get(id);
      this.#bindings = this.#bindings.delete(id);
      this.#obsolete = this.#obsolete.delete(id);
      if (entry) this.releaseLexical(entry, pending);
    }
  }

  /** Install disjoint public slots atomically, retaining lexical private refs. */
  withInstallation(description: GraphDescription): BindingGraph {
    for (const key of description.publicSlots.keys()) {
      if (this.hasPublic(key)) throw new Error(`duplicate registration: ${String(key)}`);
    }
    const installation = new BindingGraph(description);
    const graph = this.copy();
    const pending: BindingId[] = [];
    // Publish all incoming protection before releasing overwritten descriptions.
    for (const [id, count] of installation.#lexicalUsers) graph.#lexicalUsers = graph.#lexicalUsers.set(id, count);
    for (const [id, count] of installation.#privateReferences) graph.#privateReferences = graph.#privateReferences.set(id, (graph.#privateReferences.get(id) ?? 0) + count);
    for (const [id] of installation.#contributed) graph.#contributed = graph.#contributed.set(id, true);
    for (const [key, id] of installation.#publicSlots) graph.#publicSlots = graph.#publicSlots.set(key, id);
    for (const [id, count] of installation.#publicReferences) graph.#publicReferences = graph.#publicReferences.set(id, (graph.#publicReferences.get(id) ?? 0) + count);
    for (const [id, entry] of installation.#bindings) {
      const previous = graph.#bindings.get(id);
      if (previous) graph.releaseLexical(previous, pending);
      graph.#bindings = graph.#bindings.set(id, entry);
      graph.#obsolete = graph.#obsolete.delete(id);
    }
    for (const [key, sequence] of installation.#contributions) graph.#contributions = graph.#contributions.set(key, append(graph.#contributions.get(key), sequence));
    graph.prune(pending);
    return graph;
  }
}

/** Each runtime owns its acquisitions; immutable descriptions remain reusable. */
export class Runtime {
  private readonly acquisitions: Acquisitions;
  private readonly children = new Set<Runtime>();
  private closing: Promise<void> | undefined;

  constructor(
    private readonly graph: BindingGraph,
    private readonly context: RuntimeContext,
    private detach: (() => void) | undefined = undefined,
    private readonly parentAcquisitions?: Acquisitions,
    shared: readonly BindingId[] = [],
  ) {
    graph.preflight(context);
    this.acquisitions = new Acquisitions(graph, context, parentAcquisitions, shared);
    this.observeScope('scope-opened');
  }

  resolve(key: BindingKey): unknown {
    return this.acquisitions.resolve(key);
  }

  resolveAll(key: symbol): readonly unknown[] { return this.acquisitions.resolveAll(key); }

  inspectAll(key: symbol): readonly InspectionSnapshot<object, readonly unknown[]>[] {
    return Object.freeze(this.graph.contributionBindings(key).map(bindingId => this.inspectBinding(bindingId)));
  }

  acquire(key: BindingKey): Promise<void> {
    return this.acquisitions.acquire(key);
  }

  isTransient(key: BindingKey): boolean {
    return this.acquisitions.isTransient(this.graph.publicBinding(key));
  }

  inspect(key: BindingKey): InspectionSnapshot<object, readonly unknown[]> {
    return this.inspectBinding(this.graph.publicBinding(key));
  }

  private inspectBinding(bindingId: BindingId): InspectionSnapshot<object, readonly unknown[]> {
    return Object.freeze({
      bindingId,
      label: this.graph.label(bindingId),
      ...this.acquisitions.inspectDescription(bindingId),
      acquisitions: this.acquisitions.inspect(bindingId),
    });
  }

  assertOpen(): void {
    if (this.closing) throw new Error('bag is closing');
    this.acquisitions.assertOpen();
  }

  scope(graph: BindingGraph = this.graph, shared: readonly BindingId[] = []): Runtime {
    this.assertOpen();
    let child!: Runtime;
    child = new Runtime(graph, this.context, () => { this.children.delete(child); }, this.acquisitions, shared);
    this.children.add(child);
    return child;
  }

  close(cause?: unknown): Promise<void> {
    if (this.closing) return this.closing;
    let fulfill!: () => void;
    let reject!: (error: unknown) => void;
    const closing = new Promise<void>((resolve, fail) => { fulfill = resolve; reject = fail; });
    // Publish before recursively closing children or starting local cleanup.
    this.closing = closing;
    this.observeScope('scope-closing');

    const childClosing = [...this.children].map(child => {
      try { return child.close(cause); }
      catch (error) { return Promise.reject(error); }
    });
    const childResults = Promise.allSettled(childClosing);
    let localClosing: Promise<void>;
    try {
      localClosing = this.acquisitions.close(
        childClosing.length > 0 ? childResults.then(() => undefined) : undefined,
        cause,
      );
    }
    catch (error) { localClosing = Promise.reject(error); }
    void this.finishClose(childResults, localClosing).then(
      () => { fulfill(); this.observeScope('scope-closed'); },
      error => { reject(error); this.observeScope('scope-close-failed', error); },
    );

    const detach = this.detach;
    this.detach = undefined;
    if (detach) void closing.then(
      () => { detach(); },
      () => { detach(); },
    );
    return closing;
  }

  private observeScope(kind: 'scope-opened' | 'scope-closing' | 'scope-closed' | 'scope-close-failed', error?: unknown): void {
    if (!this.context.observers) return;
    const fields = {
      scopeId: this.acquisitions.ownerId,
      ...(this.parentAcquisitions ? { parentScopeId: this.parentAcquisitions.ownerId } : {}),
    };
    this.context.observers.emit(kind === 'scope-close-failed' ? { ...fields, kind, error } : { ...fields, kind });
  }

  private async finishClose(
    childResults: Promise<PromiseSettledResult<void>[]>,
    localClosing: Promise<void>,
  ): Promise<void> {
    const [children, local] = await Promise.all([
      childResults,
      localClosing.then(
        () => ({ status: 'fulfilled' as const, value: undefined }),
        reason => ({ status: 'rejected' as const, reason }),
      ),
    ]);
    const failures: CleanupFailure[] = [];
    const unexpected: unknown[] = [];
    for (const result of [...children, local]) {
      if (result.status === 'fulfilled') continue;
      if (result.reason instanceof DiBagCleanupError) failures.push(...result.reason.failures);
      else unexpected.push(result.reason);
    }
    if (unexpected.length > 0) {
      const errors = failures.length > 0
        ? [new DiBagCleanupError(failures), ...unexpected]
        : unexpected;
      throw new AggregateError(errors, `Failed to close ${errors.length} runtime operation(s)`);
    }
    if (failures.length > 0) throw new DiBagCleanupError(failures);
  }
}
