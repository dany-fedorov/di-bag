declare const key: unique symbol;
type NamedFactory = () => {
    read(): number;
    extra: true;
};
type TokenFactory = () => {
    value: number;
    extra: true;
};
export declare const inferredNamed: () => import("../../src").Builder<{
    key: "named";
    registration: NamedFactory;
}, never>;
export declare const inferredToken: () => import("../../src").Builder<{
    key: typeof key;
    registration: import("../../src").Binding<import("../../src").Token<typeof key, {
        value: number;
    }>, TokenFactory>;
}, never>;
export declare const inferredNamedModule: () => import("../../src").ModuleBuilder<{
    key: "named";
    registration: NamedFactory;
}, never>;
export declare const inferredTokenModule: () => import("../../src").ModuleBuilder<{
    key: typeof key;
    registration: import("../../src").Binding<import("../../src").Token<typeof key, {
        value: number;
    }>, TokenFactory>;
}, never>;
export declare function forwardNamed(factory: NamedFactory): import("../../src").Builder<{
    key: "named";
    registration: NamedFactory;
}, never>;
export declare function forwardToken(factory: TokenFactory): import("../../src").Builder<{
    key: typeof key;
    registration: import("../../src").Binding<import("../../src").Token<typeof key, {
        value: number;
    }>, TokenFactory>;
}, never>;
export declare function forwardNamedModule(factory: NamedFactory): import("../../src").ModuleBuilder<{
    key: "named";
    registration: NamedFactory;
}, never>;
export declare function forwardTokenModule(factory: TokenFactory): import("../../src").ModuleBuilder<{
    key: typeof key;
    registration: import("../../src").Binding<import("../../src").Token<typeof key, {
        value: number;
    }>, TokenFactory>;
}, never>;
export declare function explicitNamed(factory: NamedFactory): import("../../src").Builder<{
    key: "named";
    registration: NamedFactory;
}, never>;
export declare function explicitToken(factory: TokenFactory): import("../../src").Builder<{
    key: typeof key;
    registration: import("../../src").Binding<import("../../src").Token<typeof key, {
        value: number;
    }>, TokenFactory>;
}, never>;
export declare function explicitNamedModule(factory: NamedFactory): import("../../src").ModuleBuilder<{
    key: "named";
    registration: NamedFactory;
}, never>;
export declare function explicitTokenModule(factory: TokenFactory): import("../../src").ModuleBuilder<{
    key: typeof key;
    registration: import("../../src").Binding<import("../../src").Token<typeof key, {
        value: number;
    }>, TokenFactory>;
}, never>;
export {};
