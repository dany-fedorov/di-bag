export declare const builder: import("../../src").Builder<import("../../src").Entries<{
    value: () => number;
    consumer: ({ value }: {
        value: number;
    }) => number;
}>, never>;
export declare const moduleBuilder: import("../../src").ModuleBuilder<import("../../src").Entries<{
    value: () => number;
    consumer: ({ value }: {
        value: number;
    }) => number;
}>, never>;
export type ModuleView = ReturnType<typeof moduleBuilder.replace>;
export declare const moduleView: ModuleView;
export declare const feature: import("../../src").Module<Pick<import("../../src").Provided<import("../../src").From<{
    key: never;
    registration: import("../../src").Binding<import("../../src").TokenBase, import("../../src").Registration>;
} | import("../../src").Entries<{
    value: () => number;
    consumer: ({ value }: {
        value: number;
    }) => number;
}>>>, "consumer" | "value">, Readonly<{}>, {
    readonly consumer: "consumer";
    readonly needs: Pick<{
        value: number;
    }, "value">;
    readonly kind: "export";
}, import("../../src").ModulePublicProviders<import("../../src").From<{
    key: never;
    registration: import("../../src").Binding<import("../../src").TokenBase, import("../../src").Registration>;
} | import("../../src").Entries<{
    value: () => number;
    consumer: ({ value }: {
        value: number;
    }) => number;
}>>, "consumer" | "value">>;
export declare const result: number;
export declare const forward: (factory: () => number) => import("../../src").Builder<{
    key: "consumer";
    registration: ({ value }: {
        value: number;
    }) => number;
} | {
    key: "value";
    registration: () => number;
}, never>;
