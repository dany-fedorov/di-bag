import { contextual, started, bounded, lazy, selectedToken, raw, native } from './startup';
import type { ProviderNeeds, ProviderAcquired, ProviderOutput } from '../../src';
import type { Assert, Equal } from './assert';

export type Contracts = [
  Assert<Equal<Awaited<typeof started>, typeof lazy>>,
  Assert<Equal<typeof bounded, typeof started>>,
  Assert<Equal<ProviderNeeds<typeof contextual>, { input: { readonly label: 'exact' } }>>,
  Assert<Equal<ProviderAcquired<typeof raw>, Promise<{ value: 42 }>>>,
  Assert<Equal<ProviderOutput<typeof native>, Promise<{ signal: AbortSignal; value: 1 }>>>,
  Assert<Equal<0 extends (1 & Awaited<typeof started>) ? true : false, false>>,
];
export async function consume() {
  const bag = await started;
  const named = bag.resolve('contextual');
  const value = bag.resolve(selectedToken);
  const owner = bag.inspect('contextual').metadata.owner;
  const label: 'exact' = named.read();
  const exact: 42 = value.value;
  const exactOwner: 'startup' = owner;
  return { label, exact, exactOwner, child: bag.scope() };
}
