import type { Builder } from '../src/di-bag';
import type { DisposableFactory, Factory, Registration } from '../src/registration';
import type { CheckedConstraints, NeedConstraint } from '../src/module-types';
import type { TokenBase } from '../src/tokens';
import type { Entry, EntryKeys, From, Merge, ReplacementKeyOf, ReplacementOutput } from '../src/types';
import type { BuilderReplacementRegistration, ReplacementAdmission, ReplacedEntries, ZeroDependencyAdmission } from '../src/replacement-types';
type Equal<A, B> = (<T>() => T extends A ? 1 : 2) extends (<T>() => T extends B ? 1 : 2) ? true : false;
type Assert<T extends true> = T;
export type OldReplace<E extends Entry, C extends NeedConstraint> = {
    <const K extends string, V extends ((this: void) => ReplacementOutput<NoInfer<From<E>>, K, C>) | DisposableFactory<(this: void) => ReplacementOutput<NoInfer<From<E>>, K, C>>>(key: K & ReplacementKeyOf<EntryKeys<E>, K>, registration: V & (Factory | DisposableFactory<Factory>) & ZeroDependencyAdmission<NoInfer<V>> & CheckedConstraints<C, Merge<From<E>, Record<K, NoInfer<V>>>>): Builder<Exclude<E, {
        key: K;
    }> | {
        key: K;
        registration: V;
    }, C>;
    <const K extends string | TokenBase, V extends Registration>(key: K & NoInfer<ReplacementAdmission<From<E>, K>>, registration: V & Registration & BuilderReplacementRegistration<E, C, NoInfer<K>, V>): Builder<ReplacedEntries<E, K, V>, C>;
};
export type GenericOverloads<E extends Entry, C extends NeedConstraint> = Assert<Equal<Builder<E, C>['replace'], OldReplace<E, C>>>;
export declare function oldToNew<E extends Entry, C extends NeedConstraint>(value: OldReplace<E, C>): Builder<E, C>['replace'];
export declare function newToOld<E extends Entry, C extends NeedConstraint>(value: Builder<E, C>['replace']): OldReplace<E, C>;
export declare const base: Builder<import("../src").Entries<{
    value: () => {
        read: (n: number) => number;
    };
    consumer: ({ value }: {
        value: {
            read(n: number): number;
        };
    }) => number;
}>, never>;
export declare const extracted: {
    <const K extends string, V extends ((this: void) => ReplacementOutput<NoInfer<From<import("../src").Entries<{
        value: () => {
            read: (n: number) => number;
        };
        consumer: ({ value }: {
            value: {
                read(n: number): number;
            };
        }) => number;
    }>>>, K, never>) | DisposableFactory<(this: void) => ReplacementOutput<NoInfer<From<import("../src").Entries<{
        value: () => {
            read: (n: number) => number;
        };
        consumer: ({ value }: {
            value: {
                read(n: number): number;
            };
        }) => number;
    }>>>, K, never>>>(key: K & ReplacementKeyOf<"consumer" | "value", K>, registration: (V & (DisposableFactory<Factory> | Factory)) & ZeroDependencyAdmission<NoInfer<V>>): Builder<{
        key: K;
        registration: V;
    } | Exclude<{
        key: "consumer";
        registration: ({ value }: {
            value: {
                read(n: number): number;
            };
        }) => number;
    }, {
        key: K;
    }> | Exclude<{
        key: "value";
        registration: () => {
            read: (n: number) => number;
        };
    }, {
        key: K;
    }>, never>;
    <const K extends string | TokenBase, V extends Registration>(key: K & NoInfer<ReplacementAdmission<From<import("../src").Entries<{
        value: () => {
            read: (n: number) => number;
        };
        consumer: ({ value }: {
            value: {
                read(n: number): number;
            };
        }) => number;
    }>>, K>>, registration: V & (Registration & BuilderReplacementRegistration<import("../src").Entries<{
        value: () => {
            read: (n: number) => number;
        };
        consumer: ({ value }: {
            value: {
                read(n: number): number;
            };
        }) => number;
    }>, never, NoInfer<K>, V>)): Builder<ReplacedEntries<import("../src").Entries<{
        value: () => {
            read: (n: number) => number;
        };
        consumer: ({ value }: {
            value: {
                read(n: number): number;
            };
        }) => number;
    }>, K, V>, never>;
};
export declare const extractedResult: {
    read(n: number): number;
    richer(): boolean;
};
export declare const specialized: {
    (key: "value", registration: (() => {
        read(n: number): number;
        extra: 'exact';
    }) & (DisposableFactory<Factory> | Factory)): Builder<{
        key: "consumer";
        registration: ({ value }: {
            value: {
                read(n: number): number;
            };
        }) => number;
    } | {
        key: "value";
        registration: () => {
            read(n: number): number;
            extra: 'exact';
        };
    }, never>;
    (key: "value", registration: (() => {
        read(n: number): number;
        extra: 'exact';
    }) & Registration): Builder<{
        key: "consumer";
        registration: ({ value }: {
            value: {
                read(n: number): number;
            };
        }) => number;
    } | {
        key: "value";
        registration: () => {
            read(n: number): number;
            extra: 'exact';
        };
    }, never>;
};
export declare const specializedResult: {
    read(n: number): number;
    extra: 'exact';
};
export declare const nested: {
    read(n: number): number;
    nested: {
        call(n: number): number;
    };
};
export declare const genericForward: <F extends () => {
    read(n: number): number;
}>(f: F) => Builder<{
    key: "consumer";
    registration: ({ value }: {
        value: {
            read(n: number): number;
        };
    }) => number;
} | {
    key: "value";
    registration: F;
}, never>;
export declare const inlineThis: {
    read(n: number): number;
    additional(): "yes";
};
export declare const disposable: {
    read(): 3;
    extra: 'owned';
};
export declare const promised: Promise<{
    read(): number;
    extra: 'async';
}>;
export declare const rawProvider: import("../src").Provider<() => Promise<42>, Readonly<{}>, readonly [], import("../src").TokenGraph<readonly [], never, readonly []>, Promise<42>>;
export declare const nativeProvider: import("../src").Provider<() => Promise<42>, Readonly<{}>, readonly [], import("../src").TokenGraph<readonly [], never, readonly []>, 42>;
export declare const decorated: import("../src").Provider<() => Promise<42>, Readonly<Readonly<{}> & {
    tag: 'retained';
}>, readonly [Readonly<{
    raw: Promise<42>;
}>], import("../src").TokenGraph<readonly [], never, readonly []>, Promise<42>>;
export declare const decoratedBag: import("../src").Bag<From<{
    key: "value";
    registration: import("../src").Provider<() => Promise<42>, Readonly<Readonly<{}> & {
        tag: 'retained';
    }>, readonly [Readonly<{
        raw: Promise<42>;
    }>], import("../src").TokenGraph<readonly [], never, readonly []>, Promise<42>>;
}>, never>;
export declare const decoratedValue: Promise<42>;
export declare const decoratedInspection: import("../src").InspectionSnapshot<Readonly<Readonly<{}> & {
    tag: 'retained';
}>, readonly [Readonly<{
    raw: Promise<42>;
}>]>;
export declare const nativeValue: Promise<42>;
export declare const tokenKey: unique symbol;
export declare const token: import("../src").Token<typeof tokenKey, {
    read(n: number): number;
}>;
export declare const tokenValue: {
    read: (n: number) => number;
    extra: 'token';
};
export declare const dependency: {
    read(): number;
    extra(): true;
};
export declare const optionalDependency: {
    read(): number | undefined;
    extra(): boolean;
};
export declare const modulePrivate: import("../src").Module<Pick<import("../src").Provided<From<{
    key: "consumer";
    registration: ({ value }: {
        value: {
            read(n: number): number;
        };
    }) => number;
}>>, "consumer">, Readonly<Pick<{
    value: {
        read(n: number): number;
    };
}, "value">>, {
    readonly consumer: "consumer";
    readonly needs: Pick<{
        value: {
            read(n: number): number;
        };
    }, "value">;
    readonly kind: "external";
}, import("../src").ModulePublicProviders<From<{
    key: "consumer";
    registration: ({ value }: {
        value: {
            read(n: number): number;
        };
    }) => number;
}>, "consumer">>;
export declare const privateValue: {
    read(n: number): number;
    extra: 'private';
};
export type Exact = [
    Assert<Equal<typeof extractedResult, {
        read(n: number): number;
        richer(): boolean;
    }>>,
    Assert<Equal<typeof specializedResult, {
        read(n: number): number;
        extra: 'exact';
    }>>,
    Assert<Equal<typeof decoratedValue, Promise<42>>>,
    Assert<Equal<typeof nativeValue, Promise<42>>>,
    Assert<Equal<typeof optionalDependency, {
        read(): number | undefined;
        extra(): boolean;
    }>>
];
export {};
