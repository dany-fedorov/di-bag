import type { Entries } from '../src';
export declare const inferredFactory: () => 42;
export declare const inferredObject: {
    kind: 'entry';
};
export declare const inferredPromise: Promise<42>;
export declare const inferredCallback: (n: number) => string;
export declare const inferredNamed: "named";
export declare const tokenKey: unique symbol;
export declare const inferredSymbol: symbol;
export declare const inferredUnionKey: "one" | "two";
export declare function optionalProjectionStillChecked(): void;
export declare const batch: import("../src").Builder<Entries<{
    value: () => {
        read: () => number;
    };
    use: ({ value }: {
        value: {
            read(): number;
        };
    }) => number;
}>, never>;
export declare const replaced: import("../src").Builder<{
    key: "use";
    registration: ({ value }: {
        value: {
            read(): number;
        };
    }) => number;
} | {
    key: "value";
    registration: () => {
        read(): number;
        extra(): "retained";
    };
}, never>;
export declare const selected: {
    read(): number;
    extra(): "retained";
};
