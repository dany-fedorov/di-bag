import type { ContributionConstraint } from '../src/contribution-types';
import type { Entries, Builder, ModuleBuilder, Registration } from '../src';
import type { Registrations } from '../src/registration';
import type { NeedConstraint } from '../src/module-types';
type Equal<A, B> = (<T>() => T extends A ? 1 : 2) extends (<T>() => T extends B ? 1 : 2) ? true : false;
type Assert<T extends true> = T;
export type Legacy<R extends Registrations> = {
    [K in keyof R & (string | symbol)]: {
        key: K;
        registration: R[K];
    };
}[keyof R & (string | symbol)];
export declare function wrap<K extends string | symbol, V extends Registration>(key: K, value: V): Entries<Record<K, V>>;
export declare function unwrap<K extends string | symbol, V extends Registration>(entry: Entries<Record<K, V>>): {
    key: K;
    registration: V;
};
export declare function passThrough<K extends string | symbol, V extends Registration>(value: Entries<Record<K, V>>): Legacy<Record<K, V>>;
export declare function passBack<K extends string | symbol, V extends Registration>(value: Legacy<Record<K, V>>): Entries<Record<K, V>>;
export declare function passBuilder<K extends string | symbol, V extends Registration, C extends NeedConstraint>(builder: Builder<Entries<Record<K, V>>, C>): Builder<Legacy<Record<K, V>>, C>;
export declare function passModule<K extends string | symbol, V extends Registration, C extends ContributionConstraint>(builder: ModuleBuilder<Entries<Record<K, V>>, C>): ModuleBuilder<Legacy<Record<K, V>>, C>;
export declare const entry: {
    key: "value";
    registration: () => 42;
};
export declare const entryKey: unique symbol;
export declare const symbolEntry: {
    key: typeof entryKey;
    registration: () => 42;
};
export declare const registrations: {
    value: () => number;
    use: ({ value }: {
        value: number;
    }) => number;
};
export declare const all: Builder<Entries<{
    value: () => number;
    use: ({ value }: {
        value: number;
    }) => number;
}>, never>;
export declare const each: Builder<{
    key: "value";
    registration: () => number;
} | {
    key: "use";
    registration: ({ value }: {
        value: number;
    }) => number;
}, never>;
export declare const moduleAll: ModuleBuilder<Entries<{
    value: () => number;
    use: ({ value }: {
        value: number;
    }) => number;
}>, never>;
export declare const moduleEach: ModuleBuilder<{
    key: "value";
    registration: () => number;
} | {
    key: "use";
    registration: ({ value }: {
        value: number;
    }) => number;
}, never>;
export type ConcreteWrappers = [Assert<Equal<typeof all, typeof each>>, Assert<Equal<typeof moduleAll, typeof moduleEach>>];
export {};
