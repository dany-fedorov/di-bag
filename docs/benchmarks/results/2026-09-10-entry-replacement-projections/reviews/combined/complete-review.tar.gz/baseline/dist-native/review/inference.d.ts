import type { Registrations } from '../src/registration';
export declare const value: 42;
export declare const object: {
    kind: 'object';
};
export declare const callback: (n: number) => string;
export declare const promise: Promise<42>;
export declare const optional: {
    kind: 'optional';
};
export declare const union: {
    kind: 'union';
};
export declare const retained: {
    kind: 'retained';
};
export declare const map: Registrations;
export declare const key: PropertyKey;
export declare const requiredCallback: {
    read(): number;
    extra(): boolean;
};
export declare const unionCallback: {
    read(): string;
    extra(): boolean;
};
export declare const noConsumers: {
    read(): string;
    extra(): boolean;
};
