import subprocess,fcntl,json,sys
from pathlib import Path
out=Path('/tmp/di-bag-replacement-context-factory-probe')
for variant,scenario in [('filtered-requirements','valid'),('combined','missing'),('combined','wrong-shape')]:
 with open('/tmp/di-bag-compiler-heavy.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  r=subprocess.run(['node','--disable-warning=MODULE_TYPELESS_PACKAGE_JSON',str(out/'native-worker.mjs'),variant,'1000','replacement',scenario],cwd='/tmp/di-bag-replacement-spike',text=True,capture_output=True,timeout=75)
  (out/(variant+'-native1000replacement-'+scenario+'.stdout.log')).write_text(r.stdout);(out/(variant+'-native1000replacement-'+scenario+'.stderr.log')).write_text(r.stderr)
  print(json.dumps({'variant':variant,'scenario':scenario,'status':r.returncode,'evidence':json.loads(r.stdout) if r.returncode==0 else None}),flush=True)
