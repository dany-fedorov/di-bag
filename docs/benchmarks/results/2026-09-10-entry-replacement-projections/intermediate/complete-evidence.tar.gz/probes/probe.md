# Throwaway replacement context factory probe

Current published base3a42173d9faacc63ad7728545580a63389d56de2 (source3414490); PR9 is waiting forCI and is unchanged.

Hypothesis: the same mapper-before-cache problem may affect the contextual zero-argument replacement signature, which captures From<E>, K and C. Factor ONLY the builder signature into ReplacementFactory<O>=(this:void)=>O, preserving the original explicit receiver, ReplacementOutput arguments, NoInfer, argument admission and return history. The native1000replacement control still exceeds originalRSSlimit (27.451s3072.23MiB) in the final PR9collection.

First compare baseline/candidate original100replacement work. Advance only if a meaningful improvement appears, then verify original1000native and independent compatibility. All code remains throwaway; no production or PR9 edits.

Allocation follow-up:100replacement creates10100 From properties,9901 Omit properties and9900 LocalReplacementRequirements properties in both baseline/context-factory.500nativecontext-factory reduceswork27,922,423→22,623,008 butTypes1,361,668→1,348,724 only andRSS1119.65→1094.89MiB;1000stillmemorykill23.880s3076.29MiB. Omit allocation stack reaches homomorphic instantiateMappedType/getReducedType of Merge before conditional evaluation. WrongConstraint<C,Provided<A>> eagerly mapsProvided evenwhenCnever. New single hypothesis: moveProvided projection inside privateWrongConstraint needs branch, pass rawA instead. KeepkeyofProvided<A> andProvided<A>[K]exactforany/optional semantics; no publicguardbranch oradmissionchange. Variantslazy-constraintsaloneandcombinedwithcontextfactory;notproduction.
