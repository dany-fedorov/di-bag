from pathlib import Path
import shutil,json,hashlib,subprocess,sys
repo=Path('/tmp/di-bag-replacement-spike');stage=Path('/tmp/di-bag-replacement-projection-evidence');stage.mkdir(exist_ok=True)
head=sys.argv[1];base='fb5fe6c736fc0c21b32b93dfc9e170c955209bb9'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=repo,text=True).strip()
for target,origin in [('review',Path('/tmp/di-bag-replacement-projection-review')),('probes',Path('/tmp/di-bag-replacement-context-factory-probe'))]:
 dest=stage/target;dest.mkdir(exist_ok=True)
 for f in origin.iterdir():
  if f.is_file():shutil.copyfile(f,dest/f.name)
 if target=='review':
  for variant in ['baseline','candidate']:
   for d in (origin/variant).iterdir():
    if d.is_dir() and d.name in ('dist-classic','dist-native','review','src'):
     shutil.copytree(d,dest/variant/d.name,dirs_exist_ok=True)
identity={'baseline':base,'candidate':head,'reviewBaseline':'3a42173d9faacc63ad7728545580a63389d56de2','productionFiles':{},'compilerInputs':{}}
for f in sorted((repo/'src').glob('*.ts')):
 before=subprocess.check_output(['git','show',base+':src/'+f.name],cwd=repo)
 after=f.read_bytes();identity['productionFiles'][f.name]={'baseline':hashlib.sha256(before).hexdigest(),'candidate':hashlib.sha256(after).hexdigest()}
 assert before==subprocess.check_output(['git','show',identity['reviewBaseline']+':src/'+f.name],cwd=repo)
 if before!=after:
  d=stage/'source';d.mkdir(exist_ok=True);(d/('baseline.'+f.name)).write_bytes(before);(d/('candidate.'+f.name)).write_bytes(after)
for f in ['tests/compiler.ts','scripts/compiler-case.ts','scripts/check-compiler-case.ts','scripts/native-scale.ts','scripts/native-compiler.ts','scripts/native-process.ts','package.json','package-lock.json']:
 identity['compilerInputs'][f]=hashlib.sha256((repo/f).read_bytes()).hexdigest()
 assert (repo/f).read_bytes()==subprocess.check_output(['git','show',base+':'+f],cwd=repo)
(stage/'source-manifest.json').write_text(json.dumps(identity,indent=2)+'\n')
gates=stage/'gates';gates.mkdir(exist_ok=True)
for pattern in ['di-bag-replacement-projection-integration-*.log','di-bag-replacement-projection-integration-verification.json','di-bag-replacement-projection-red.log','di-bag-replacement-projection-green.log']:
 for f in Path('/tmp').glob(pattern):shutil.copyfile(f,gates/f.name)
for name in ['collect','summarize','stage','verify']:
 shutil.copyfile('/tmp/di-bag-replacement-projection-'+name+'.py',stage/(name+'.py'))
print(json.dumps({'stage':str(stage),'files':sum(1 for f in stage.rglob('*') if f.is_file()),'head':head}))
