from pathlib import Path
import json,hashlib,shutil,subprocess
root=Path('/tmp/di-bag-replacement-spike');stage=Path('/tmp/di-bag-replacement-projection-evidence');measurements=Path('/tmp/di-bag-replacement-projection-measurements')
summary=json.loads((measurements/'summary.json').read_text());manifest=json.loads((stage/'source-manifest.json').read_text())
assert summary['candidate']==manifest['candidate']=='3360a96516daa7483c490a1bcacaa1ed16ec7ce1'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==summary['candidate']
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True).strip()
for x in summary['original1000']:
 if x['form'] in ('bindings','modules') or (x['form']=='replacement' and x['lane']=='native'):assert x['accepted'],x
shutil.copytree(measurements,stage/'measurements',dirs_exist_ok=True)
lines=[f"Final source: `{summary['candidate']}`. The clean collection contains **{summary['cases']} rows: {summary['accepted']} accepted and {summary['failed']} failed**. All paired 500-operation rows use identical generated source on the baseline and candidate.", '', '| 500-operation form | Classic instantiations before → after | Native instantiations before → after |', '| --- | ---: | ---: |']
for form in ('chained','replacement','bindings','modules'):
 values=[]
 for lane in ('classic','native'):
  x=next(x for x in summary['comparisons'] if x['form']==form and x['lane']==lane)
  values.append(f"{x['beforeInstantiations']:,} → {x['afterInstantiations']:,} ({-x['reductionPercent']:+.3f}%)")
 lines.append(f"| {form} | {values[0]} | {values[1]} |")
lines+=['','| Original 1,000-operation form | Scenario | Compiler | Accepted | Result | Process time | Observed peak RSS |','| --- | --- | --- | --- | --- | ---: | ---: |']
for x in summary['original1000']:
 result='zero diagnostics' if x['accepted'] and x['scenario']=='valid' else ('intended boundary error; no TS2589' if x['accepted'] else x['reason'])
 rss=f"{x['maxRssMiB']:.2f} MiB" if isinstance(x['maxRssMiB'],(int,float)) else 'unavailable'
 lines.append(f"| {x['form']} | {x['scenario']} | {x['lane']} | {'yes' if x['accepted'] else 'no'} | {result} | {x['processMilliseconds']/1000:.3f} s | {rss} |")
lines+=['','Accepted negative rows mean invalid code was rejected at the original marked boundary without TS2589. Raw rows retain every diagnostic and the unchanged oracle decides acceptance. The original native 1,000-replacement valid/missing/wrong-shape cases now pass. All twelve original binding/module cases remain accepted. The classic 1,000 named/replacement stacks and native 1,000 named timeout remain open. This collection reruns all 24 original 1,000-operation cases for these four forms; it does not reclassify the historical 108-row matrix.', '', 'Local verification passed **942 tests, zero failures and 18,897 assertions**, both compiler builds and source typechecks, **31 emitted Node regressions per compiler**, and the strict native audit (**639/639 expected diagnostics across 124 files**, zero unexpected). Generated references, documentation checks and all nine examples passed. The local platform manifest was refreshed before verification and npm update notifications were disabled to match CI. All 18 validation steps and their raw logs are retained under `gates/`. The pull request records hosted CI and merge verification.']
p=stage/'README.md';s=p.read_text();assert 'FINAL MEASUREMENTS AND VALIDATION PENDING.' in s;p.write_text(s.replace('FINAL MEASUREMENTS AND VALIDATION PENDING.','\n'.join(lines)))
shutil.copyfile('/tmp/di-bag-replacement-projection-finalize.py',stage/'finalize.py')
files={str(p.relative_to(stage)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(stage.rglob('*')) if p.is_file() and p.name!='artifact-manifest.json'}
(stage/'artifact-manifest.json').write_text(json.dumps({'sourceCommit':summary['candidate'],'baseline':summary['baseline'],'files':files},indent=2)+'\n')
print(json.dumps({'files':len(files)+1,'bytes':sum(x['bytes'] for x in files.values()),'accepted':summary['accepted'],'failed':summary['failed'],'stage':str(stage)}))
