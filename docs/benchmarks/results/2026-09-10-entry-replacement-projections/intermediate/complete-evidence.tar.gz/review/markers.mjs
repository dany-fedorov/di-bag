import fs from 'node:fs';import {matchDiagnosticMarkers} from '/tmp/di-bag-replacement-spike/tests/diagnostic-markers.ts';
const root='/tmp/di-bag-replacement-projection-review';const summary={};
for(const kind of ['classic','native'])for(const variant of ['baseline','candidate']){
const d=JSON.parse(fs.readFileSync(`${root}/${kind}-semantic-${variant}.json`,'utf8'));
const files=[...new Set(d.diagnostics.map(x=>x.file))];const results=files.map(file=>({file,...matchDiagnosticMarkers(fs.readFileSync(file,'utf8'),file,d.diagnostics.filter(x=>x.file===file))}));
if(results.some(x=>x.unexpected.length||x.missing.length))throw Error(JSON.stringify(results.filter(x=>x.unexpected.length||x.missing.length)));
summary[`${kind}-${variant}`]={files:files.length,expected:results.reduce((n,x)=>n+x.expected,0),matched:results.reduce((n,x)=>n+x.matched,0),unexpected:0,missing:0};
}
fs.writeFileSync(`${root}/markers.json`,JSON.stringify(summary,null,2));console.log(JSON.stringify(summary));
